# StreamBox

Xtream Codes ve M3U destekli, Netflix/Stremio tarzı arayüze sahip Android IPTV **oynatıcısı** (telefon/tablet).
Uygulama içerik, kanal listesi veya abonelik sağlamaz; kullanıcı kendi hesabının bilgilerini girer.

## Özellikler

**Ana sayfa:** Önerilen afişler (puanı 7.0 ve üstü içerikler, otomatik kayan) → hemen altında *Kaldığın Yerden Devam Et* → yüksek puanlı filmler/diziler → canlı TV → kategori satırları.

**Liste yönetimi:** Liste diske kaydedilir. Uygulama açılınca kayıtlı liste hemen kullanılır ve "Liste güncellensin mi?" diye sorar; onaylarsan yenilenir (eski liste yenilenirken görünmeye devam eder). Ayarlar'dan soru kapatılabilir.

**Listem:** Filmler / Diziler / Canlı TV / Geçmiş bölümleri; film, dizi ve kanallarda favori kategorilerine göre filtre.

**Oynatıcı:**
- Dişli menüsünde ve alt düğmelerde: oynatma hızı (0.5x–2x), ekran boyutu (En uygun, Sığdır, Uzat, Doldur), ses parçası, altyazı, video kalitesi, PiP
- "En uygun": video oranı ekrana yakınsa doldurur, değilse sığdırır
- Ekranda dikey kaydırma: sol yarı parlaklık, sağ yarı ses
- Çift dokunuş ±10 sn, Ana Ekran tuşunda otomatik PiP
- Altyazı görünümü (boyut, renk, arka plan, kenar)
- Altyazı ekleme: cihazdan dosya (.srt/.vtt/.ass, Türkçe karakter kodlaması otomatik düzeltilir) veya SubDL / OpenSubtitles'ta online arama

**Cihazdaki videolar:** Ana sayfa üstündeki klasör simgesi veya Ayarlar'dan. Birden fazla dosya seçilirse ada göre sıralı oynatma listesi olur, kaldığın yerden devam eder.

**Diğer:** Canlı TV kategori/arama/favori/EPG, film ve dizi detayı (sezon/bölüm), kaldığın yerden devam, yavaş (uydu) bağlantı için uzun zaman aşımı ve büyük tampon.

## Derleme

1. Android Studio'yu (Koala veya yenisi) kur, bu klasörü **Open** ile aç, Gradle senkronizasyonunu bekle (Android SDK 34).
2. Telefonu USB hata ayıklama ile bağla ve **Run** de. APK için: *Build > Build APK(s)*.

Bilgisayarsız derleme için `.github/workflows/build.yml` GitHub Actions ile `app-debug.apk` üretir.

## İsteğe bağlı anahtarlar (Ayarlar)

| Servis | Ne için | Not |
|---|---|---|
| SubDL | Online altyazı arama | Ücretsiz API anahtarı; indirme anahtarsız da çalışır (günlük sınırlı) |
| OpenSubtitles | Online altyazı arama | API anahtarı + kullanıcı adı + şifre gerekir (indirme için giriş şart) |
| OMDb | Gerçek IMDb puanı | Ücretsiz anahtar, günlük 1000 istek |

Anahtarlar ve şifre şifrelenmeden, yalnızca cihazın uygulama deposunda saklanır.

## Kod haritası

| Dosya | Görevi |
|---|---|
| `data/XtreamApi.kt`, `M3uParser.kt`, `XmltvParser.kt` | Kaynaklardan veri okuma |
| `data/Repository.kt` | Canlı/film/dizi paralel ve bağımsız yükleme |
| `data/CatalogCache.kt` | Listeyi diske kaydetme |
| `data/SubtitleService.kt` | SubDL, OpenSubtitles, yerel altyazı, kodlama dönüşümü |
| `data/Ratings.kt` | Puan okuma, başlık temizleme, OMDb |
| `AppViewModel.kt` | Oturum, katalog, yenileme onayı, anahtarlar, favori/geçmiş |
| `ui/MainScreen.kt` | Sekmeler, ana sayfa afişleri, Listem |
| `ui/PlayerScreen.kt`, `PlayerSettingsSheet.kt` | Oynatıcı ve ayar paneli |
| `ui/LocalMedia.kt` | Cihazdan video seçici |

## Güncelleme (eski sürümü silmeden)

`app/stable.jks` her derlemede aynı imzayı sağlar ve `versionCode` GitHub Actions çalıştırma numarasından gelir.
Bu sürümden SONRA yapılan derlemeler eskisinin üstüne yüklenir. Bu sürüme geçerken eski uygulamayı BİR KEZ silmek gerekir.
`stable.jks` şifresi kodda yazılıdır; yalnızca kişisel kullanım içindir, uygulamayı mağazada yayınlayacaksan kendi anahtarını üret.

## Ana sayfa katalogları

Ayarlar > Ana sayfa katalogları: TMDb (anahtar) veya Stremio Cinemeta (anahtarsız) ile Popüler / Yeni / Öne çıkan satırları
listendeki içeriklerle başlığa göre eşleştirilir. İsteğe bağlı olarak bir Stremio eklentisinin manifest adresi eklenebilir.

## İçerik seçimi

Ayarlar > İçerik seçimi: canlı TV / film / dizi kategorilerini kapatabilir, ana sayfada hangi satırların görüneceğini seçebilirsin.
Kapalı kategoriler listeden çıkar. Liste yenilenirken, kapalı kategoriler toplam içeriğin en az %25'ini tutuyorsa (önceki indirmelerden bilinir)
yalnızca açık kategoriler tek tek indirilir; aksi halde tek istekle indirilip kapalılar ayıklanır. Kategoriyi geri açınca liste otomatik yenilenir.

## Bilinen sınırlar

- Bu kod yazıldığı ortamda **derlenip cihazda denenmedi**. İlk derlemede küçük hatalar çıkabilir.
- Puanlar Ayarlar > Puan kaynağı'ndan seçilir (OMDb, TMDb, TVMaze). Listenin kendi puanı 10 ise güvenilmez sayılır. Eşleşme başlık temizliğine dayanır, yanlış eşleşme olabilir.
- Canlı yayında görüntü donarsa uygulama otomatik yeniden bağlanır (en fazla 12 deneme).
- OpenSubtitles ve SubDL akışları resmi dokümana göre yazıldı ama gerçek hesapla denenmedi.
- M3U listelerinde diziler gruplanmaz; Dizi sekmesi yalnızca Xtream girişinde dolar.
- Altyazı ve ses parçası seçimi yayının sunduklarıyla sınırlıdır. Çoğu canlı kanal tek ses/tek kalite verir.
- Android TV / kumanda arayüzü yok.

## Yasal not

Bu uygulama yalnızca bir oynatıcıdır. Yalnızca kullanım hakkına sahip olduğun yayınları oynat. Altyazı servislerinin kullanım şartlarına uy. Uygulama adı ve arayüzü özgündür; Netflix, Stremio veya başka bir markanın adı, logosu ya da görselleri kullanılmamıştır. Yayınlamadan önce kendi adını ve ikonunu belirle.
