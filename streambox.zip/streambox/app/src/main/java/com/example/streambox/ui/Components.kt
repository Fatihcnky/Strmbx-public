package com.example.streambox.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Row
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalContext
import com.example.streambox.data.Ratings
import java.util.Locale
import com.example.streambox.data.Category
import com.example.streambox.data.HistoryEntity
import com.example.streambox.data.LiveChannel
import com.example.streambox.data.Movie
import com.example.streambox.data.Series

val Accent = Color(0xFF8B5CF6)
val Bg = Color(0xFF0B0B10)
val Surface1 = Color(0xFF17171F)

@Composable
fun StreamTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Bg,
            surface = Surface1,
            onSurface = Color.White,
            onBackground = Color.White,
            secondaryContainer = Color(0xFF2E2549),
        ),
        content = content,
    )
}

/** Izgara/satırlarda gösterilen kart verisi; payload tıklanınca açılacak asıl nesnedir. */
data class Tile(
    val key: String,
    val title: String,
    val image: String?,
    val categoryId: String = "",
    val payload: Any? = null,
    val badge: String? = null,
    /** İzleme ilerlemesi (0..1); "Kaldığın yerden devam et" kartlarında poster altında çubuk olarak çizilir. */
    val progress: Float? = null,
)

class Actions(
    val onMovie: (Movie) -> Unit,
    val onSeries: (Series) -> Unit,
    val onLive: (List<LiveChannel>, Int) -> Unit,
    val onResume: (HistoryEntity) -> Unit,
) {
    fun handle(t: Tile) {
        when (val p = t.payload) {
            is Movie -> onMovie(p)
            is Series -> onSeries(p)
            is LiveChannel -> onLive(listOf(p), 0)
            is HistoryEntity -> onResume(p)
            else -> Unit
        }
    }
}

/** Puan tablosu + "bu başlığın puanını getir" isteği; NavHost'un üstünden sağlanır. */
class RatingCtx(val map: Map<String, Double>, val request: (String, String) -> Unit)

val LocalRatings = staticCompositionLocalOf<RatingCtx?> { null }

/** Başlığın puanı: önce internetten çekilen, yoksa listenin (geçerliyse) puanı. Görününce çekilmesini ister. */
@Composable
fun rememberRating(name: String, provider: String?, type: String): Double? {
    val ctx = LocalRatings.current ?: return Ratings.providerRating(provider)
    val k = remember(name) { Ratings.key(name) }
    LaunchedEffect(k) { ctx.request(name, type) }
    return ctx.map[k]?.takeIf { it > 0 } ?: Ratings.providerRating(provider)
}

fun ratingLabel(r: Double) = "★ " + String.format(Locale.US, "%.1f", r)

@Composable
fun PosterCard(tile: Tile, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val p = tile.payload
    val live: Double? = when (p) {
        is Movie -> rememberRating(p.name, p.rating, "movie")
        is Series -> rememberRating(p.name, p.rating, "series")
        else -> null
    }
    val badge = tile.badge ?: live?.let(::ratingLabel)
    val ctx = LocalContext.current
    val request = remember(tile.image) {
        ImageRequest.Builder(ctx).data(tile.image).size(300, 450).crossfade(false).build()
    }
    Column(modifier.clickable(onClick = onClick)) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
                .clip(RoundedCornerShape(8.dp))
                .background(Surface1),
            contentAlignment = Alignment.Center,
        ) {
            if (!tile.image.isNullOrBlank()) {
                AsyncImage(
                    model = request,
                    contentDescription = tile.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                Text(
                    tile.title,
                    textAlign = TextAlign.Center,
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(8.dp),
                    style = MaterialTheme.typography.labelMedium,
                )
            }
            tile.progress?.let { p ->
                Box(
                    Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .height(5.dp)
                        .background(Color(0x99000000)),
                ) {
                    Box(Modifier.fillMaxHeight().fillMaxWidth(p.coerceIn(0.02f, 1f)).background(Accent))
                }
            }
            badge?.let { b ->
                Text(
                    b,
                    color = Color(0xFFFFC107),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(4.dp)
                        .background(Color(0xCC000000), RoundedCornerShape(4.dp))
                        .padding(horizontal = 5.dp, vertical = 1.dp),
                )
            }
        }
        Text(
            tile.title,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}

@Composable
fun TileRow(
    title: String,
    tiles: List<Tile>,
    onClick: (Tile) -> Unit,
    onMore: (() -> Unit)? = null,
) {
    if (tiles.isEmpty()) return
    Column(Modifier.padding(top = 18.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            if (onMore != null) {
                Text(
                    "Tümü ›", color = Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onMore).padding(horizontal = 8.dp, vertical = 4.dp),
                )
            }
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            itemsIndexed(tiles) { _, t ->
                PosterCard(t, Modifier.width(112.dp)) { onClick(t) }
            }
            if (onMore != null) {
                item {
                    Box(
                        Modifier
                            .width(112.dp)
                            .aspectRatio(2f / 3f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Surface1)
                            .clickable(onClick = onMore),
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = Accent)
                            Text("Daha fazla", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SearchField(value: String, hint: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        placeholder = { Text(hint) },
        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
        trailingIcon = {
            if (value.isNotEmpty()) {
                IconButton(onClick = { onChange("") }) {
                    Icon(Icons.Filled.Close, contentDescription = "Temizle")
                }
            }
        },
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
    )
}

@Composable
fun CategoryChips(
    categories: List<Category>,
    selected: String?,
    extra: List<Pair<String, String>> = emptyList(),
    onSelect: (String?) -> Unit,
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            FilterChip(selected = selected == null, onClick = { onSelect(null) }, label = { Text("Tümü") })
        }
        items(extra) { (id, label) ->
            FilterChip(selected = selected == id, onClick = { onSelect(id) }, label = { Text(label) })
        }
        items(categories) { c ->
            FilterChip(
                selected = selected == c.id,
                onClick = { onSelect(c.id) },
                label = { Text(c.name, maxLines = 1) },
            )
        }
    }
}

@Composable
fun EmptyState(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Color.Gray, textAlign = TextAlign.Center)
    }
}
