package com.example.streambox.ui

import com.example.streambox.data.Catalog
import com.example.streambox.data.FeedRow
import com.example.streambox.data.Movie
import com.example.streambox.data.Ratings
import com.example.streambox.data.Series
import kotlinx.coroutines.yield
import kotlin.math.abs
import kotlin.random.Random

/** Öneri afişindeki bir öğe: film mi dizi mi, yıl ve puan bilgisiyle. */
class HeroItem(val tile: Tile, val isSeries: Boolean, val year: Int?, val rating: Double?, val series: Series?)

/** Katalogdan (TMDb/Stremio) bir öğenin kullanıcının listesindeki karşılığı: puan/yıl tohumlamak için. */
class Seed(val key: String, val rating: Double?, val year: Int?)

/** [id]: ana sayfa seçiminde (gizle/göster) kullanılan kimlik. [tiles] satırın tüm öğeleri; ekranda ilk 20 gösterilir, "Daha fazla" hepsini açar. */
class HomeRowData(val id: String, val title: String, val tiles: List<Tile>)

/** Ana sayfanın ağır hesaplanan kısmı; ana iş parçacığını yormamak için arka planda üretilir. */
class HomeModel(
    val hero: List<HeroItem>,
    val feedRows: List<HomeRowData>,
    val ratedMovies: List<Tile>,
    val ratedSeries: List<Tile>,
    val liveTiles: List<Tile>,
    val movieRows: List<HomeRowData>,
    val seriesRows: List<HomeRowData>,
    val seeds: List<Seed>,
)

object HomeBuilder {

    private const val MIN_YEAR = 2000

    private fun ratingOf(name: String, provider: String?, imdb: Map<String, Double>): Double? =
        imdb[Ratings.key(name)]?.takeIf { it > 0 } ?: Ratings.providerRating(provider)

    private fun yearOf(name: String, own: String?, years: Map<String, Int>): Int? =
        own?.let { Ratings.parseYear(it) } ?: Ratings.yearOf(name) ?: years[Ratings.key(name)]

    suspend fun build(
        cat: Catalog,
        imdb: Map<String, Double>,
        years: Map<String, Int>,
        feeds: List<FeedRow>,
        hidden: Set<String>,
    ): HomeModel {
        // --- Kullanıcının içerikleri için başlık dizini (eşleştirme)
        val movieIdx = HashMap<String, MutableList<Movie>>()
        val seriesIdx = HashMap<String, MutableList<Series>>()
        cat.movies.forEachIndexed { i, m ->
            if (i % 3000 == 0) yield()
            movieIdx.getOrPut(Ratings.norm(Ratings.clean(m.name).first)) { ArrayList(1) }.add(m)
        }
        cat.series.forEachIndexed { i, s ->
            if (i % 3000 == 0) yield()
            seriesIdx.getOrPut(Ratings.norm(Ratings.clean(s.name).first)) { ArrayList(1) }.add(s)
        }

        // --- Katalog satırlarını eşleştir
        val seeds = ArrayList<Seed>()
        val heroPool = LinkedHashMap<String, HeroItem>()
        val feedRows = ArrayList<HomeRowData>()
        for (row in feeds) {
            yield()
            if ("feed:${row.title}" in hidden) continue
            val tiles = ArrayList<Tile>()
            val seen = HashSet<String>()
            for (it in row.items) {
                val keys = listOfNotNull(it.title, it.altTitle).map { t -> Ratings.norm(t) }.filter { k -> k.isNotEmpty() }
                if (row.type == "series") {
                    val s = keys.firstNotNullOfOrNull { k ->
                        seriesIdx[k]?.firstOrNull { c -> yearOk(it.year, yearOf(c.name, c.year, years)) }
                    } ?: continue
                    val tile = s.toTile().let { t -> it.rating?.let { r -> t.copy(badge = ratingLabel(r)) } ?: t }
                    if (!seen.add(tile.key)) continue
                    tiles += tile
                    seeds += Seed(Ratings.key(s.name), it.rating, it.year)
                    val y = it.year ?: yearOf(s.name, s.year, years)
                    if (y != null && y >= MIN_YEAR && !s.poster.isNullOrBlank()) {
                        heroPool.putIfAbsent(tile.key, HeroItem(tile, true, y, it.rating ?: ratingOf(s.name, s.rating, imdb), s))
                    }
                } else {
                    val m = keys.firstNotNullOfOrNull { k ->
                        movieIdx[k]?.firstOrNull { c -> yearOk(it.year, yearOf(c.name, c.year, years)) }
                    } ?: continue
                    val tile = m.toTile().let { t -> it.rating?.let { r -> t.copy(badge = ratingLabel(r)) } ?: t }
                    if (!seen.add(tile.key)) continue
                    tiles += tile
                    seeds += Seed(Ratings.key(m.name), it.rating, it.year)
                    val y = it.year ?: yearOf(m.name, m.year, years)
                    if (y != null && y >= MIN_YEAR && !m.poster.isNullOrBlank()) {
                        heroPool.putIfAbsent(tile.key, HeroItem(tile, false, y, it.rating ?: ratingOf(m.name, m.rating, imdb), null))
                    }
                }
                if (tiles.size >= 150) break
            }
            if (tiles.size >= 3) feedRows += HomeRowData("feed:${row.title}", row.title, tiles)
        }

        // --- Puanlı satırlar + kendi içeriklerinden öneri adayları
        class Rated(val tile: Tile, val rating: Double, val isSeries: Boolean)
        val rated = ArrayList<Rated>()
        cat.movies.forEachIndexed { i, m ->
            if (i % 3000 == 0) yield()
            val r = ratingOf(m.name, m.rating, imdb) ?: return@forEachIndexed
            if (r < 7.0) return@forEachIndexed
            val tile = m.toTile().copy(badge = ratingLabel(r))
            rated += Rated(tile, r, false)
            val y = yearOf(m.name, m.year, years)
            if (y != null && y >= MIN_YEAR && !m.poster.isNullOrBlank()) {
                heroPool.putIfAbsent(tile.key, HeroItem(tile, false, y, r, null))
            }
        }
        cat.series.forEachIndexed { i, s ->
            if (i % 3000 == 0) yield()
            val r = ratingOf(s.name, s.rating, imdb) ?: return@forEachIndexed
            if (r < 7.0) return@forEachIndexed
            val tile = s.toTile().copy(badge = ratingLabel(r))
            rated += Rated(tile, r, true)
            val y = yearOf(s.name, s.year, years)
            if (y != null && y >= MIN_YEAR && !s.poster.isNullOrBlank()) {
                heroPool.putIfAbsent(tile.key, HeroItem(tile, true, y, r, s))
            }
        }
        rated.sortByDescending { it.rating }

        // --- Öneri afişi: 2000 sonrası, puanı yüksek olanlardan karışık 8 tane (aynı katalogda aynı sıra)
        val rng = Random(cat.movies.size * 31 + cat.series.size)
        val hero = heroPool.values
            .filter { (it.rating ?: 0.0) >= 6.5 }
            .sortedByDescending { it.rating ?: 0.0 }
            .take(40)
            .shuffled(rng)
            .take(8)

        val byMovieCat = cat.movies.groupBy { it.categoryId }
        val movieRows = cat.movieCategories.filter { "mcat:${it.id}" !in hidden }.mapNotNull { c ->
            byMovieCat[c.id]?.take(300)?.map { it.toTile() }?.takeIf { it.isNotEmpty() }
                ?.let { HomeRowData("mcat:${c.id}", "Filmler • ${c.name}", it) }
        }.take(12)
        val bySeriesCat = cat.series.groupBy { it.categoryId }
        val seriesRows = cat.seriesCategories.filter { "scat:${it.id}" !in hidden }.mapNotNull { c ->
            bySeriesCat[c.id]?.take(300)?.map { it.toTile() }?.takeIf { it.isNotEmpty() }
                ?.let { HomeRowData("scat:${c.id}", "Diziler • ${c.name}", it) }
        }.take(10)

        return HomeModel(
            hero = hero,
            feedRows = feedRows,
            ratedMovies = rated.filter { !it.isSeries }.take(100).map { it.tile },
            ratedSeries = rated.filter { it.isSeries }.take(100).map { it.tile },
            liveTiles = cat.live.take(30).map { it.toTile() },
            movieRows = movieRows,
            seriesRows = seriesRows,
            seeds = seeds,
        )
    }

    private fun yearOk(want: Int?, have: Int?) = want == null || have == null || abs(want - have) <= 1
}
