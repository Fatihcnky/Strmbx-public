package com.example.streambox.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.streambox.AppViewModel
import com.example.streambox.data.Account
import com.example.streambox.data.AccountType

@Composable
fun LoginScreen(vm: AppViewModel, onDone: () -> Unit) {
    val loading by vm.loading.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()

    var xtream by rememberSaveable { mutableStateOf(true) }
    var name by rememberSaveable { mutableStateOf("") }
    var server by rememberSaveable { mutableStateOf("") }
    var user by rememberSaveable { mutableStateOf("") }
    var pass by rememberSaveable { mutableStateOf("") }
    var m3u by rememberSaveable { mutableStateOf("") }
    var epg by rememberSaveable { mutableStateOf("") }

    val canSubmit = !loading && if (xtream) {
        server.isNotBlank() && user.isNotBlank() && pass.isNotBlank()
    } else {
        m3u.isNotBlank()
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Spacer(Modifier.height(24.dp))
        Text("STREAMBOX", color = Accent, fontWeight = FontWeight.ExtraBold, fontSize = 32.sp, letterSpacing = 3.sp)
        Text(
            "Kendi IPTV aboneliğinizin bilgilerini girin. Uygulama içerik sağlamaz, yalnızca oynatıcıdır.",
            color = Color.Gray,
            style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = xtream, onClick = { xtream = true }, label = { Text("Xtream Codes") })
            FilterChip(selected = !xtream, onClick = { xtream = false }, label = { Text("M3U Linki") })
        }

        OutlinedTextField(
            value = name, onValueChange = { name = it }, singleLine = true,
            label = { Text("Liste adı (isteğe bağlı)") }, modifier = Modifier.fillMaxWidth(),
        )

        if (xtream) {
            OutlinedTextField(
                value = server, onValueChange = { server = it }, singleLine = true,
                label = { Text("Sunucu (http://host:port)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = user, onValueChange = { user = it }, singleLine = true,
                label = { Text("Kullanıcı adı") }, modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = pass, onValueChange = { pass = it }, singleLine = true,
                label = { Text("Şifre") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth(),
            )
        } else {
            OutlinedTextField(
                value = m3u, onValueChange = { m3u = it },
                label = { Text("M3U / M3U8 linki") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                minLines = 2, modifier = Modifier.fillMaxWidth(),
            )
        }
        OutlinedTextField(
            value = epg, onValueChange = { epg = it }, singleLine = true,
            label = { Text("EPG (XMLTV) linki - isteğe bağlı") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            modifier = Modifier.fillMaxWidth(),
        )

        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

        Button(
            onClick = {
                val acc = Account(
                    type = if (xtream) AccountType.XTREAM else AccountType.M3U,
                    name = name.trim(),
                    server = server.trim(),
                    username = user.trim(),
                    password = pass.trim(),
                    m3uUrl = m3u.trim(),
                    epgUrl = epg.trim(),
                )
                vm.login(acc, onDone)
            },
            enabled = canSubmit,
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) {
            if (loading) {
                CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Color.White)
                Spacer(Modifier.size(10.dp))
                Text("Liste yükleniyor...")
            } else {
                Text("Bağlan")
            }
        }
    }
}
