package com.example.streambox.data

import android.content.Context
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

/** Kataloğu diske kaydeder; böylece her açılışta liste yeniden indirilmez. */
object CatalogCache {
    private val json = Json { ignoreUnknownKeys = true }

    private fun file(ctx: Context, acc: Account): File {
        val key = (acc.type.name + "|" + acc.server + "|" + acc.username + "|" + acc.m3uUrl)
            .hashCode().toUInt().toString(16)
        return File(ctx.filesDir, "catalog_$key.json")
    }

    fun load(ctx: Context, acc: Account): Catalog? = runCatching {
        val f = file(ctx, acc)
        if (!f.exists()) null else json.decodeFromString<Catalog>(f.readText())
    }.getOrNull()

    fun save(ctx: Context, acc: Account, c: Catalog) {
        runCatching {
            val clean = c.copy(pending = emptySet(), errors = emptyMap())
            val f = file(ctx, acc)
            val tmp = File(f.parentFile, f.name + ".tmp")
            tmp.writeText(json.encodeToString(clean))
            tmp.renameTo(f)
        }
    }

    fun delete(ctx: Context, acc: Account) {
        runCatching { file(ctx, acc).delete() }
    }
}
