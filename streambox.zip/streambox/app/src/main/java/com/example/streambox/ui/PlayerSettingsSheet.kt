package com.example.streambox.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.ui.AspectRatioFrameLayout
import com.example.streambox.data.ApiKeys
import com.example.streambox.data.PlayerSettings
import com.example.streambox.data.SubResult
import kotlinx.coroutines.launch
import java.util.Locale

// Seçenek listeleri: PlayerSettings alanları bu listelerin indeksidir.
val ResizeLabels = listOf("En uygun (otomatik)", "Sığdır", "Uzat", "Doldur (kırp)")
val ResizeShort = listOf("Oto", "Sığdır", "Uzat", "Doldur")

/** İndeks 0 ("En uygun") çalışma anında Sığdır/Doldur arasında seçilir; buradaki değer yer tutucudur. */
val ResizeModes = listOf(
    AspectRatioFrameLayout.RESIZE_MODE_FIT,
    AspectRatioFrameLayout.RESIZE_MODE_FIT,
    AspectRatioFrameLayout.RESIZE_MODE_FILL,
    AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
)
val SpeedValues = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)
val SpeedLabels = listOf("0.5x", "0.75x", "Normal (1x)", "1.25x", "1.5x", "1.75x", "2x")
val SubSizeLabels = listOf("Küçük", "Orta", "Büyük", "Çok büyük")
val SubSizeSp = listOf(14f, 18f, 24f, 32f)
val SubColorLabels = listOf("Beyaz", "Sarı", "Yeşil", "Camgöbeği")
val SubColors = listOf(0xFFFFFFFF.toInt(), 0xFFFFEB3B.toInt(), 0xFF69F0AE.toInt(), 0xFF18FFFF.toInt())
val SubBgLabels = listOf("Yok", "Yarı saydam", "Siyah")
val SubBgColors = listOf(0x00000000, 0x99000000.toInt(), 0xFF000000.toInt())
val SubEdgeLabels = listOf("Yok", "Gölge", "Kontur")

private val LangLabels = listOf("Türkçe", "İngilizce", "Tümü")
private val LangCodes = listOf("tr", "en", "")

/** Seçilebilir bir parça (ses, altyazı veya video kalitesi). */
data class TrackChoice(val label: String, val selection: TrackSelectionOverride?)

private fun langName(code: String?): String? {
    if (code.isNullOrBlank() || code == "und") return null
    val l = Locale.forLanguageTag(code)
    return l.getDisplayLanguage(Locale("tr")).takeIf { it.isNotBlank() }?.replaceFirstChar { it.uppercase() }
}

private fun audioLabel(f: Format, n: Int): String {
    val lang = langName(f.language) ?: f.label ?: "Ses $n"
    val ch = when (f.channelCount) {
        1 -> "Mono"; 2 -> "Stereo"; 6 -> "5.1"; 8 -> "7.1"; else -> null
    }
    return listOfNotNull(lang, ch).joinToString(" • ")
}

/** Dışarıdan eklenen altyazıların etiketi "Harici" ile başlar; olduğu gibi gösterilir. */
const val EXTERNAL_PREFIX = "Harici"

private fun subLabel(f: Format, n: Int): String {
    val label = f.label
    if (label != null && label.startsWith(EXTERNAL_PREFIX)) return label
    return langName(f.language) ?: label ?: "Altyazı $n"
}

private fun videoLabel(f: Format): String {
    val h = f.height
    val res = if (h > 0) "${h}p" else "Bilinmiyor"
    val kbps = if (f.bitrate > 0) " • ${f.bitrate / 1000} kb/s" else ""
    return res + kbps
}

/** Oynatıcının güncel parçalarından seçim listeleri. Seçili olanın indeksi de verilir. */
class TrackLists(
    val audio: List<TrackChoice>, val audioSel: Int,
    val subs: List<TrackChoice>, val subSel: Int,
    val video: List<TrackChoice>, val videoSel: Int,
) {
    companion object {
        val Empty = TrackLists(
            emptyList(), 0,
            listOf(TrackChoice("Kapalı", null)), 0,
            listOf(TrackChoice("Otomatik", null)), 0,
        )
    }
}

fun buildTrackLists(tracks: Tracks, player: Player): TrackLists {
    val audio = ArrayList<TrackChoice>()
    var audioSel = 0
    val subs = arrayListOf(TrackChoice("Kapalı", null))
    var subSel = 0
    val video = ArrayList<TrackChoice>()
    var videoSelOverride: TrackSelectionOverride? = null

    val params = player.trackSelectionParameters
    val textDisabled = params.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
    val forcedVideo = params.overrides.values.firstOrNull { it.type == C.TRACK_TYPE_VIDEO }

    var a = 0
    var s = 0
    for (g in tracks.groups) {
        when (g.type) {
            C.TRACK_TYPE_AUDIO -> for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                a++
                if (g.isTrackSelected(i)) audioSel = audio.size
                audio.add(TrackChoice(audioLabel(g.getTrackFormat(i), a), TrackSelectionOverride(g.mediaTrackGroup, i)))
            }

            C.TRACK_TYPE_TEXT -> for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                s++
                if (!textDisabled && g.isTrackSelected(i)) subSel = subs.size
                subs.add(TrackChoice(subLabel(g.getTrackFormat(i), s), TrackSelectionOverride(g.mediaTrackGroup, i)))
            }

            C.TRACK_TYPE_VIDEO -> for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                val ov = TrackSelectionOverride(g.mediaTrackGroup, i)
                if (forcedVideo != null && g.isTrackSelected(i)) videoSelOverride = ov
                video.add(TrackChoice(videoLabel(g.getTrackFormat(i)), ov))
            }
        }
    }
    val sortedVideo = listOf(TrackChoice("Otomatik", null)) + video.sortedByDescending {
        it.label.substringBefore("p").toIntOrNull() ?: 0
    }
    val videoSel = if (forcedVideo == null) 0
    else sortedVideo.indexOfFirst { it.selection != null && it.selection == videoSelOverride }.coerceAtLeast(0)

    return TrackLists(audio, audioSel, subs, subSel, sortedVideo, videoSel)
}

fun applyTrackChoice(player: Player, type: Int, choice: TrackChoice) {
    val b = player.trackSelectionParameters.buildUpon()
    b.clearOverridesOfType(type)
    if (type == C.TRACK_TYPE_TEXT) {
        if (choice.selection == null) {
            b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
        } else {
            b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).addOverride(choice.selection)
        }
    } else if (choice.selection != null) {
        b.addOverride(choice.selection)
    }
    player.trackSelectionParameters = b.build()
}

enum class PanelPage { Main, Audio, Subs, Quality, Resize, SubStyle, Speed, OnlineSub }

@Composable
fun PlayerSettingsPanel(
    startPage: PanelPage,
    tracks: TrackLists,
    settings: PlayerSettings,
    speedIndex: Int,
    isLive: Boolean,
    keys: ApiKeys,
    searchDefault: String,
    onSettings: (PlayerSettings) -> Unit,
    onSpeed: (Int) -> Unit,
    onAudio: (TrackChoice) -> Unit,
    onSub: (TrackChoice) -> Unit,
    onQuality: (TrackChoice) -> Unit,
    onPickLocalSub: () -> Unit,
    onSearch: suspend (provider: String, query: String, lang: String) -> List<SubResult>,
    onDownload: suspend (SubResult) -> String?,
    onClose: () -> Unit,
) {
    var page by remember(startPage) { mutableStateOf(startPage) }

    Column(
        Modifier
            .fillMaxHeight()
            .width(340.dp)
            .background(Color(0xF012121A))
            .pointerInput(Unit) { detectTapGestures { } }
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (page != PanelPage.Main) {
                IconButton(onClick = { page = PanelPage.Main }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri", tint = Color.White)
                }
            }
            Text(
                when (page) {
                    PanelPage.Main -> "Ayarlar"
                    PanelPage.Audio -> "Ses"
                    PanelPage.Subs -> "Altyazı"
                    PanelPage.Quality -> "Video kalitesi"
                    PanelPage.Resize -> "Ekran boyutu"
                    PanelPage.SubStyle -> "Altyazı görünümü"
                    PanelPage.Speed -> "Oynatma hızı"
                    PanelPage.OnlineSub -> "Online altyazı ara"
                },
                color = Color.White, fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f),
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.Close, contentDescription = "Kapat", tint = Color.White)
            }
        }

        when (page) {
            PanelPage.Main -> LazyColumn {
                item { MenuRow("Ekran boyutu", ResizeLabels[settings.resize]) { page = PanelPage.Resize } }
                if (!isLive) item { MenuRow("Oynatma hızı", SpeedLabels[speedIndex]) { page = PanelPage.Speed } }
                item { MenuRow("Ses", tracks.audio.getOrNull(tracks.audioSel)?.label ?: "Yok") { page = PanelPage.Audio } }
                item { MenuRow("Altyazı", tracks.subs.getOrNull(tracks.subSel)?.label ?: "Kapalı") { page = PanelPage.Subs } }
                item {
                    MenuRow("Video kalitesi", tracks.video.getOrNull(tracks.videoSel)?.label ?: "Otomatik") {
                        page = PanelPage.Quality
                    }
                }
                item { MenuRow("Altyazı görünümü", "Boyut, renk, arka plan") { page = PanelPage.SubStyle } }
            }

            PanelPage.Resize -> OptionList(ResizeLabels, settings.resize) { onSettings(settings.copy(resize = it)) }

            PanelPage.Speed -> OptionList(SpeedLabels, speedIndex) { onSpeed(it) }

            PanelPage.Audio -> if (tracks.audio.isEmpty()) {
                Note("Bu yayında seçilebilir ses parçası yok.")
            } else {
                OptionList(tracks.audio.map { it.label }, tracks.audioSel) { onAudio(tracks.audio[it]) }
            }

            PanelPage.Subs -> LazyColumn {
                items(tracks.subs.indices.toList()) { i ->
                    OptionRow(tracks.subs[i].label, i == tracks.subSel) { onSub(tracks.subs[i]) }
                }
                item { MenuRow("Cihazdan altyazı ekle", ".srt, .vtt, .ass dosyası seç") { onPickLocalSub() } }
                item { MenuRow("Online altyazı ara", "SubDL, OpenSubtitles") { page = PanelPage.OnlineSub } }
            }

            PanelPage.Quality -> if (tracks.video.size <= 2) {
                Note(if (isLive) "Bu kanal tek kalitede yayın yapıyor." else "Bu yayında seçilebilir kalite yok.")
            } else {
                OptionList(tracks.video.map { it.label }, tracks.videoSel) { onQuality(tracks.video[it]) }
            }

            PanelPage.SubStyle -> LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { Chips("Boyut", SubSizeLabels, settings.subSize) { onSettings(settings.copy(subSize = it)) } }
                item { Chips("Yazı rengi", SubColorLabels, settings.subColor) { onSettings(settings.copy(subColor = it)) } }
                item { Chips("Arka plan", SubBgLabels, settings.subBg) { onSettings(settings.copy(subBg = it)) } }
                item { Chips("Kenar", SubEdgeLabels, settings.subEdge) { onSettings(settings.copy(subEdge = it)) } }
                item {
                    Text(
                        "Örnek altyazı metni",
                        color = Color(SubColors[settings.subColor]),
                        fontSize = SubSizeSp[settings.subSize].sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(SubBgColors[settings.subBg]))
                            .padding(8.dp),
                    )
                }
            }

            PanelPage.OnlineSub -> OnlineSubPage(keys, searchDefault, onSearch, onDownload)
        }
    }
}

@Composable
private fun OnlineSubPage(
    keys: ApiKeys,
    defaultQuery: String,
    onSearch: suspend (String, String, String) -> List<SubResult>,
    onDownload: suspend (SubResult) -> String?,
) {
    val providers = buildList {
        if (keys.subdl.isNotBlank()) add("subdl" to "SubDL")
        if (keys.osKey.isNotBlank() && keys.osUser.isNotBlank() && keys.osPass.isNotBlank()) {
            add("os" to "OpenSubtitles")
        }
    }
    if (providers.isEmpty()) {
        Note(
            "Online arama için ana sayfadaki Ayarlar > Altyazı servisleri bölümüne SubDL API anahtarı " +
                "(veya OpenSubtitles anahtarı + kullanıcı adı + şifre) ekleyin."
        )
        return
    }

    var query by remember { mutableStateOf(defaultQuery) }
    var prov by remember { mutableIntStateOf(0) }
    var lang by remember { mutableIntStateOf(0) }
    var results by remember { mutableStateOf<List<SubResult>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            label = { Text("Film / dizi adı") }, modifier = Modifier.fillMaxWidth(),
        )
        if (providers.size > 1) Chips("Servis", providers.map { it.second }, prov) { prov = it }
        Chips("Dil", LangLabels, lang) { lang = it }
        Button(
            enabled = !busy && query.isNotBlank(),
            onClick = {
                scope.launch {
                    busy = true
                    status = null
                    try {
                        results = onSearch(providers[prov.coerceAtMost(providers.lastIndex)].first, query.trim(), LangCodes[lang])
                        if (results.isEmpty()) status = "Sonuç bulunamadı."
                    } catch (e: Exception) {
                        results = emptyList()
                        status = e.message ?: "Arama başarısız"
                    }
                    busy = false
                }
            },
            modifier = Modifier.fillMaxWidth(),
        ) {
            if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
            else Text("Ara")
        }
        status?.let { Text(it, color = Color(0xFFB39DFF), fontSize = 13.sp) }

        LazyColumn(Modifier.weight(1f, fill = false)) {
            items(results) { r ->
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clickable(enabled = !busy) {
                            scope.launch {
                                busy = true
                                status = "İndiriliyor..."
                                val err = onDownload(r)
                                status = err ?: "Altyazı eklendi ve seçildi."
                                busy = false
                            }
                        }
                        .padding(vertical = 8.dp),
                ) {
                    Text(r.name, color = Color.White, fontSize = 13.sp, maxLines = 2)
                    Text(r.lang.uppercase(), color = Color.Gray, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun MenuRow(title: String, value: String, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp)) {
        Text(title, color = Color.White, fontWeight = FontWeight.Medium)
        Text(value, color = Color(0xFFB39DFF), fontSize = 13.sp)
    }
}

@Composable
private fun OptionRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            label,
            color = if (selected) Color(0xFFB39DFF) else Color.White,
            modifier = Modifier.weight(1f),
        )
        if (selected) Icon(Icons.Filled.Check, contentDescription = null, tint = Color(0xFFB39DFF))
    }
}

@Composable
private fun OptionList(labels: List<String>, selected: Int, onPick: (Int) -> Unit) {
    LazyColumn {
        items(labels.indices.toList()) { i -> OptionRow(labels[i], i == selected) { onPick(i) } }
    }
}

@Composable
private fun Chips(title: String, labels: List<String>, selected: Int, onPick: (Int) -> Unit) {
    Column {
        Text(title, color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(labels.indices.toList()) { i ->
                FilterChip(selected = i == selected, onClick = { onPick(i) }, label = { Text(labels[i]) })
            }
        }
    }
}

@Composable
private fun Note(text: String) {
    Text(text, color = Color.Gray, modifier = Modifier.padding(vertical = 16.dp))
}
