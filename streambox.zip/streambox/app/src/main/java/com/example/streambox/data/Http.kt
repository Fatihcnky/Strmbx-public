package com.example.streambox.data

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object Http {
    const val UA = "Mozilla/5.0 (Linux; Android 13) StreamBox/1.0"

    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(45, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    /** @return (HTTP kodu, gövde). Başarısız kodlarda istisna fırlatmaz; çağıran karar verir. */
    fun getRaw(url: String, headers: Map<String, String> = emptyMap()): Pair<Int, String> {
        val b = Request.Builder().url(url).header("User-Agent", UA)
        headers.forEach { (k, v) -> b.header(k, v) }
        client.newCall(b.build()).execute().use { resp ->
            return resp.code to (resp.body?.string() ?: "")
        }
    }

    fun get(url: String): String {
        val req = Request.Builder().url(url).header("User-Agent", UA).build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) error("Sunucu hata döndürdü (HTTP ${resp.code})")
            return resp.body?.string() ?: ""
        }
    }
}

/** JSON değeri string/number/null olabilir; boş ve "null" değerleri null sayılır. */
fun JsonElement?.str(): String? =
    (this as? JsonPrimitive)?.contentOrNull?.takeIf { it.isNotBlank() && it != "null" }

fun JsonObject.s(key: String): String? = this[key].str()
