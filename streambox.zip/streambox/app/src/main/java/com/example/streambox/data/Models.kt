package com.example.streambox.data

import kotlinx.serialization.Serializable

@Serializable
enum class AccountType { XTREAM, M3U }

@Serializable
data class Account(
    val type: AccountType,
    val name: String = "",
    val server: String = "",
    val username: String = "",
    val password: String = "",
    val m3uUrl: String = "",
    val epgUrl: String = "",
    val liveExt: String = "m3u8",
)

@Serializable
data class Category(val id: String, val name: String)

@Serializable
data class LiveChannel(
    val id: String,
    val name: String,
    val logo: String?,
    val categoryId: String,
    val url: String,
    val epgId: String?,
    val streamId: String?,
)

@Serializable
data class Movie(
    val id: String,
    val name: String,
    val poster: String?,
    val categoryId: String,
    val url: String,
    val rating: String?,
    val plot: String? = null,
    val year: String? = null,
)

@Serializable
data class Series(
    val id: String,
    val name: String,
    val poster: String?,
    val categoryId: String,
    val rating: String?,
    val plot: String?,
    val year: String? = null,
)

data class Episode(
    val id: String,
    val season: Int,
    val number: Int,
    val title: String,
    val url: String,
    val image: String?,
)

data class EpgItem(
    val title: String,
    val description: String,
    val startMs: Long,
    val endMs: Long,
)

@Serializable
data class Catalog(
    val liveCategories: List<Category> = emptyList(),
    val live: List<LiveChannel> = emptyList(),
    val movieCategories: List<Category> = emptyList(),
    val movies: List<Movie> = emptyList(),
    val seriesCategories: List<Category> = emptyList(),
    val series: List<Series> = emptyList(),
    val epgUrl: String? = null,
    /** Bölüm adı ("live", "movies", "series") -> yükleme hatası. */
    val errors: Map<String, String> = emptyMap(),
    /** Hâlâ arka planda yüklenen bölümler. */
    val pending: Set<String> = emptySet(),
    /** Gizlenenler dahil tüm kategoriler (içerik seçimi ekranı için). */
    val allLiveCategories: List<Category> = emptyList(),
    val allMovieCategories: List<Category> = emptyList(),
    val allSeriesCategories: List<Category> = emptyList(),
    /** "live:ID" / "movies:ID" / "series:ID" -> öğe sayısı (hangi yenileme yönteminin hızlı olacağını seçmek için). */
    val categorySizes: Map<String, Int> = emptyMap(),
)

/** Kullanıcının gizlediği kategori kimlikleri. Gizlenenler listeden çıkarılır, mümkünse yenilemede hiç indirilmez. */
@Serializable
data class ContentFilter(
    val hiddenLive: Set<String> = emptySet(),
    val hiddenMovies: Set<String> = emptySet(),
    val hiddenSeries: Set<String> = emptySet(),
) {
    val isEmpty get() = hiddenLive.isEmpty() && hiddenMovies.isEmpty() && hiddenSeries.isEmpty()
}

fun Catalog.applyFilter(f: ContentFilter): Catalog = if (f.isEmpty) this else copy(
    liveCategories = liveCategories.filter { it.id !in f.hiddenLive },
    live = live.filter { it.categoryId !in f.hiddenLive },
    movieCategories = movieCategories.filter { it.id !in f.hiddenMovies },
    movies = movies.filter { it.categoryId !in f.hiddenMovies },
    seriesCategories = seriesCategories.filter { it.id !in f.hiddenSeries },
    series = series.filter { it.categoryId !in f.hiddenSeries },
)

/** Oynatıcı ayarları; her alan ilgili seçenek listesinin indeksidir. */
data class PlayerSettings(
    val resize: Int = 0, // 0 En uygun (otomatik), 1 Sığdır, 2 Uzat, 3 Doldur
    val subSize: Int = 1,
    val subColor: Int = 0,
    val subBg: Int = 1,
    val subEdge: Int = 2,
)

/** Kullanıcının girdiği isteğe bağlı servis anahtarları (yalnızca cihazda saklanır). */
data class ApiKeys(
    val subdl: String = "",
    val osKey: String = "",
    val osUser: String = "",
    val osPass: String = "",
    val omdb: String = "",
    val tmdb: String = "",
)

/** Oynatıcıya verilen tek bir öğe (kanal, film, bölüm veya cihazdaki dosya). */
data class PlayItem(
    val kind: String, // "live" | "movie" | "episode" | "local"
    val key: String,
    val title: String,
    val subtitle: String?,
    val image: String?,
    val url: String,
    val epgId: String? = null,
    val streamId: String? = null,
)

data class PlayRequest(
    val items: List<PlayItem>,
    val index: Int,
    val startMs: Long = 0L,
)

fun LiveChannel.toPlayItem() = PlayItem(
    kind = "live", key = url, title = name, subtitle = null,
    image = logo, url = url, epgId = epgId, streamId = streamId,
)
