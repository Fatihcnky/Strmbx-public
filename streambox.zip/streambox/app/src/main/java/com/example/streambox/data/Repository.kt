package com.example.streambox.data

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.SocketTimeoutException
import java.net.UnknownHostException

object Repository {

    fun describe(t: Throwable): String = when (t) {
        is OutOfMemoryError -> "liste çok büyük, bellek yetersiz"
        is SocketTimeoutException -> "zaman aşımı (bağlantı yavaş)"
        is UnknownHostException -> "sunucuya ulaşılamadı"
        else -> t.message ?: t.javaClass.simpleName
    }

    /** Gizlenen kategoriler toplam içeriğin bu oranından fazlasını tutuyorsa kategori kategori indirmek daha hızlıdır. */
    private const val PER_CATEGORY_MIN_SAVING = 0.25
    private const val PARALLEL_CATEGORY_FETCH = 4

    /** Bu bölümde gizlenenler biliniyorsa ne kadar veriyi atlayacağımızın tahmini (0..1). */
    private fun savingEstimate(prefix: String, hidden: Set<String>, sizes: Map<String, Int>): Double {
        if (hidden.isEmpty()) return 0.0
        val all = sizes.filterKeys { it.startsWith("$prefix:") }
        val total = all.values.sum()
        if (total <= 0) return 0.0
        val skipped = hidden.sumOf { all["$prefix:$it"] ?: 0 }
        return skipped.toDouble() / total
    }

    /**
     * Bir bölümü indirir. Gizli kategori varsa ve atlanacak veri yeterince büyükse yalnızca görünen kategoriler
     * tek tek (paralel) indirilir; aksi halde tek istekle indirilip gizliler ayıklanır.
     * @return (görünen öğeler, bilinen kategori boyutları)
     */
    private suspend fun <T> fetchSection(
        prefix: String,
        cats: List<Category>,
        hidden: Set<String>,
        sizes: Map<String, Int>,
        all: () -> List<T>,
        byCategory: (String) -> List<T>,
        categoryOf: (T) -> String,
    ): Pair<List<T>, Map<String, Int>> {
        val visible = cats.filter { it.id !in hidden }
        val perCategory = hidden.isNotEmpty() && visible.isNotEmpty() &&
            savingEstimate(prefix, hidden, sizes) >= PER_CATEGORY_MIN_SAVING
        if (perCategory) {
            val gate = kotlinx.coroutines.sync.Semaphore(PARALLEL_CATEGORY_FETCH)
            val parts = coroutineScope {
                visible.map { c ->
                    async {
                        gate.acquire()
                        try {
                            c.id to runCatching { byCategory(c.id) }.getOrNull()
                        } finally {
                            gate.release()
                        }
                    }
                }.map { it.await() }
            }
            // Hiçbiri gelmediyse (sunucu kategori filtresini desteklemiyor olabilir) tek istekle dene
            if (parts.any { it.second != null }) {
                val list = parts.flatMap { it.second.orEmpty() }
                val newSizes = sizes + parts.filter { it.second != null }.associate { "$prefix:${it.first}" to it.second!!.size }
                return list to newSizes
            }
        }
        val list = all()
        val counts = list.groupingBy(categoryOf).eachCount().mapKeys { "$prefix:${it.key}" }
        val newSizes = sizes.filterKeys { !it.startsWith("$prefix:") } + counts
        return list.filter { categoryOf(it) !in hidden } to newSizes
    }

    /**
     * Kataloğu yükler. Xtream'de canlı TV, filmler ve diziler birbirinden bağımsız ve
     * paralel yüklenir; her biri bitince [onUpdate] güncel kataloğu verir (IO thread'inde).
     * [filter]deki gizli kategoriler listeye alınmaz; mümkünse hiç indirilmez.
     */
    suspend fun load(
        acc: Account,
        filter: ContentFilter,
        prev: Catalog?,
        onUpdate: (Catalog) -> Unit,
    ): Catalog = withContext(Dispatchers.IO) {
        if (acc.type == AccountType.M3U) {
            val c = M3uParser.load(acc)
            // M3U'da kategoriler grup adlarıdır; dosya zaten tümüyle iner, gizlenenler ayıklanır
            c.copy(
                allLiveCategories = c.liveCategories,
                allMovieCategories = c.movieCategories,
                allSeriesCategories = c.seriesCategories,
            ).applyFilter(filter).also(onUpdate)
        } else {
            val api = XtreamApi(acc)
            if (!api.authenticate()) {
                error("Giriş başarısız. Sunucu adresini, kullanıcı adını ve şifreyi kontrol edin.")
            }

            val lock = Any()
            var cat = Catalog(
                epgUrl = acc.epgUrl.trim().ifBlank { api.xmltvUrl() },
                pending = setOf("live", "movies", "series"),
                categorySizes = prev?.categorySizes.orEmpty(),
                allLiveCategories = prev?.allLiveCategories.orEmpty(),
                allMovieCategories = prev?.allMovieCategories.orEmpty(),
                allSeriesCategories = prev?.allSeriesCategories.orEmpty(),
            )

            fun push(f: (Catalog) -> Catalog) {
                synchronized(lock) {
                    cat = f(cat)
                    onUpdate(cat)
                }
            }

            fun done(name: String, f: (Catalog) -> Catalog) =
                push { c -> f(c).let { it.copy(pending = it.pending - name) } }

            fun fail(name: String, t: Throwable) =
                push { it.copy(pending = it.pending - name, errors = it.errors + (name to describe(t))) }

            push { it }
            val sizes0 = prev?.categorySizes.orEmpty()

            coroutineScope {
                launch {
                    try {
                        val cats = runCatching { api.categories("get_live_categories") }.getOrDefault(emptyList())
                        val (list, sizes) = fetchSection(
                            "live", cats, filter.hiddenLive, sizes0,
                            all = { api.liveStreams() }, byCategory = { api.liveStreams(it) }, categoryOf = { it.categoryId },
                        )
                        done("live") {
                            it.copy(
                                liveCategories = cats.filter { c -> c.id !in filter.hiddenLive }, live = list,
                                allLiveCategories = cats, categorySizes = it.categorySizes.replaceSection("live", sizes),
                            )
                        }
                    } catch (t: Throwable) {
                        if (t is CancellationException) throw t
                        fail("live", t)
                    }
                }
                launch {
                    try {
                        val cats = runCatching { api.categories("get_vod_categories") }.getOrDefault(emptyList())
                        val (list, sizes) = try {
                            fetchSection(
                                "movies", cats, filter.hiddenMovies, sizes0,
                                all = { api.movies() }, byCategory = { api.movies(it) }, categoryOf = { it.categoryId },
                            )
                        } catch (t: Throwable) {
                            if (t is CancellationException || cats.isEmpty()) throw t
                            // Tek seferde indirilemediyse kategori kategori dene
                            val parts = cats.filter { it.id !in filter.hiddenMovies }
                                .flatMap { c -> runCatching { api.movies(c.id) }.getOrDefault(emptyList()) }
                            if (parts.isEmpty()) throw t
                            parts to sizes0
                        }
                        done("movies") {
                            it.copy(
                                movieCategories = cats.filter { c -> c.id !in filter.hiddenMovies }, movies = list,
                                allMovieCategories = cats, categorySizes = it.categorySizes.replaceSection("movies", sizes),
                            )
                        }
                    } catch (t: Throwable) {
                        if (t is CancellationException) throw t
                        fail("movies", t)
                    }
                }
                launch {
                    try {
                        val cats = runCatching { api.categories("get_series_categories") }.getOrDefault(emptyList())
                        val (list, sizes) = try {
                            fetchSection(
                                "series", cats, filter.hiddenSeries, sizes0,
                                all = { api.series() }, byCategory = { api.series(it) }, categoryOf = { it.categoryId },
                            )
                        } catch (t: Throwable) {
                            if (t is CancellationException || cats.isEmpty()) throw t
                            val parts = cats.filter { it.id !in filter.hiddenSeries }
                                .flatMap { c -> runCatching { api.series(c.id) }.getOrDefault(emptyList()) }
                            if (parts.isEmpty()) throw t
                            parts to sizes0
                        }
                        done("series") {
                            it.copy(
                                seriesCategories = cats.filter { c -> c.id !in filter.hiddenSeries }, series = list,
                                allSeriesCategories = cats, categorySizes = it.categorySizes.replaceSection("series", sizes),
                            )
                        }
                    } catch (t: Throwable) {
                        if (t is CancellationException) throw t
                        fail("series", t)
                    }
                }
            }
            cat
        }
    }

    /** [sizes] içindeki yalnızca bu bölümün ("live:" vb.) girdilerini mevcut tabloya işler. */
    private fun Map<String, Int>.replaceSection(prefix: String, sizes: Map<String, Int>): Map<String, Int> =
        filterKeys { !it.startsWith("$prefix:") } + sizes.filterKeys { it.startsWith("$prefix:") }
}
