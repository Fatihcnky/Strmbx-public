package com.example.streambox.data

import android.net.Uri
import android.util.Base64
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject

/** Xtream Codes (player_api.php) istemcisi. Tüm çağrılar bloklayıcıdır; IO thread'inde kullanın. */
class XtreamApi(private val acc: Account) {

    private val base = acc.server.trim().trimEnd('/').let {
        if (it.startsWith("http://") || it.startsWith("https://")) it else "http://$it"
    }
    private val u = Uri.encode(acc.username.trim())
    private val p = Uri.encode(acc.password.trim())

    private fun api(action: String? = null, extra: String = ""): String =
        "$base/player_api.php?username=$u&password=$p" +
            (if (action != null) "&action=$action" else "") + extra

    private fun array(url: String): JsonArray =
        Http.json.parseToJsonElement(Http.get(url)) as? JsonArray ?: JsonArray(emptyList())

    fun xmltvUrl(): String = "$base/xmltv.php?username=$u&password=$p"

    fun authenticate(): Boolean {
        val root = Http.json.parseToJsonElement(Http.get(api())) as? JsonObject ?: return false
        val info = root["user_info"] as? JsonObject ?: return false
        return info.s("auth") == "1"
    }

    fun categories(action: String): List<Category> =
        array(api(action)).mapNotNull { el ->
            val o = el as? JsonObject ?: return@mapNotNull null
            val id = o.s("category_id") ?: return@mapNotNull null
            Category(id, o.s("category_name") ?: id)
        }

    fun liveStreams(categoryId: String? = null): List<LiveChannel> =
        array(api("get_live_streams", categoryId?.let { "&category_id=$it" } ?: "")).mapNotNull { el ->
            val o = el as? JsonObject ?: return@mapNotNull null
            val sid = o.s("stream_id") ?: return@mapNotNull null
            LiveChannel(
                id = sid,
                name = o.s("name") ?: "Kanal $sid",
                logo = o.s("stream_icon"),
                categoryId = o.s("category_id") ?: "",
                url = "$base/live/$u/$p/$sid.${acc.liveExt}",
                epgId = o.s("epg_channel_id"),
                streamId = sid,
            )
        }

    fun movies(categoryId: String? = null): List<Movie> =
        array(api("get_vod_streams", categoryId?.let { "&category_id=$it" } ?: "")).mapNotNull { el ->
            val o = el as? JsonObject ?: return@mapNotNull null
            val sid = o.s("stream_id") ?: return@mapNotNull null
            val ext = o.s("container_extension") ?: "mp4"
            Movie(
                id = sid,
                name = o.s("name") ?: "Film $sid",
                poster = o.s("stream_icon"),
                categoryId = o.s("category_id") ?: "",
                url = "$base/movie/$u/$p/$sid.$ext",
                rating = o.s("rating") ?: o.s("rating_5based")?.toDoubleOrNull()?.times(2)?.toString(),
                year = (o.s("year") ?: o.s("releasedate") ?: o.s("release_date"))?.take(4),
            )
        }

    fun series(categoryId: String? = null): List<Series> =
        array(api("get_series", categoryId?.let { "&category_id=$it" } ?: "")).mapNotNull { el ->
            val o = el as? JsonObject ?: return@mapNotNull null
            val sid = o.s("series_id") ?: return@mapNotNull null
            Series(
                id = sid,
                name = o.s("name") ?: "Dizi $sid",
                poster = o.s("cover"),
                categoryId = o.s("category_id") ?: "",
                rating = o.s("rating") ?: o.s("rating_5based")?.toDoubleOrNull()?.times(2)?.toString(),
                plot = o.s("plot"),
                year = (o.s("year") ?: o.s("releaseDate") ?: o.s("release_date"))?.take(4),
            )
        }

    /** Film detayı. [name]: sağlayıcının bu kayıt için bildirdiği ad (listedeki adla uyuşmazlığı yakalamak için). */
    fun vodInfo(vodId: String): VodInfo? {
        val root = Http.json.parseToJsonElement(Http.get(api("get_vod_info", "&vod_id=$vodId"))) as? JsonObject ?: return null
        val info = root["info"] as? JsonObject
        val data = root["movie_data"] as? JsonObject
        val plot = info?.s("plot") ?: info?.s("description")
        val year = (info?.s("releasedate") ?: info?.s("release_date"))?.take(4)
        val name = data?.s("name") ?: info?.s("name") ?: info?.s("o_name")
        return VodInfo(plot, year, name)
    }

    /** Sezon numarası -> bölümler. */
    fun seriesEpisodes(seriesId: String): Map<Int, List<Episode>> {
        val root = Http.json.parseToJsonElement(Http.get(api("get_series_info", "&series_id=$seriesId"))) as? JsonObject
            ?: return emptyMap()
        val eps = root["episodes"]
        val seasons: List<Pair<String, JsonArray>> = when (eps) {
            is JsonObject -> eps.entries.mapNotNull { (k, v) -> (v as? JsonArray)?.let { k to it } }
            is JsonArray -> eps.mapIndexedNotNull { i, v -> (v as? JsonArray)?.let { (i + 1).toString() to it } }
            else -> emptyList()
        }
        val out = sortedMapOf<Int, List<Episode>>()
        for ((key, arr) in seasons) {
            val list = arr.mapIndexedNotNull { idx, el ->
                val o = el as? JsonObject ?: return@mapIndexedNotNull null
                val id = o.s("id") ?: return@mapIndexedNotNull null
                val number = o.s("episode_num")?.toIntOrNull() ?: (idx + 1)
                val season = key.toIntOrNull() ?: o.s("season")?.toIntOrNull() ?: 1
                val ext = o.s("container_extension") ?: "mp4"
                Episode(
                    id = id,
                    season = season,
                    number = number,
                    title = o.s("title") ?: "Bölüm $number",
                    url = "$base/series/$u/$p/$id.$ext",
                    image = (o["info"] as? JsonObject)?.s("movie_image"),
                )
            }.sortedBy { it.number }
            if (list.isNotEmpty()) out[key.toIntOrNull() ?: list.first().season] = list
        }
        return out
    }

    fun shortEpg(streamId: String): List<EpgItem> {
        val root = Http.json.parseToJsonElement(
            Http.get(api("get_short_epg", "&stream_id=$streamId&limit=8"))
        ) as? JsonObject ?: return emptyList()
        val arr = root["epg_listings"] as? JsonArray ?: return emptyList()
        return arr.mapNotNull { el ->
            val o = el as? JsonObject ?: return@mapNotNull null
            val start = o.s("start_timestamp")?.toLongOrNull() ?: return@mapNotNull null
            val stop = o.s("stop_timestamp")?.toLongOrNull() ?: return@mapNotNull null
            EpgItem(
                title = decode(o.s("title")),
                description = decode(o.s("description")),
                startMs = start * 1000,
                endMs = stop * 1000,
            )
        }
    }

    private fun decode(s: String?): String {
        if (s == null) return ""
        return try {
            String(Base64.decode(s, Base64.DEFAULT), Charsets.UTF_8)
        } catch (_: Exception) {
            s
        }
    }
}

class VodInfo(val plot: String?, val year: String?, val name: String?)
