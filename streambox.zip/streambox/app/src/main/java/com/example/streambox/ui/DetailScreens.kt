package com.example.streambox.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.streambox.AppViewModel
import com.example.streambox.data.Episode
import com.example.streambox.data.Ratings
import com.example.streambox.data.PlayItem
import com.example.streambox.data.PlayRequest

@Composable
private fun DetailHeader(title: String, image: String?, onBack: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(380.dp).background(Surface1)) {
        if (!image.isNullOrBlank()) {
            AsyncImage(
                model = image, contentDescription = null,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize(),
            )
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.5f), Color.Transparent, Bg))
            )
        )
        IconButton(onClick = onBack, modifier = Modifier.statusBarsPadding().padding(8.dp)) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
        }
        Text(
            title,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.BottomStart).padding(16.dp),
        )
    }
}

@Composable
fun MovieDetailScreen(vm: AppViewModel, nav: NavController) {
    val movie = vm.selectedMovie
    if (movie == null) {
        LaunchedEffect(Unit) { nav.popBackStack() }
        return
    }
    var plot by remember(movie) { mutableStateOf(movie.plot) }
    var year by remember(movie) { mutableStateOf(movie.year) }
    var panelName by remember(movie) { mutableStateOf<String?>(null) }
    LaunchedEffect(movie) {
        runCatching { vm.movieInfo(movie) }.getOrNull()?.let { info ->
            if (info.plot != null) plot = info.plot
            if (info.year != null) year = info.year
            panelName = info.name
        }
    }

    val favs by vm.favorites.collectAsStateWithLifecycle()
    val hist by vm.history.collectAsStateWithLifecycle()
    val isFav = favs.any { it.itemKey == movie.url }
    val resume = hist.firstOrNull {
        it.itemKey == movie.url && it.durationMs > 0 && it.positionMs > 10_000 && it.positionMs < it.durationMs * 0.95
    }

    fun play(startMs: Long) {
        vm.playRequest = PlayRequest(
            listOf(PlayItem("movie", movie.url, movie.name, null, movie.poster, movie.url)),
            0, startMs,
        )
        nav.navigate("player")
    }

    LazyColumn(Modifier.fillMaxSize().background(Bg), contentPadding = PaddingValues(bottom = 32.dp)) {
        item { DetailHeader(movie.name, movie.poster) { nav.popBackStack() } }
        item {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                val shown = rememberRating(movie.name, movie.rating, "movie")
                val meta = listOfNotNull(year, shown?.let(::ratingLabel)).joinToString("  •  ")
                if (meta.isNotBlank()) Text(meta, color = Color.Gray)
                // Sağlayıcının bu kayıt için bildirdiği ad listedeki adla uyuşmuyorsa uyar (hatalı kayıt olabilir)
                val pn = panelName
                if (pn != null && Ratings.norm(pn) != Ratings.norm(movie.name) &&
                    Ratings.norm(Ratings.clean(pn).first) != Ratings.norm(Ratings.clean(movie.name).first)
                ) {
                    Text(
                        "Dikkat: sağlayıcı bu kaydı \"$pn\" olarak bildiriyor; listedeki ad farklı. Listenizde hatalı eşleşmiş olabilir. (Kayıt no: ${movie.id})",
                        color = Color(0xFFFFB74D), style = MaterialTheme.typography.bodySmall,
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { play(resume?.positionMs ?: 0L) }) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(if (resume != null) "Devam Et" else "Oynat")
                    }
                    if (resume != null) {
                        OutlinedButton(onClick = { play(0L) }) { Text("Baştan") }
                    }
                    OutlinedButton(
                        onClick = { vm.toggleFavorite(movie.url, "movie", movie.name, movie.poster) },
                    ) {
                        Icon(if (isFav) Icons.Filled.Check else Icons.Filled.Add, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(if (isFav) "Listemde" else "Listeme Ekle")
                    }
                }
                plot?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
            }
        }
    }
}

@Composable
fun SeriesDetailScreen(vm: AppViewModel, nav: NavController) {
    val series = vm.selectedSeries
    if (series == null) {
        LaunchedEffect(Unit) { nav.popBackStack() }
        return
    }

    var seasons by remember(series) { mutableStateOf<Map<Int, List<Episode>>?>(null) }
    var failed by remember(series) { mutableStateOf(false) }
    var season by remember(series) { mutableStateOf<Int?>(null) }

    LaunchedEffect(series) {
        runCatching { vm.seriesEpisodes(series) }
            .onSuccess { map ->
                seasons = map
                season = map.keys.firstOrNull()
            }
            .onFailure { failed = true }
    }

    val favs by vm.favorites.collectAsStateWithLifecycle()
    val key = "series:${series.id}"
    val isFav = favs.any { it.itemKey == key }

    fun playEpisode(list: List<Episode>, idx: Int) {
        val items = list.map { e ->
            PlayItem(
                kind = "episode",
                key = e.url,
                title = series.name,
                subtitle = "S${e.season} B${e.number} • ${e.title}",
                image = e.image ?: series.poster,
                url = e.url,
            )
        }
        vm.playRequest = PlayRequest(items, idx)
        nav.navigate("player")
    }

    LazyColumn(Modifier.fillMaxSize().background(Bg), contentPadding = PaddingValues(bottom = 32.dp)) {
        item { DetailHeader(series.name, series.poster) { nav.popBackStack() } }
        item {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                rememberRating(series.name, series.rating, "series")?.let { Text(ratingLabel(it), color = Color.Gray) }
                OutlinedButton(
                    onClick = { vm.toggleFavorite(key, "series", series.name, series.poster) },
                ) {
                    Icon(if (isFav) Icons.Filled.Check else Icons.Filled.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(if (isFav) "Listemde" else "Listeme Ekle")
                }
                series.plot?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
            }
        }

        val map = seasons
        when {
            failed -> item {
                Text(
                    "Bölümler yüklenemedi.",
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(16.dp),
                )
            }

            map == null -> item {
                Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }

            map.isEmpty() -> item {
                Text("Bu dizi için bölüm bulunamadı.", color = Color.Gray, modifier = Modifier.padding(16.dp))
            }

            else -> {
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        items(map.keys.toList()) { s ->
                            FilterChip(
                                selected = season == s,
                                onClick = { season = s },
                                label = { Text("Sezon $s") },
                            )
                        }
                    }
                }
                val eps = map[season].orEmpty()
                itemsIndexed(eps) { i, e ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { playEpisode(eps, i) }
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("${e.number}", color = Color.Gray, modifier = Modifier.width(32.dp))
                        Text(
                            e.title, modifier = Modifier.weight(1f),
                            maxLines = 2, overflow = TextOverflow.Ellipsis,
                        )
                        Icon(Icons.Filled.PlayArrow, contentDescription = "Oynat", modifier = Modifier.size(24.dp))
                    }
                }
            }
        }
    }
}
