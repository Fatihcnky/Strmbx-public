package com.example.streambox.ui

import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.streambox.AppViewModel
import com.example.streambox.data.Catalog
import com.example.streambox.data.Category
import com.example.streambox.data.EpgItem
import com.example.streambox.data.HistoryEntity
import com.example.streambox.data.LiveChannel
import com.example.streambox.data.Movie
import com.example.streambox.data.PlayItem
import com.example.streambox.data.PlayRequest
import com.example.streambox.data.Ratings
import com.example.streambox.data.Series
import com.example.streambox.data.toPlayItem
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay

private enum class Tab(val label: String, val icon: ImageVector) {
    Home("Ana Sayfa", Icons.Filled.Home),
    Live("Canlı TV", Icons.Filled.Tv),
    Movies("Filmler", Icons.Filled.Movie),
    Series("Diziler", Icons.Filled.VideoLibrary),
    MyList("Listem", Icons.Filled.Favorite),
}

/** Kartlara dokunulunca yapılacaklar (ana ekran ve "Daha fazla" ekranı ortak kullanır). */
internal fun buildActions(vm: AppViewModel, nav: NavController): Actions = Actions(
    onMovie = { m -> vm.selectedMovie = m; nav.navigate("movie") },
    onSeries = { s -> vm.selectedSeries = s; nav.navigate("series") },
    onLive = { list, idx ->
        vm.playRequest = PlayRequest(list.map { it.toPlayItem() }, idx)
        nav.navigate("player")
    },
    onResume = { h ->
        vm.playRequest = PlayRequest(
            listOf(PlayItem(h.kind, h.itemKey, h.title, null, h.image, h.url)),
            0, h.positionMs,
        )
        nav.navigate("player")
    },
)

@Composable
fun MainScreen(vm: AppViewModel, nav: NavController) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val ctx = LocalContext.current
    val catalog by vm.catalog.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val refreshing by vm.refreshing.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    val notice by vm.notice.collectAsStateWithLifecycle()
    val askRefresh by vm.askRefresh.collectAsStateWithLifecycle()
    val lastUpdated by vm.lastUpdated.collectAsStateWithLifecycle()
    val openLocal = rememberLocalVideoPicker(vm, nav)

    LaunchedEffect(notice) {
        notice?.let {
            Toast.makeText(ctx, it, Toast.LENGTH_LONG).show()
            vm.notice.value = null
        }
    }

    if (askRefresh) {
        val whenText = if (lastUpdated > 0) {
            SimpleDateFormat("d MMMM yyyy HH:mm", Locale("tr")).format(Date(lastUpdated))
        } else {
            "bilinmiyor"
        }
        AlertDialog(
            onDismissRequest = { vm.dismissRefresh() },
            title = { Text("Liste güncellensin mi?") },
            text = {
                Text(
                    "Kanallar, filmler ve diziler en son $whenText tarihinde güncellendi. " +
                        "Şimdi yeniden indirmek ister misin? Yavaş bağlantıda uzun sürebilir; " +
                        "güncellenirken eski liste kullanılmaya devam eder."
                )
            },
            confirmButton = { TextButton(onClick = { vm.confirmRefresh() }) { Text("Güncelle") } },
            dismissButton = { TextButton(onClick = { vm.dismissRefresh() }) { Text("Şimdi değil") } },
        )
    }

    val actions = remember(vm, nav) { buildActions(vm, nav) }

    Scaffold(
        containerColor = Bg,
        contentColor = Color.White,
        bottomBar = {
            NavigationBar(containerColor = Surface1) {
                Tab.values().forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label, fontSize = 10.sp, maxLines = 1) },
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            val cat = catalog
            when {
                cat == null && loading -> Column(
                    Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(12.dp))
                    Text("Liste yükleniyor...", color = Color.Gray)
                }

                cat == null -> Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(error ?: "Liste yüklenemedi", textAlign = TextAlign.Center)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { vm.loadCatalog() }) { Text("Tekrar dene") }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { nav.navigate("settings") }) { Text("Ayarlar") }
                }

                else -> when (Tab.values()[tab]) {
                    Tab.Home -> HomeTab(
                        vm, cat, actions, { nav.navigate("settings") }, openLocal,
                        onMore = { r -> vm.moreTitle = r.title; vm.moreTiles = r.tiles; nav.navigate("more") },
                    )
                    Tab.Live -> LiveTab(vm, cat, actions)
                    Tab.Movies -> BrowseTab(
                        hint = "Film ara",
                        categories = cat.movieCategories,
                        tiles = remember(cat.movies) { cat.movies.map { it.toTile() } },
                        emptyText = "Bu listede film bulunamadı.",
                        pending = "movies" in cat.pending,
                        errorText = cat.errors["movies"],
                        onRetry = { vm.loadCatalog() },
                        onClick = actions::handle,
                    )

                    Tab.Series -> BrowseTab(
                        hint = "Dizi ara",
                        categories = cat.seriesCategories,
                        tiles = remember(cat.series) { cat.series.map { it.toTile() } },
                        emptyText = "Bu listede dizi bulunamadı. Diziler yalnızca Xtream Codes girişinde listelenir.",
                        pending = "series" in cat.pending,
                        errorText = cat.errors["series"],
                        onRetry = { vm.loadCatalog() },
                        onClick = actions::handle,
                    )

                    Tab.MyList -> MyListTab(vm, cat, actions)
                }
            }

            if (refreshing) {
                LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter))
            }
        }
    }
}

internal fun Movie.toTile() = Tile(url, name, poster, categoryId, this)
internal fun Series.toTile() = Tile("series:$id", name, poster, categoryId, this)
internal fun LiveChannel.toTile() = Tile(url, name, logo, categoryId, this)
internal fun HistoryEntity.toTile() = Tile(
    itemKey, title, image, "", this,
    progress = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else null,
)

private fun isResumable(h: HistoryEntity) =
    h.durationMs > 0 && h.positionMs > 10_000 && h.positionMs < h.durationMs * 0.95

// ---------------------------------------------------------------- Ana sayfa

private const val ROW_PREVIEW = 20

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun HomeTab(
    vm: AppViewModel,
    cat: Catalog,
    actions: Actions,
    onSettings: () -> Unit,
    onOpenLocal: () -> Unit,
    onMore: (HomeRowData) -> Unit,
) {
    val hist by vm.history.collectAsStateWithLifecycle()
    val hidden by vm.homeHidden.collectAsStateWithLifecycle()
    val imdb by vm.imdb.collectAsStateWithLifecycle()
    val years by vm.years.collectAsStateWithLifecycle()
    val feeds by vm.feeds.collectAsStateWithLifecycle()
    val feedsLoading by vm.feedsLoading.collectAsStateWithLifecycle()
    val refreshing by vm.refreshing.collectAsStateWithLifecycle()

    // Ağır hesaplar (binlerce başlığı eşleştirme, puanlama) arka planda; ekran takılmaz.
    // Anahtarlar hızlı değişirse (liste yüklenirken) önceki hesap iptal olur, son durum hesaplanır.
    val model by produceState<HomeModel?>(null, cat, imdb, years, feeds, hidden) {
        kotlinx.coroutines.delay(250)
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
            HomeBuilder.build(cat, imdb, years, feeds, hidden)
        }
    }
    val m = model

    // Katalogdan eşleşen başlıkların puan/yılını kaydet (ek istek gerektirmez)
    LaunchedEffect(m) { m?.seeds?.forEach { vm.seedMeta(it.key, it.rating, it.year) } }

    // Öneri afişi: yeterli öğe oluşunca sabitlenir; puanlar geldikçe sürekli değişmez
    var hero by remember { mutableStateOf<List<HeroItem>>(emptyList()) }
    LaunchedEffect(m) {
        if (m != null && hero.size < 6 && m.hero.isNotEmpty()) hero = m.hero
    }

    val continueTiles = remember(hist) { hist.filter(::isResumable).map { it.toTile() } }

    val rows = remember(m) {
        if (m == null) emptyList() else buildList {
            addAll(m.feedRows)
            if (m.ratedMovies.isNotEmpty() && "rated_movies" !in hidden) add(HomeRowData("rated_movies", "Yüksek Puanlı Filmler (7.0+)", m.ratedMovies))
            if (m.ratedSeries.isNotEmpty() && "rated_series" !in hidden) add(HomeRowData("rated_series", "Yüksek Puanlı Diziler (7.0+)", m.ratedSeries))
            if (m.liveTiles.isNotEmpty() && "live" !in hidden) add(HomeRowData("live", "Canlı TV", m.liveTiles))
            addAll(m.movieRows)
            addAll(m.seriesRows)
        }
    }

    // Satırlar kademeli eklenir: altına inildikçe yenileri gelir, alttaki dönen simge görünür
    var shown by remember { mutableIntStateOf(3) }
    val listState = androidx.compose.foundation.lazy.rememberLazyListState()
    LaunchedEffect(rows.size) {
        androidx.compose.runtime.snapshotFlow {
            (listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0) to listState.layoutInfo.totalItemsCount
        }.collect { (last, total) ->
            if (last >= total - 2 && shown < rows.size) {
                kotlinx.coroutines.delay(350)
                shown = (shown + 3).coerceAtMost(rows.size)
            }
        }
    }

    val busy = m == null || shown < rows.size || cat.pending.isNotEmpty() || refreshing || feedsLoading

    LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            HeroPager(hero, vm::seasonCount, onSettings, onOpenLocal) { actions.handle(it) }
        }
        // Stremio gibi: afişlerden hemen sonra "kaldığın yerden devam et"
        if ("continue" !in hidden) {
            item { TileRow("Kaldığın Yerden Devam Et", continueTiles, actions::handle) }
        }
        itemsIndexed(rows.take(shown)) { _, r ->
            TileRow(
                r.title, r.tiles.take(ROW_PREVIEW), actions::handle,
                onMore = if (r.id != "live" && r.tiles.size > ROW_PREVIEW) ({ onMore(r) }) else null,
            )
        }
        if (busy) {
            item {
                Box(Modifier.fillMaxWidth().padding(vertical = 28.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(Modifier.size(32.dp), strokeWidth = 3.dp)
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun HeroPager(
    items: List<HeroItem>,
    seasonOf: suspend (Series) -> Int?,
    onSettings: () -> Unit,
    onOpenLocal: () -> Unit,
    onOpen: (Tile) -> Unit,
) {
    Box(Modifier.fillMaxWidth().height(if (items.isEmpty()) 110.dp else 470.dp).background(Surface1)) {
        if (items.isNotEmpty()) {
            val pager = rememberPagerState(pageCount = { items.size })
            LaunchedEffect(items) {
                while (items.size > 1) {
                    delay(6000)
                    pager.animateScrollToPage((pager.currentPage + 1) % items.size)
                }
            }
            HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
                val h = items[page]
                val t = h.tile
                // Dizi ise sezon sayısı (Xtream bölüm listesinden) arka planda getirilir
                val seasons by produceState<Int?>(null, t.key) {
                    value = h.series?.let { seasonOf(it) }
                }
                Box(Modifier.fillMaxSize().clickable { onOpen(t) }) {
                    AsyncImage(
                        model = t.image, contentDescription = t.title,
                        contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize(),
                    )
                    Box(
                        Modifier.fillMaxSize().background(
                            Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.5f), Color.Transparent, Bg))
                        )
                    )
                    Column(Modifier.align(Alignment.BottomStart).padding(start = 16.dp, end = 16.dp, bottom = 34.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                if (h.isSeries) "DİZİ" else "FİLM",
                                color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Accent)
                                    .padding(horizontal = 6.dp, vertical = 2.dp),
                            )
                            val info = listOfNotNull(
                                if (h.isSeries) seasons?.let { "$it Sezon" } else null,
                                h.year?.toString(),
                                h.rating?.let(::ratingLabel),
                            ).joinToString(" • ")
                            if (info.isNotEmpty()) {
                                Text(
                                    "  $info", color = Color(0xFFFFC107),
                                    fontWeight = FontWeight.Bold, fontSize = 13.sp,
                                )
                            }
                        }
                        Text(
                            t.title, style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        )
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { onOpen(t) }) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Oynat / Detay")
                        }
                    }
                }
            }
            if (items.size > 1) {
                Row(
                    Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    repeat(items.size) { i ->
                        Box(
                            Modifier.size(if (i == pager.currentPage) 8.dp else 6.dp)
                                .clip(CircleShape)
                                .background(if (i == pager.currentPage) Color.White else Color.White.copy(alpha = 0.4f))
                        )
                    }
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("STREAMBOX", color = Accent, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, letterSpacing = 2.sp)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onOpenLocal) {
                Icon(Icons.Filled.FolderOpen, contentDescription = "Cihazdan video aç")
            }
            IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, contentDescription = "Ayarlar") }
        }
    }
}

// ---------------------------------------------------------------- Canlı TV

private const val FAV_ID = "__fav__"

@Composable
private fun LiveTab(vm: AppViewModel, cat: Catalog, actions: Actions) {
    var query by rememberSaveable { mutableStateOf("") }
    var catId by rememberSaveable { mutableStateOf<String?>(null) }
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val epg by vm.epg.collectAsStateWithLifecycle()
    val favKeys = remember(favs) { favs.filter { it.kind == "live" }.map { it.itemKey }.toSet() }

    val list = remember(cat, query, catId, favKeys) {
        cat.live.filter { ch ->
            val inCat = when (catId) {
                null -> true
                FAV_ID -> ch.url in favKeys
                else -> ch.categoryId == catId
            }
            inCat && (query.isBlank() || ch.name.contains(query, ignoreCase = true))
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        SearchField(query, "Kanal ara") { query = it }
        CategoryChips(cat.liveCategories, catId, extra = listOf(FAV_ID to "★ Favoriler")) { catId = it }
        if (list.isEmpty()) {
            when {
                cat.live.isEmpty() && "live" in cat.pending -> EmptyState("Kanallar yükleniyor...")
                cat.live.isEmpty() && cat.errors["live"] != null ->
                    EmptyState("Kanallar yüklenemedi: ${cat.errors["live"]}")

                else -> EmptyState("Kanal bulunamadı.")
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 8.dp, bottom = 16.dp)) {
                itemsIndexed(list) { i, ch ->
                    LiveRow(
                        ch = ch,
                        now = nowOf(epg, ch),
                        isFav = ch.url in favKeys,
                        onClick = { actions.onLive(list, i) },
                        onFav = { vm.toggleFavorite(ch.url, "live", ch.name, ch.logo) },
                    )
                }
            }
        }
    }
}

private fun nowOf(epg: Map<String, List<EpgItem>>, ch: LiveChannel): EpgItem? {
    val id = ch.epgId ?: return null
    val t = System.currentTimeMillis()
    return epg[id]?.firstOrNull { t >= it.startMs && t < it.endMs }
}

@Composable
private fun LiveRow(ch: LiveChannel, now: EpgItem?, isFav: Boolean, onClick: () -> Unit, onFav: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(56.dp).clip(RoundedCornerShape(8.dp)).background(Surface1),
            contentAlignment = Alignment.Center,
        ) {
            if (!ch.logo.isNullOrBlank()) {
                AsyncImage(
                    model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().padding(4.dp),
                )
            } else {
                Icon(Icons.Filled.Tv, contentDescription = null, tint = Color.Gray)
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(ch.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            if (now != null) {
                Text(now.title, color = Color.Gray, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val total = (now.endMs - now.startMs).coerceAtLeast(1L).toFloat()
                val frac = ((System.currentTimeMillis() - now.startMs) / total).coerceIn(0f, 1f)
                LinearProgressIndicator(
                    progress = { frac },
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp).height(2.dp),
                )
            }
        }
        IconButton(onClick = onFav) {
            Icon(
                if (isFav) Icons.Filled.Star else Icons.Filled.StarBorder,
                contentDescription = "Favori",
                tint = if (isFav) Color(0xFFFFC107) else Color.Gray,
            )
        }
    }
}

// ---------------------------------------------------------------- Film / Dizi ızgarası

@Composable
private fun BrowseTab(
    hint: String,
    categories: List<Category>,
    tiles: List<Tile>,
    emptyText: String,
    pending: Boolean,
    errorText: String?,
    onRetry: () -> Unit,
    onClick: (Tile) -> Unit,
) {
    var query by rememberSaveable(hint) { mutableStateOf("") }
    var catId by rememberSaveable(hint) { mutableStateOf<String?>(null) }

    val filtered = remember(tiles, query, catId) {
        tiles.filter { t ->
            (catId == null || t.categoryId == catId) &&
                (query.isBlank() || t.title.contains(query, ignoreCase = true))
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        SearchField(query, hint) { query = it }
        if (categories.isNotEmpty()) CategoryChips(categories, catId) { catId = it }
        if (filtered.isEmpty()) {
            when {
                tiles.isNotEmpty() -> EmptyState("Sonuç bulunamadı.")
                pending -> Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Yükleniyor... Yavaş bağlantıda birkaç dakika sürebilir.",
                        color = Color.Gray, textAlign = TextAlign.Center,
                    )
                }

                errorText != null -> Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("Yüklenemedi: $errorText", textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = onRetry) { Text("Tekrar dene") }
                }

                else -> EmptyState(emptyText)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(108.dp),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(filtered) { t -> PosterCard(t) { onClick(t) } }
            }
        }
    }
}

// ---------------------------------------------------------------- Listem

private val ListKinds = listOf("Filmler", "Diziler", "Canlı TV", "Geçmiş")

@Composable
private fun MyListTab(vm: AppViewModel, cat: Catalog, actions: Actions) {
    var kind by rememberSaveable { mutableIntStateOf(0) }
    var catId by rememberSaveable { mutableStateOf<String?>(null) }
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val hist by vm.history.collectAsStateWithLifecycle()
    val epg by vm.epg.collectAsStateWithLifecycle()

    val movieByUrl = remember(cat.movies) { cat.movies.associateBy { it.url } }
    val seriesByKey = remember(cat.series) { cat.series.associateBy { "series:${it.id}" } }
    val liveByUrl = remember(cat.live) { cat.live.associateBy { it.url } }

    val favMovies = remember(favs, movieByUrl) {
        favs.filter { it.kind == "movie" }.mapNotNull { movieByUrl[it.itemKey]?.toTile() }
    }
    val favSeries = remember(favs, seriesByKey) {
        favs.filter { it.kind == "series" }.mapNotNull { seriesByKey[it.itemKey]?.toTile() }
    }
    val favLive = remember(favs, liveByUrl) {
        favs.filter { it.kind == "live" }.mapNotNull { liveByUrl[it.itemKey] }
    }
    val histTiles = remember(hist) { hist.map { it.toTile() } }

    val counts = listOf(favMovies.size, favSeries.size, favLive.size, histTiles.size)

    // Seçili bölümün kategorileri: yalnızca içinde favori olanlar
    val categories: List<Category> = remember(kind, favMovies, favSeries, favLive, cat) {
        when (kind) {
            0 -> favMovies.map { it.categoryId }.toSet().let { ids -> cat.movieCategories.filter { it.id in ids } }
            1 -> favSeries.map { it.categoryId }.toSet().let { ids -> cat.seriesCategories.filter { it.id in ids } }
            2 -> favLive.map { it.categoryId }.toSet().let { ids -> cat.liveCategories.filter { it.id in ids } }
            else -> emptyList()
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text(
            "Listem", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp),
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            itemsIndexed(ListKinds) { i, label ->
                FilterChip(
                    selected = kind == i,
                    onClick = { kind = i; catId = null },
                    label = { Text("$label (${counts[i]})") },
                )
            }
        }
        if (categories.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            CategoryChips(categories, catId) { catId = it }
        }

        when (kind) {
            0, 1 -> {
                val tiles = (if (kind == 0) favMovies else favSeries).filter { catId == null || it.categoryId == catId }
                if (tiles.isEmpty()) {
                    EmptyState(
                        if (kind == 0) "Listende film yok.\nFilm detayındaki Listeme Ekle'ye dokun."
                        else "Listende dizi yok.\nDizi detayındaki Listeme Ekle'ye dokun."
                    )
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(108.dp),
                        contentPadding = PaddingValues(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        items(tiles) { t -> PosterCard(t) { actions.handle(t) } }
                    }
                }
            }

            2 -> {
                val list = favLive.filter { catId == null || it.categoryId == catId }
                if (list.isEmpty()) {
                    EmptyState("Favori kanal yok.\nCanlı TV'de kanalların yanındaki yıldıza dokun.")
                } else {
                    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 8.dp, bottom = 16.dp)) {
                        itemsIndexed(list) { i, ch ->
                            LiveRow(
                                ch = ch,
                                now = nowOf(epg, ch),
                                isFav = true,
                                onClick = { actions.onLive(list, i) },
                                onFav = { vm.toggleFavorite(ch.url, "live", ch.name, ch.logo) },
                            )
                        }
                    }
                }
            }

            else -> {
                if (histTiles.isEmpty()) {
                    EmptyState("Henüz izleme geçmişi yok.")
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(108.dp),
                        contentPadding = PaddingValues(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        items(histTiles) { t -> PosterCard(t) { actions.handle(t) } }
                    }
                }
            }
        }
    }
}
