package com.example.streambox.data

import android.util.Xml
import okhttp3.Request
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.zip.GZIPInputStream

/**
 * XMLTV akışını okur; yalnızca istenen kanallar için şu andan itibaren
 * 12 saat içindeki programları tutar (bellek tasarrufu için).
 */
object XmltvParser {

    private val withZone = SimpleDateFormat("yyyyMMddHHmmss Z", Locale.US)
    private val noZone = SimpleDateFormat("yyyyMMddHHmmss", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    private fun parseTime(s: String?): Long {
        val t = s?.trim() ?: return 0L
        return try {
            (if (t.contains(' ') || t.contains('+') || t.contains('-')) withZone.parse(t) else noZone.parse(t))?.time ?: 0L
        } catch (_: Exception) {
            try {
                noZone.parse(t.take(14))?.time ?: 0L
            } catch (_: Exception) {
                0L
            }
        }
    }

    fun parse(url: String, wanted: Set<String>): Map<String, List<EpgItem>> {
        val req = Request.Builder().url(url).header("User-Agent", Http.UA).build()
        Http.client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return emptyMap()
            var stream: InputStream = resp.body?.byteStream() ?: return emptyMap()
            if (url.substringBefore('?').endsWith(".gz")) stream = GZIPInputStream(stream)

            val parser = Xml.newPullParser()
            parser.setInput(stream, null)

            val now = System.currentTimeMillis()
            val horizon = now + 12L * 3600_000L
            val out = HashMap<String, MutableList<EpgItem>>()

            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG && parser.name == "programme") {
                    val channel = parser.getAttributeValue(null, "channel")
                    val start = parseTime(parser.getAttributeValue(null, "start"))
                    val stop = parseTime(parser.getAttributeValue(null, "stop"))
                    var title = ""
                    var desc = ""
                    event = parser.next()
                    while (!(event == XmlPullParser.END_TAG && parser.name == "programme") &&
                        event != XmlPullParser.END_DOCUMENT
                    ) {
                        if (event == XmlPullParser.START_TAG) {
                            when (parser.name) {
                                "title" -> if (title.isEmpty()) title = parser.nextText() else parser.nextText()
                                "desc" -> if (desc.isEmpty()) desc = parser.nextText() else parser.nextText()
                            }
                        }
                        event = parser.next()
                    }
                    if (channel != null && channel in wanted && stop > now && start < horizon) {
                        out.getOrPut(channel) { mutableListOf() }.add(EpgItem(title, desc, start, stop))
                    }
                }
                event = parser.next()
            }
            return out.mapValues { (_, v) -> v.sortedBy { it.startMs } }
        }
    }
}
