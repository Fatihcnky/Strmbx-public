package com.example.streambox.data

import okhttp3.Request

/** M3U / M3U8 oynatma listesini canlı kanal ve film olarak ayırır. */
object M3uParser {

    private val attr = Regex("""([\w-]+)="([^"]*)"""")
    private val vodExt = listOf(".mp4", ".mkv", ".avi", ".mov", ".m4v")

    fun load(acc: Account): Catalog {
        val live = ArrayList<LiveChannel>()
        val movies = ArrayList<Movie>()
        val liveCats = LinkedHashMap<String, Category>()
        val movieCats = LinkedHashMap<String, Category>()
        var epgUrl: String? = acc.epgUrl.trim().ifBlank { null }

        val req = Request.Builder().url(acc.m3uUrl.trim()).header("User-Agent", Http.UA).build()
        Http.client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) error("Liste indirilemedi (HTTP ${resp.code})")
            val src = resp.body?.source() ?: error("Boş yanıt")
            var first = true
            var info: String? = null
            var counter = 0

            while (true) {
                val raw = src.readUtf8Line() ?: break
                val line = raw.removePrefix("﻿").trim()
                if (line.isEmpty()) continue

                if (first) {
                    first = false
                    if (!line.startsWith("#EXTM3U")) error("Geçerli bir M3U listesi değil")
                    if (epgUrl == null) {
                        epgUrl = attr.findAll(line)
                            .firstOrNull { it.groupValues[1].lowercase() in setOf("url-tvg", "x-tvg-url") }
                            ?.groupValues?.get(2)?.split(',')?.firstOrNull()?.trim()
                            ?.ifBlank { null }
                    }
                    continue
                }
                if (line.startsWith("#EXTINF")) {
                    info = line
                    continue
                }
                if (line.startsWith("#")) continue

                val inf = info ?: continue
                info = null
                val url = line

                val attrs = attr.findAll(inf).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                val name = nameOf(inf).ifBlank { attrs["tvg-name"].orEmpty() }.ifBlank { "Kanal ${++counter}" }
                val group = attrs["group-title"].orEmpty().ifBlank { "Diğer" }
                val logo = attrs["tvg-logo"]?.ifBlank { null }

                val lower = url.substringBefore('?').lowercase()
                val isVod = "/movie/" in lower || "/series/" in lower || vodExt.any { lower.endsWith(it) }

                if (isVod) {
                    movieCats.getOrPut(group) { Category(group, group) }
                    movies.add(Movie(id = url, name = name, poster = logo, categoryId = group, url = url, rating = null))
                } else {
                    liveCats.getOrPut(group) { Category(group, group) }
                    live.add(
                        LiveChannel(
                            id = url, name = name, logo = logo, categoryId = group, url = url,
                            epgId = attrs["tvg-id"]?.ifBlank { null }, streamId = null,
                        )
                    )
                }
            }
        }

        if (live.isEmpty() && movies.isEmpty()) error("Listede oynatılabilir öğe bulunamadı")

        return Catalog(
            liveCategories = liveCats.values.toList(),
            live = live,
            movieCategories = movieCats.values.toList(),
            movies = movies,
            epgUrl = epgUrl,
        )
    }

    /** #EXTINF satırında tırnak dışındaki son virgülden sonrası kanal adıdır. */
    private fun nameOf(inf: String): String {
        var inQuote = false
        var last = -1
        for (i in inf.indices) {
            val c = inf[i]
            if (c == '"') inQuote = !inQuote
            else if (c == ',' && !inQuote) last = i
        }
        return if (last >= 0) inf.substring(last + 1).trim() else ""
    }
}
