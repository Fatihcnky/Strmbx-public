package com.example.streambox.data

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import okhttp3.HttpUrl.Companion.toHttpUrl
import kotlin.math.roundToInt

/**
 * Puan yardımcıları. Kaynaklar (public-apis listesinden):
 *  - OMDb  (IMDb puanı, anahtar ister)
 *  - TMDb  (topluluk puanı, anahtar ister)
 *  - TVMaze (yalnızca diziler, anahtarsız)
 * Listenin (sağlayıcının) kendi puanı en son çare olarak kullanılır.
 */
object Ratings {

    /** Puan ve (biliniyorsa) yapım yılı. */
    class Meta(val rating: Double?, val year: Int?)

    enum class Source(val label: String, val hint: String) {
        AUTO("Otomatik", "Girili anahtarlara göre OMDb → TMDb → Cinemeta → TVMaze sırasıyla dener"),
        CINEMETA("Stremio Cinemeta (IMDb puanı)", "Film ve dizi • anahtar gerekmez"),
        OMDB("OMDb (IMDb puanı)", "Film ve dizi • ücretsiz anahtar gerekir • günlük 1000 istek"),
        TMDB("TMDb", "Film ve dizi • ücretsiz anahtar gerekir"),
        TVMAZE("TVMaze", "Yalnızca diziler • anahtar gerekmez"),
        PROVIDER("Yalnızca liste verisi", "İnternetten puan çekilmez"),
    }

    /** Sağlayıcı bazen her içeriğe 10 (veya 0) yazar; bu değerler güvenilmez sayılır. */
    fun providerRating(s: String?): Double? {
        val v = s?.replace(',', '.')?.trim()?.toDoubleOrNull() ?: return null
        return if (v in 0.1..9.9) v else null
    }

    private val brackets = Regex("""\([^)]*\)|\[[^]]*]""")
    private val langPrefix = Regex("""^\s*\|?[A-Za-z]{2,3}\|?\s*[-:|]\s*""")
    private val quality = Regex("""\b(4K|FHD|UHD|HD|1080p|720p|HDR|MULTI|DUAL)\b""", RegexOption.IGNORE_CASE)
    private val trailingYear = Regex("""\s+(19|20)\d{2}\s*$""")
    private val spaces = Regex("""\s+""")
    private val yearParen = Regex("""\(((?:19|20)\d{2})\)""")
    private val yearEnd = Regex("""\b((?:19|20)\d{2})\s*$""")

    /** "TR - Film Adı (2019) 4K" -> ("Film Adı", "2019"). */
    fun clean(name: String): Pair<String, String?> {
        val year = yearParen.find(name)?.groupValues?.get(1) ?: yearEnd.find(name)?.groupValues?.get(1)
        var t = name.replace(brackets, " ")
        t = t.replace(langPrefix, "")
        t = t.replace(quality, " ")
        t = t.replace(spaces, " ").trim()
        t = t.replace(trailingYear, "").trim()
        return t to year
    }

    private val keyCache = java.util.concurrent.ConcurrentHashMap<String, String>()

    /** Temiz, küçük harfli başlık. Binlerce başlıkta çağrıldığı için sonuçlar saklanır. */
    fun key(name: String): String = keyCache.getOrPut(name) { clean(name).first.lowercase() }

    /** Addaki yıl (varsa). */
    fun yearOf(name: String): Int? = clean(name).second?.toIntOrNull()

    private val marks = Regex("""\p{Mn}+""")
    private val nonAlnum = Regex("""[^a-z0-9]+""")

    /** Katalog eşleştirmesi için: aksan/noktalama farkları yok sayılır ("Amélie" = "amelie", "ı" = "i"). */
    fun norm(s: String): String {
        val d = java.text.Normalizer.normalize(s.lowercase().replace('ı', 'i'), java.text.Normalizer.Form.NFD)
        return d.replace(marks, "").replace(nonAlnum, " ").trim()
    }

    private val yearAny = Regex("""(19|20)\d{2}""")

    /** Servisin döndürdüğü başlık, aranan başlıkla aynı mı? ("50%" aranınca "5000 Blankets" gelirse yanlış eşleşmedir.) */
    private fun titleOk(wanted: String, got: String?): Boolean {
        val g = got?.let { norm(it) }.orEmpty()
        return g.isNotEmpty() && g == norm(wanted)
    }

    fun parseYear(s: String?): Int? = s?.let { yearAny.find(it)?.value?.toIntOrNull() }

    private fun round1(v: Double) = (v * 10).roundToInt() / 10.0

    /** Seçili kaynakla (ve anahtarlarla) bu tür için internetten puan çekilebilir mi? */
    fun canFetch(src: Source, keys: ApiKeys, type: String): Boolean = chain(src, keys, type).isNotEmpty()

    private fun chain(src: Source, keys: ApiKeys, type: String): List<Source> = when (src) {
        Source.AUTO -> buildList {
            if (keys.omdb.isNotBlank()) add(Source.OMDB)
            if (keys.tmdb.isNotBlank()) add(Source.TMDB)
            add(Source.CINEMETA)
            if (type == "series") add(Source.TVMAZE)
        }
        Source.CINEMETA -> listOf(Source.CINEMETA)
        Source.OMDB -> if (keys.omdb.isNotBlank()) listOf(Source.OMDB) else emptyList()
        Source.TMDB -> if (keys.tmdb.isNotBlank()) listOf(Source.TMDB) else emptyList()
        Source.TVMAZE -> if (type == "series") listOf(Source.TVMAZE) else emptyList()
        Source.PROVIDER -> emptyList()
    }

    /**
     * @return puan ve yıl; hiçbir şey bulunamadıysa null (kalıcı "yok" sayılır).
     * Ağ/anahtar/limit hatasında istisna fırlatır (sonuç önbelleğe alınmaz).
     */
    fun fetch(src: Source, keys: ApiKeys, name: String, type: String): Meta? {
        val (title, yearStr) = clean(name)
        if (title.isBlank()) return null
        val year = yearStr?.toIntOrNull()
        var error: Exception? = null
        var best: Meta? = null
        for (s in chain(src, keys, type)) {
            try {
                val m = when (s) {
                    Source.OMDB -> omdb(keys.omdb.trim(), title, year, type)
                    Source.TMDB -> tmdb(keys.tmdb.trim(), title, year, type)
                    Source.CINEMETA -> cinemeta(title, year, type)
                    Source.TVMAZE -> tvmaze(title)
                    else -> null
                } ?: continue
                val r = m.rating?.takeIf { it > 0 }?.let(::round1)
                val merged = Meta(r ?: best?.rating, m.year ?: best?.year)
                if (r != null) return merged
                best = merged // yıl bulundu ama puan yok: sıradaki kaynak puanı tamamlasın
            } catch (e: Exception) {
                error = e
            }
        }
        if (best != null) return best
        if (error != null) throw error
        return null
    }

    private fun omdb(key: String, title: String, year: Int?, type: String): Meta? {
        val url = "https://www.omdbapi.com/".toHttpUrl().newBuilder()
            .addQueryParameter("apikey", key)
            .addQueryParameter("t", title)
            .addQueryParameter("type", type)
            .apply { if (year != null) addQueryParameter("y", year.toString()) }
            .build()
        val (code, body) = Http.getRaw(url.toString())
        if (code == 401) error("OMDb anahtarı geçersiz veya henüz etkinleştirilmemiş")
        if (code !in 200..299) error("OMDb hatası (HTTP $code)")
        val o = Http.json.parseToJsonElement(body) as? JsonObject ?: return null
        if (o.s("Response").equals("False", ignoreCase = true)) {
            val err = o.s("Error").orEmpty()
            if (err.contains("limit", true) || err.contains("key", true)) error("OMDb: $err")
            return null
        }
        if (!titleOk(title, o.s("Title"))) return null
        return Meta(o.s("imdbRating")?.toDoubleOrNull(), parseYear(o.s("Year")))
    }

    private fun tmdb(key: String, title: String, year: Int?, type: String): Meta? {
        val path = if (type == "series") "tv" else "movie"
        val b = "https://api.themoviedb.org/3/search/$path".toHttpUrl().newBuilder()
            .addQueryParameter("query", title)
            .addQueryParameter("language", "en-US")
        if (year != null) b.addQueryParameter(if (type == "series") "first_air_date_year" else "year", year.toString())
        val headers = HashMap<String, String>()
        if (key.startsWith("eyJ")) headers["Authorization"] = "Bearer $key" // v4 okuma jetonu
        else b.addQueryParameter("api_key", key) // v3 anahtarı
        val (code, body) = Http.getRaw(b.build().toString(), headers)
        if (code == 401) error("TMDb anahtarı geçersiz")
        if (code !in 200..299) error("TMDb hatası (HTTP $code)")
        val results = (Http.json.parseToJsonElement(body) as? JsonObject)?.get("results") as? JsonArray ?: return null
        for (r in results) {
            val o = r as? JsonObject ?: continue
            val v = o.s("vote_average")?.toDoubleOrNull() ?: continue
            val votes = o.s("vote_count")?.toIntOrNull() ?: 0
            val got = o.s("title") ?: o.s("name")
            val orig = o.s("original_title") ?: o.s("original_name")
            if (!titleOk(title, got) && !titleOk(title, orig)) continue
            val y = parseYear(o.s("release_date") ?: o.s("first_air_date"))
            if (year != null && y != null && kotlin.math.abs(y - year) > 1) continue
            if (v > 0 && votes >= 5) return Meta(v, y)
        }
        return null
    }

    /** Stremio'nun Cinemeta eklentisi: anahtarsız arama, IMDb puanı ve yılı döndürür. */
    private fun cinemeta(title: String, year: Int?, type: String): Meta? {
        val t = if (type == "series") "series" else "movie"
        val q = java.net.URLEncoder.encode(title, "UTF-8").replace("+", "%20")
        val (code, body) = Http.getRaw("https://v3-cinemeta.strem.io/catalog/$t/top/search=$q.json")
        if (code == 404) return null
        if (code == 429) error("Cinemeta istek sınırı, biraz sonra tekrar denenecek")
        if (code !in 200..299) error("Cinemeta hatası (HTTP $code)")
        val metas = (Http.json.parseToJsonElement(body) as? JsonObject)?.get("metas") as? JsonArray ?: return null
        val want = norm(title)
        for (m in metas) {
            val o = m as? JsonObject ?: continue
            if (norm(o.s("name").orEmpty()) != want) continue
            val y = parseYear(o.s("releaseInfo") ?: o.s("year"))
            if (year == null || y == null || kotlin.math.abs(y - year) <= 1) {
                return Meta(o.s("imdbRating")?.toDoubleOrNull(), y)
            }
        }
        return null // yıl uyuşmayan eşleşmeler yanlış film olabilir: kullanma
    }

    private fun tvmaze(title: String): Meta? {
        val url = "https://api.tvmaze.com/singlesearch/shows".toHttpUrl().newBuilder()
            .addQueryParameter("q", title).build()
        val (code, body) = Http.getRaw(url.toString())
        if (code == 404) return null
        if (code == 429) error("TVMaze istek sınırı aşıldı, biraz sonra tekrar denenecek")
        if (code !in 200..299) error("TVMaze hatası (HTTP $code)")
        val o = Http.json.parseToJsonElement(body) as? JsonObject ?: return null
        if (!titleOk(title, o.s("name"))) return null
        return Meta((o["rating"] as? JsonObject)?.s("average")?.toDoubleOrNull(), parseYear(o.s("premiered")))
    }

    /** Ayarlarda "Test et" düğmesi: seçili kaynak ve anahtarlarla örnek iki başlık dener. */
    fun test(src: Source, keys: ApiKeys): String {
        if (src == Source.PROVIDER) return "Bu seçenekte internetten puan çekilmez."
        val lines = ArrayList<String>()
        for ((label, name, type) in listOf(
            Triple("Film", "Inception (2010)", "movie"),
            Triple("Dizi", "Breaking Bad", "series"),
        )) {
            if (!canFetch(src, keys, type)) {
                lines += "$label: bu kaynak için ${if (type == "movie") "anahtar gerekli / film desteklenmiyor" else "anahtar gerekli"}"
                continue
            }
            lines += try {
                val m = fetch(src, keys, name, type)
                "$label ($name): " + (m?.rating?.let { "★ $it" + (m.year?.let { y -> " • $y" } ?: "") } ?: "bulunamadı")
            } catch (e: Exception) {
                "$label: HATA – ${e.message}"
            }
        }
        return lines.joinToString("\n")
    }
}
