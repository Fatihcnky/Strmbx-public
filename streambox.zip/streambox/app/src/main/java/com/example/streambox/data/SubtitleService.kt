package com.example.streambox.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayInputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.zip.ZipInputStream

data class SubResult(
    val provider: String, // "subdl" | "os"
    val id: String, // SubDL: indirme yolu, OpenSubtitles: file_id
    val name: String,
    val lang: String,
)

object SubtitleService {

    private const val UA = "StreamBox v1.0"
    private val subExt = listOf("srt", "vtt", "ass", "ssa")

    // ------------------------------------------------------------ Arama

    suspend fun search(keys: ApiKeys, provider: String, query: String, lang: String): List<SubResult> =
        withContext(Dispatchers.IO) {
            if (provider == "subdl") searchSubdl(keys.subdl.trim(), query, lang)
            else searchOpenSubtitles(keys.osKey.trim(), query, lang)
        }

    private fun searchSubdl(key: String, query: String, lang: String): List<SubResult> {
        val url = "https://api.subdl.com/api/v1/subtitles".toHttpUrl().newBuilder()
            .addQueryParameter("api_key", key)
            .addQueryParameter("film_name", query)
            .addQueryParameter("subs_per_page", "30")
            .apply { if (lang.isNotBlank()) addQueryParameter("languages", lang.uppercase()) }
            .build()
        val root = Http.json.parseToJsonElement(Http.get(url.toString())) as? JsonObject ?: return emptyList()
        if (root.s("status") == "false") error(root.s("error") ?: "SubDL hata döndürdü")
        val arr = root["subtitles"] as? JsonArray ?: return emptyList()
        return arr.mapNotNull { el ->
            val o = el as? JsonObject ?: return@mapNotNull null
            val path = o.s("url") ?: return@mapNotNull null
            SubResult(
                provider = "subdl",
                id = path,
                name = o.s("release_name") ?: o.s("name") ?: "Altyazı",
                lang = (o.s("lang") ?: o.s("language") ?: lang).ifBlank { "?" },
            )
        }
    }

    private fun osRequest(url: String, key: String): Request.Builder =
        Request.Builder().url(url)
            .header("Api-Key", key)
            .header("User-Agent", UA)
            .header("Accept", "application/json")

    private fun searchOpenSubtitles(key: String, query: String, lang: String): List<SubResult> {
        val url = "https://api.opensubtitles.com/api/v1/subtitles".toHttpUrl().newBuilder()
            .addQueryParameter("query", query)
            .apply { if (lang.isNotBlank()) addQueryParameter("languages", lang.lowercase()) }
            .build()
        Http.client.newCall(osRequest(url.toString(), key).build()).execute().use { resp ->
            if (!resp.isSuccessful) error("OpenSubtitles hata döndürdü (HTTP ${resp.code})")
            val root = Http.json.parseToJsonElement(resp.body?.string().orEmpty()) as? JsonObject
                ?: return emptyList()
            val data = root["data"] as? JsonArray ?: return emptyList()
            return data.mapNotNull { el ->
                val attrs = (el as? JsonObject)?.get("attributes") as? JsonObject ?: return@mapNotNull null
                val file = (attrs["files"] as? JsonArray)?.firstOrNull() as? JsonObject ?: return@mapNotNull null
                val fid = file.s("file_id") ?: return@mapNotNull null
                SubResult(
                    provider = "os",
                    id = fid,
                    name = attrs.s("release") ?: file.s("file_name") ?: "Altyazı",
                    lang = attrs.s("language") ?: lang.ifBlank { "?" },
                )
            }
        }
    }

    // ------------------------------------------------------------ İndirme

    suspend fun download(keys: ApiKeys, r: SubResult, dir: File): File = withContext(Dispatchers.IO) {
        dir.mkdirs()
        val bytes = if (r.provider == "subdl") downloadSubdl(keys, r) else downloadOpenSubtitles(keys, r)
        saveSubtitle(bytes, dir, "sub_${r.provider}_${r.id.hashCode().toUInt().toString(16)}")
    }

    private fun getBytes(url: String, headers: Map<String, String> = emptyMap()): ByteArray {
        val b = Request.Builder().url(url).header("User-Agent", UA)
        headers.forEach { (k, v) -> b.header(k, v) }
        Http.client.newCall(b.build()).execute().use { resp ->
            if (!resp.isSuccessful) error("İndirilemedi (HTTP ${resp.code})")
            return resp.body?.bytes() ?: error("Boş yanıt")
        }
    }

    private fun downloadSubdl(keys: ApiKeys, r: SubResult): ByteArray {
        val path = if (r.id.startsWith("/")) r.id else "/${r.id}"
        val headers = if (keys.subdl.isNotBlank()) mapOf("x-api-key" to keys.subdl.trim()) else emptyMap()
        return getBytes("https://dl.subdl.com$path", headers)
    }

    private fun downloadOpenSubtitles(keys: ApiKeys, r: SubResult): ByteArray {
        val jsonType = "application/json".toMediaType()
        val apiKey = keys.osKey.trim()

        // 1) Giriş: indirme için token gerekir
        val loginBody = buildJsonObject {
            put("username", keys.osUser.trim())
            put("password", keys.osPass)
        }.toString().toRequestBody(jsonType)
        val loginReq = osRequest("https://api.opensubtitles.com/api/v1/login", apiKey).post(loginBody).build()
        val (token, host) = Http.client.newCall(loginReq).execute().use { resp ->
            if (!resp.isSuccessful) error("OpenSubtitles girişi başarısız (HTTP ${resp.code}). Kullanıcı adı/şifreyi kontrol edin.")
            val o = Http.json.parseToJsonElement(resp.body?.string().orEmpty()) as? JsonObject
                ?: error("OpenSubtitles geçersiz yanıt verdi")
            val t = o.s("token") ?: error("OpenSubtitles token vermedi")
            t to (o.s("base_url") ?: "api.opensubtitles.com")
        }

        // 2) İndirme bağlantısı
        val dlBody = buildJsonObject {
            put("file_id", r.id.toLong())
            put("sub_format", "srt")
        }.toString().toRequestBody(jsonType)
        val dlReq = osRequest("https://$host/api/v1/download", apiKey)
            .header("Authorization", "Bearer $token")
            .post(dlBody).build()
        val link = Http.client.newCall(dlReq).execute().use { resp ->
            if (!resp.isSuccessful) error("OpenSubtitles indirme başarısız (HTTP ${resp.code}). Günlük kotanız dolmuş olabilir.")
            val o = Http.json.parseToJsonElement(resp.body?.string().orEmpty()) as? JsonObject
                ?: error("OpenSubtitles geçersiz yanıt verdi")
            o.s("link") ?: error("İndirme bağlantısı alınamadı")
        }
        return getBytes(link)
    }

    // ------------------------------------------------------------ Yerel dosya

    suspend fun importLocal(ctx: Context, uri: Uri, dir: File): File = withContext(Dispatchers.IO) {
        dir.mkdirs()
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Dosya okunamadı")
        val name = ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }
        saveSubtitle(bytes, dir, "local_${uri.toString().hashCode().toUInt().toString(16)}", name)
    }

    // ------------------------------------------------------------ Ortak

    /** Zip ise içinden ilk altyazıyı çıkarır, UTF-8'e çevirip dosyaya yazar. */
    private fun saveSubtitle(raw: ByteArray, dir: File, base: String, originalName: String? = null): File {
        var data = raw
        var ext = originalName?.substringAfterLast('.', "")?.lowercase().orEmpty()

        if (data.size > 4 && data[0] == 'P'.code.toByte() && data[1] == 'K'.code.toByte()) {
            var found = false
            ZipInputStream(ByteArrayInputStream(data)).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    val n = e.name.substringAfterLast('/').lowercase()
                    val x = n.substringAfterLast('.', "")
                    if (!e.isDirectory && x in subExt) {
                        data = zin.readBytes()
                        ext = x
                        found = true
                        break
                    }
                }
            }
            if (!found) error("Zip içinde altyazı dosyası bulunamadı")
        }
        if (ext !in subExt) ext = if (String(data.copyOf(minOf(data.size, 10))).trimStart('﻿').startsWith("WEBVTT")) "vtt" else "srt"

        val out = File(dir, "$base.$ext")
        out.writeBytes(toUtf8(data))
        return out
    }

    /** UTF-8 değilse (Türkçe altyazılarda sık: windows-1254) dönüştürür. */
    private fun toUtf8(b: ByteArray): ByteArray {
        var bytes = b
        if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()) {
            bytes = bytes.copyOfRange(3, bytes.size)
        }
        if (bytes.size >= 2 && ((bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte()) ||
                (bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte()))
        ) {
            return String(bytes, Charsets.UTF_16).toByteArray(Charsets.UTF_8)
        }
        return try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes))
            bytes
        } catch (_: CharacterCodingException) {
            String(bytes, Charset.forName("windows-1254")).toByteArray(Charsets.UTF_8)
        }
    }
}
