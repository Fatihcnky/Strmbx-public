package com.example.streambox.ui

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.Settings as AndroidSettings
import android.util.Rational
import android.util.TypedValue
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Spacer
import androidx.media3.exoplayer.SeekParameters
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.positionChanged
import android.os.SystemClock
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.withTimeoutOrNull
import android.view.LayoutInflater
import android.view.View
import androidx.compose.foundation.clickable
import android.view.TextureView
import android.view.ViewGroup
import com.example.streambox.R
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.PictureInPictureModeChangedInfo
import androidx.core.util.Consumer
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.navigation.NavController
import com.example.streambox.AppViewModel
import com.example.streambox.data.EpgItem
import com.example.streambox.data.Http
import com.example.streambox.data.SubtitleService
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Oynatıcı ekranı açıkken MainActivity'nin Ana Ekran tuşunda PiP'e geçmesi için. */
object PipState {
    @Volatile var allowed = false
    @Volatile var ratio: Rational = Rational(16, 9)
}

fun enterPip(act: Activity) {
    runCatching {
        if (Build.VERSION.SDK_INT >= 26) {
            act.enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(PipState.ratio).build())
        } else if (Build.VERSION.SDK_INT >= 24) {
            @Suppress("DEPRECATION")
            act.enterPictureInPictureMode()
        }
    }
}

private fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

private fun fmtDuration(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

private fun hm(ms: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(ms))

private class Hud(val brightness: Boolean, val fraction: Float)

private fun systemBrightness(ctx: Context): Float = runCatching {
    AndroidSettings.System.getInt(ctx.contentResolver, AndroidSettings.System.SCREEN_BRIGHTNESS, 128) / 255f
}.getOrDefault(0.5f)

@Composable
private fun ActionChip(icon: ImageVector, label: String, onClick: () -> Unit) {
    TextButton(onClick = onClick) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = Color.White, fontSize = 12.sp, maxLines = 1)
    }
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(vm: AppViewModel, nav: NavController) {
    val req = vm.playRequest
    if (req == null) {
        LaunchedEffect(Unit) { nav.popBackStack() }
        return
    }
    val context = LocalContext.current
    val activity = remember { context.findActivity() }
    val scope = rememberCoroutineScope()
    val epgMap by vm.epg.collectAsStateWithLifecycle()
    val settings by vm.playerSettings.collectAsStateWithLifecycle()
    val keys by vm.keys.collectAsStateWithLifecycle()
    val screenCfg = LocalConfiguration.current

    var index by remember { mutableIntStateOf(req.index.coerceIn(0, req.items.lastIndex)) }
    val item = req.items[index]
    val isLive = item.kind == "live"
    val currentItem by rememberUpdatedState(item)

    var overlay by remember { mutableStateOf(true) }
    var interaction by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }
    var playing by remember { mutableStateOf(true) }
    var buffering by remember { mutableStateOf(true) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var dragPos by remember { mutableStateOf<Float?>(null) }
    var showGuide by remember { mutableStateOf(false) }
    var guide by remember(item.key) { mutableStateOf<List<EpgItem>>(emptyList()) }
    var panel by remember { mutableStateOf<PanelPage?>(null) }
    var tracks by remember { mutableStateOf(TrackLists.Empty) }
    var speedIndex by remember { mutableIntStateOf(2) }
    var videoAspect by remember { mutableFloatStateOf(0f) }
    var inPip by remember { mutableStateOf(false) }
    val scrubEnabled by vm.scrubPreview.collectAsStateWithLifecycle()
    val holdSpeed by vm.holdSpeed.collectAsStateWithLifecycle()
    var boosted by remember { mutableStateOf(false) }
    val frameCache = remember { android.util.LruCache<Long, android.graphics.Bitmap>(60) }
    var renderedPos by remember { mutableLongStateOf(-1L) }
    var swipePos by remember { mutableStateOf<Long?>(null) }
    var previewPlayer by remember { mutableStateOf<ExoPlayer?>(null) }
    var sliderBounds by remember { mutableStateOf<androidx.compose.ui.geometry.Rect?>(null) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var pan by remember { mutableStateOf(Offset.Zero) }
    var videoInfo by remember { mutableStateOf("") }
    var reconnecting by remember { mutableIntStateOf(0) }   // >0: canlı yayın yeniden bağlanıyor (deneme sayısı)
    var liveFault by remember { mutableStateOf(false) }
    var hud by remember { mutableStateOf<Hud?>(null) }
    var pendingSubLabel by remember { mutableStateOf<String?>(null) }
    val extraSubs = remember { mutableStateListOf<MediaItem.SubtitleConfiguration>() }

    val supportsPip = remember {
        Build.VERSION.SDK_INT >= 26 &&
            context.packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
    }

    val player = remember {
        // DefaultDataSource: http(s) için OkHttp, ayrıca content:// ve file:// (cihazdaki dosyalar)
        val dataSourceFactory = DefaultDataSource.Factory(
            context,
            OkHttpDataSource.Factory(Http.client).setUserAgent(Http.UA),
        )
        ExoPlayer.Builder(context)
            // Yüksek gecikmeli (uydu) bağlantılar için daha büyük tampon
            .setLoadControl(
                DefaultLoadControl.Builder()
                    .setBufferDurationsMs(20_000, 60_000, 3_000, 6_000)
                    .build()
            )
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
            .build()
            .apply { playWhenReady = true }
    }

    val saveNow: () -> Unit = {
        val cur = currentItem
        if (cur.kind != "live" && durationMs > 0) vm.saveProgress(cur, positionMs, durationMs)
    }

    // Harici altyazıyı (dosya) mevcut yayına ekler, bulunduğu yerden devam eder
    fun attachSubtitle(file: File, lang: String?, label: String) {
        val mime = when (file.extension.lowercase()) {
            "vtt" -> MimeTypes.TEXT_VTT
            "ass", "ssa" -> MimeTypes.TEXT_SSA
            else -> MimeTypes.APPLICATION_SUBRIP
        }
        extraSubs.add(
            MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(file))
                .setMimeType(mime)
                .setLanguage(lang?.takeIf { it.isNotBlank() && it != "?" })
                .setLabel(label)
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .build()
        )
        val pos = player.currentPosition
        val wasPlaying = player.playWhenReady
        pendingSubLabel = label
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .build()
        player.setMediaItem(
            MediaItem.Builder()
                .setUri(Uri.parse(currentItem.url))
                .setSubtitleConfigurations(extraSubs.toList())
                .build(),
            pos,
        )
        player.prepare()
        player.playWhenReady = wasPlaying
    }

    val pickSubtitle = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        PipState.allowed = supportsPip
        if (uri != null) {
            scope.launch {
                try {
                    val f = SubtitleService.importLocal(context, uri, File(context.cacheDir, "subs"))
                    val name = displayName(context, uri)?.substringBeforeLast('.') ?: f.nameWithoutExtension
                    attachSubtitle(f, null, "$EXTERNAL_PREFIX: ${name.take(28)}")
                    panel = null
                } catch (e: Exception) {
                    error = null
                    vm.notice.value = "Altyazı eklenemedi: ${e.message ?: "bilinmeyen hata"}"
                }
            }
        }
    }

    // Yatay mod + tam ekran + PiP izni
    DisposableEffect(Unit) {
        val act = activity
        act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val controller = act?.window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        PipState.allowed = supportsPip
        onDispose {
            PipState.allowed = false
            saveNow()
            player.release()
            act?.window?.let { w ->
                val lp = w.attributes
                lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                w.attributes = lp
            }
            act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            controller?.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    // PiP modu değişimi
    DisposableEffect(activity) {
        val comp = activity as? ComponentActivity
        val listener = Consumer<PictureInPictureModeChangedInfo> { info ->
            inPip = info.isInPictureInPictureMode
            if (inPip) {
                overlay = false
                panel = null
                showGuide = false
            }
        }
        comp?.addOnPictureInPictureModeChangedListener(listener)
        onDispose { comp?.removeOnPictureInPictureModeChangedListener(listener) }
    }

    // Arka plana geçince duraklat (PiP'te devam eder)
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_STOP && activity?.isInPictureInPictureMode != true) player.pause()
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    // Oynatıcı olayları
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playing = isPlaying
            }

            override fun onVideoSizeChanged(size: VideoSize) {
                if (size.height > 0 && size.width > 0) {
                    val a = size.width * size.pixelWidthHeightRatio / size.height
                    videoAspect = a
                    // PiP penceresi için izin verilen aralığa (≈0.42–2.39) sıkıştır
                    val c = a.coerceIn(0.5f, 2.3f)
                    PipState.ratio = Rational((c * 1000).roundToInt(), 1000)
                }
            }

            override fun onTracksChanged(t: Tracks) {
                val lists = buildTrackLists(t, player)
                tracks = lists
                pendingSubLabel?.let { label ->
                    val i = lists.subs.indexOfFirst { it.label == label }
                    if (i > 0) {
                        pendingSubLabel = null
                        applyTrackChoice(player, C.TRACK_TYPE_TEXT, lists.subs[i])
                    }
                }
            }

            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_ENDED) {
                    val cur = req.items[index]
                    if (cur.kind != "live") {
                        val dur = player.duration.coerceAtLeast(0L)
                        vm.saveProgress(cur, dur, dur)
                        if (index < req.items.lastIndex) index++
                    }
                }
            }

            override fun onPlayerError(e: PlaybackException) {
                if (currentItem.kind == "live") {
                    liveFault = true // izleme döngüsü yeniden bağlanır; art arda başarısız olursa hata gösterilir
                    return
                }
                error = "Oynatılamadı (${e.errorCodeName}). Bağlantı sayısı sınırına takılmış olabilir veya yayın kapalı."
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    // Öğe değişince yükle (kanal değiştirme / sonraki bölüm)
    LaunchedEffect(index) {
        error = null
        positionMs = 0L
        durationMs = 0L
        extraSubs.clear()
        pendingSubLabel = null
        // Önceki öğeden kalan ses/altyazı/kalite seçimlerini sıfırla
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .clearOverrides()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .build()
        player.setMediaItem(MediaItem.fromUri(Uri.parse(item.url)), if (index == req.index) req.startMs else 0L)
        player.prepare()
        player.play()
    }

    // Yeni öğede yakınlaştırmayı ve yeniden bağlanma sayacını sıfırla
    LaunchedEffect(index) {
        zoom = 1f
        pan = Offset.Zero
        reconnecting = 0
        liveFault = false
        videoInfo = ""
    }

    // Mevcut kalite ve kare hızı (biçimde fps yoksa gerçekte çizilen kareler sayılır)
    LaunchedEffect(player, index) {
        var lastRendered = 0
        var lastT = 0L
        while (true) {
            delay(1000)
            val f = player.videoFormat
            val counters = player.videoDecoderCounters
            counters?.ensureUpdated()
            val rendered = counters?.renderedOutputBufferCount ?: 0
            val now = SystemClock.elapsedRealtime()
            var fps = f?.frameRate?.takeIf { it > 0f } ?: 0f
            if (fps <= 0f && player.isPlaying && lastT > 0 && rendered >= lastRendered) {
                val m = (rendered - lastRendered) * 1000f / (now - lastT).coerceAtLeast(1L)
                if (m > 5f) fps = m
            }
            lastRendered = rendered
            lastT = now
            val w = f?.width ?: 0
            val h = f?.height ?: 0
            videoInfo = if (w > 0 && h > 0) {
                val q = when {
                    w >= 3800 -> "4K"
                    w >= 2500 -> "1440p"
                    w >= 1900 -> "1080p"
                    w >= 1260 -> "720p"
                    w >= 840 -> "480p"
                    else -> "${h}p"
                }
                buildString {
                    append("$q (${w}×$h)")
                    if (fps > 0f) append(" • ${fps.roundToInt()} fps")
                }
            } else ""
        }
    }

    // Canlı yayın bekçisi: görüntü donarsa, yayın kesilirse ya da hata verirse kendiliğinden yeniden bağlanır
    LaunchedEffect(player, index, isLive) {
        if (!isLive) return@LaunchedEffect
        var stalled = 0
        var stableSecs = 0
        var lastPos = -1L
        var attempts = 0
        while (true) {
            delay(1000)
            val st = player.playbackState
            val pos = player.currentPosition
            val wantsPlay = player.playWhenReady
            val moving = st == Player.STATE_READY && pos != lastPos
            lastPos = pos

            if (moving) {
                stalled = 0
                stableSecs++
                if (stableSecs >= 15 && attempts > 0) { attempts = 0; reconnecting = 0 }
                if (reconnecting > 0 && stableSecs >= 3) reconnecting = 0
                continue
            }
            stableSecs = 0
            if (!wantsPlay && !liveFault) { stalled = 0; continue } // kullanıcı duraklattı

            stalled++
            val dead = liveFault || st == Player.STATE_ENDED || st == Player.STATE_IDLE
            if (stalled >= (if (dead) 2 else 20)) {
                stalled = 0
                liveFault = false
                attempts++
                if (attempts > 12) {
                    reconnecting = 0
                    error = "Yayın geri gelmedi. Kanalı değiştirip tekrar deneyin."
                    return@LaunchedEffect
                }
                reconnecting = attempts
                // Bağlantıyı baştan kur (yalnızca prepare() eski soketi bırakmayabilir)
                player.setMediaItem(MediaItem.fromUri(Uri.parse(currentItem.url)))
                player.prepare()
                player.play()
                // Bir sonraki denemeden önce biraz bekle (uzayan arızalarda 2-6 sn)
                delay((1000L * attempts.coerceAtMost(6)).coerceAtLeast(2000L))
                lastPos = -1L
            }
        }
    }

    // --- Sarma önizlemesi: sürüklerken o anın görüntüsünü ikinci, hafif bir oynatıcıyla gösterir
    val previewPos: Long? = swipePos ?: dragPos?.toLong()

    // Bölüm/film değişince eski önizleme oynatıcısını bırak
    LaunchedEffect(index) {
        previewPlayer?.release()
        previewPlayer = null
        frameCache.evictAll()
        renderedPos = -1L
    }

    // Sarma başlayınca açılır; bittikten 4 sn sonra kapanır (sunucu bağlantısını geri bırakır)
    LaunchedEffect(previewPos != null || overlay, scrubEnabled, index) {
        // Kontroller görünürken önizleme oynatıcısı önceden ısıtılır; sürüklemeye başlayınca hemen hazır olur
        if (previewPos == null && !overlay) {
            delay(4000)
            previewPlayer?.release()
            previewPlayer = null
            return@LaunchedEffect
        }
        if (!scrubEnabled || isLive || previewPlayer != null) return@LaunchedEffect
        val dsf = DefaultDataSource.Factory(
            context,
            OkHttpDataSource.Factory(Http.client).setUserAgent(Http.UA),
        )
        previewPlayer = ExoPlayer.Builder(context)
            .setLoadControl(DefaultLoadControl.Builder().setBufferDurationsMs(1_000, 3_000, 250, 500).build())
            .setMediaSourceFactory(DefaultMediaSourceFactory(dsf))
            .build()
            .apply {
                volume = 0f
                playWhenReady = false
                setSeekParameters(SeekParameters.CLOSEST_SYNC)
                setMediaItem(MediaItem.fromUri(Uri.parse(currentItem.url)))
                prepare()
            }
    }

    // Sürükleme sırasında küçük bir gecikmeyle (arka arkaya gelen konumları birleştirir) önizlemeyi o ana götür
    LaunchedEffect(previewPos, previewPlayer) {
        val p = previewPos ?: return@LaunchedEffect
        delay(60)
        previewPlayer?.seekTo(p)
    }

    DisposableEffect(Unit) {
        onDispose { previewPlayer?.release() }
    }

    // Oynatma hızı (canlı yayında her zaman 1x)
    LaunchedEffect(speedIndex, index, boosted, holdSpeed) {
        player.setPlaybackSpeed(if (isLive) 1f else if (boosted) holdSpeed else SpeedValues[speedIndex])
    }

    // Yayın akışı
    LaunchedEffect(item.key, epgMap) {
        if (isLive) guide = vm.guideFor(item)
    }

    // Konum takibi + düzenli kayıt
    LaunchedEffect(player) {
        var tick = 0
        while (true) {
            delay(500)
            positionMs = player.currentPosition
            durationMs = player.duration.takeIf { it > 0 } ?: 0L
            if (++tick % 20 == 0) saveNow()
        }
    }

    // Kontrolleri otomatik gizle
    LaunchedEffect(overlay, playing, showGuide, panel, interaction) {
        if (overlay && playing && !showGuide && panel == null) {
            delay(4000)
            overlay = false
        }
    }

    // Parlaklık/ses göstergesini kısa süre sonra gizle
    LaunchedEffect(hud) {
        if (hud != null) {
            delay(900)
            hud = null
        }
    }

    BackHandler(enabled = showGuide || panel != null) {
        showGuide = false
        panel = null
    }

    fun seekBy(delta: Long) {
        val target = (player.currentPosition + delta).coerceAtLeast(0L)
        val dur = player.duration
        player.seekTo(if (dur > 0) target.coerceAtMost(dur) else target)
    }

    val hasMany = req.items.size > 1
    val screenAspect = screenCfg.screenWidthDp.toFloat() / screenCfg.screenHeightDp.coerceAtLeast(1)

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        val exo = player
        AndroidView(
            factory = { ctx ->
                // TextureView'lu düzen: görüntü yakınlaştırma/kaydırma bununla düzgün çalışır
                (LayoutInflater.from(ctx).inflate(R.layout.player_view, null) as PlayerView).apply {
                    useController = false
                    this.player = exo
                    keepScreenOn = true
                    clipChildren = false
                    (findViewById<View>(androidx.media3.ui.R.id.exo_content_frame) as? ViewGroup)?.clipChildren = false
                }
            },
            update = { view ->
                (view.videoSurfaceView as? TextureView)?.apply {
                    scaleX = zoom
                    scaleY = zoom
                    translationX = pan.x
                    translationY = pan.y
                }
                // "En uygun": video oranı ekrana yakınsa doldur (küçük kırpma), değilse sığdır
                view.resizeMode = if (settings.resize == 0) {
                    if (videoAspect > 0f && abs(videoAspect / screenAspect - 1f) <= 0.15f) {
                        androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    } else {
                        androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                    }
                } else {
                    ResizeModes[settings.resize]
                }
                view.subtitleView?.apply {
                    setApplyEmbeddedStyles(false)
                    setApplyEmbeddedFontSizes(false)
                    setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, SubSizeSp[settings.subSize])
                    val edge = when (settings.subEdge) {
                        1 -> CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW
                        2 -> CaptionStyleCompat.EDGE_TYPE_OUTLINE
                        else -> CaptionStyleCompat.EDGE_TYPE_NONE
                    }
                    setStyle(
                        CaptionStyleCompat(
                            SubColors[settings.subColor],
                            SubBgColors[settings.subBg],
                            android.graphics.Color.TRANSPARENT,
                            edge,
                            android.graphics.Color.BLACK,
                            null,
                        )
                    )
                }
            },
            modifier = Modifier.fillMaxSize(),
        )

        // Dokunma yakalayıcı: tek dokunuş kontrolleri açar/kapatır, çift dokunuş ±10 sn atlar,
        // dikey kaydırma: sol yarı parlaklık, sağ yarı ses
        if (!inPip) {
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        // İki parmakla yakınlaştır/uzaklaştır ve kaydır (diğer hareketlerden önce, Initial geçişinde)
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                            do {
                                val event = awaitPointerEvent(PointerEventPass.Initial)
                                if (event.changes.count { it.pressed } >= 2) {
                                    val z = event.calculateZoom()
                                    val p = event.calculatePan()
                                    if (z != 1f || p != Offset.Zero) {
                                        val nz = (zoom * z).coerceIn(1f, 5f)
                                        val maxX = size.width * (nz - 1f) / 2f
                                        val maxY = size.height * (nz - 1f) / 2f
                                        zoom = if (nz < 1.02f) 1f else nz
                                        pan = if (zoom == 1f) Offset.Zero else Offset(
                                            (pan.x + p.x).coerceIn(-maxX, maxX),
                                            (pan.y + p.y).coerceIn(-maxY, maxY),
                                        )
                                        event.changes.forEach { if (it.positionChanged()) it.consume() }
                                    }
                                }
                            } while (event.changes.any { it.pressed })
                        }
                    }
                    .pointerInput(isLive) {
                        detectTapGestures(
                            onPress = {
                                // Basılı tut: ayarlardaki hızda oynat, bırakınca normale dön
                                if (!isLive) {
                                    val released = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis + 150) {
                                        tryAwaitRelease()
                                    }
                                    if (released == null) {
                                        boosted = true
                                        tryAwaitRelease()
                                        boosted = false
                                    }
                                }
                            },
                            onTap = {
                                overlay = !overlay
                                interaction++
                            },
                            onDoubleTap = { off ->
                                if (!isLive) {
                                    seekBy(if (off.x < size.width / 2) -10_000L else 10_000L)
                                    overlay = true
                                    interaction++
                                }
                            },
                        )
                    }
                    .pointerInput(Unit) {
                        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                        var leftSide = true
                        var accum = 0f
                        var startBright = 0.5f
                        var startVol = 0
                        detectVerticalDragGestures(
                            onDragStart = { off ->
                                leftSide = off.x < size.width / 2
                                accum = 0f
                                val cur = activity?.window?.attributes?.screenBrightness ?: -1f
                                startBright = if (cur >= 0f) cur else systemBrightness(context)
                                startVol = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
                            },
                            onVerticalDrag = { change, dy ->
                                change.consume()
                                accum -= dy / size.height.coerceAtLeast(1)
                                if (leftSide) {
                                    val b = (startBright + accum * 1.3f).coerceIn(0.02f, 1f)
                                    activity?.window?.let { w ->
                                        val lp = w.attributes
                                        lp.screenBrightness = b
                                        w.attributes = lp
                                    }
                                    hud = Hud(true, b)
                                } else {
                                    val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                                    val v = (startVol + accum * max * 1.3f).roundToInt().coerceIn(0, max)
                                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
                                    hud = Hud(false, v / max.toFloat())
                                }
                            },
                        )
                    }
                    .pointerInput(isLive) {
                        // Yatay kaydırma: ileri/geri sar (bırakınca atlar). Ekran genişliği ≈ 4 dk (kısa içerikte süre kadar)
                        if (isLive) return@pointerInput
                        var base = 0L
                        var acc = 0f
                        detectHorizontalDragGestures(
                            onDragStart = {
                                base = player.currentPosition
                                acc = 0f
                                swipePos = base
                                overlay = false
                            },
                            onHorizontalDrag = { change, dx ->
                                change.consume()
                                acc += dx
                                val dur = player.duration.takeIf { it > 0 }
                                val span = minOf(dur ?: 240_000L, 240_000L)
                                val delta = (acc / size.width.coerceAtLeast(1) * span).toLong()
                                val target = base + delta
                                swipePos = if (dur != null) target.coerceIn(0L, dur) else target.coerceAtLeast(0L)
                            },
                            onDragEnd = {
                                swipePos?.let { player.seekTo(it) }
                                swipePos = null
                                interaction++
                            },
                            onDragCancel = { swipePos = null },
                        )
                    }
            )
        }

        if (buffering && error == null) {
            CircularProgressIndicator(Modifier.align(Alignment.Center), color = Color.White)
        }

        // Sarma önizlemesi + ne kadar sarıldığı (örn. 12:30 (+0:45))
        val pp = previewPos
        if (pp != null && !isLive && !inPip) {
            val delta = pp - positionMs
            val label = "${fmtDuration(pp)}  (${if (delta >= 0) "+" else "−"}${fmtDuration(abs(delta))})"
            val b = sliderBounds
            val frac = if (durationMs > 0) (pp.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
            val mod = if (swipePos == null && b != null) {
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(bottom = 128.dp)
                    .offset {
                        val w = 176.dp.toPx()
                        val x = b.left + b.width * frac - w / 2
                        IntOffset(x.coerceIn(8.dp.toPx(), (screenCfg.screenWidthDp.dp.toPx() - w - 8.dp.toPx()).coerceAtLeast(8.dp.toPx())).roundToInt(), 0)
                    }
            } else {
                Modifier.align(Alignment.Center)
            }
            ScrubPreview(
                preview = if (scrubEnabled) previewPlayer else null,
                label = label,
                target = pp,
                cache = frameCache,
                renderedPos = renderedPos,
                onRendered = { renderedPos = it },
                modifier = mod,
            )
        }

        if (boosted && !inPip) {
            Text(
                "▶▶ ${("%.2f".format(java.util.Locale.US, holdSpeed)).trimEnd('0').trimEnd('.')}x",
                color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 28.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xCC000000))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            )
        }

        if (zoom > 1.01f && !inPip) {
            Text(
                "×${String.format(Locale.US, "%.1f", zoom)}  ✕ Sıfırla",
                color = Color.White, fontSize = 13.sp,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 84.dp, end = 16.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xCC000000))
                    .clickable { zoom = 1f; pan = Offset.Zero }
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            )
        }

        if (reconnecting > 0 && error == null && !inPip) {
            Text(
                "Yayın koptu, yeniden bağlanılıyor… ($reconnecting)",
                color = Color.White, fontSize = 13.sp,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 28.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xCCB26A00))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            )
        }

        // Parlaklık / ses göstergesi
        hud?.let { h ->
            Row(
                Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 28.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xCC000000))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Icon(
                    if (h.brightness) Icons.Filled.BrightnessMedium else Icons.Filled.VolumeUp,
                    contentDescription = null, tint = Color.White,
                )
                LinearProgressIndicator(progress = { h.fraction }, modifier = Modifier.width(120.dp))
                Text("${(h.fraction * 100).roundToInt()}%", color = Color.White, fontSize = 13.sp)
            }
        }

        AnimatedVisibility(
            visible = !inPip && (overlay || error != null),
            enter = fadeIn(), exit = fadeOut(),
        ) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f))) {
                // Üst çubuk
                Row(
                    Modifier.align(Alignment.TopStart).fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri", tint = Color.White)
                    }
                    Column(Modifier.padding(start = 8.dp).weight(1f)) {
                        Text(
                            item.title, color = Color.White, fontWeight = FontWeight.Bold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        item.subtitle?.let {
                            Text(it, color = Color.LightGray, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (videoInfo.isNotEmpty()) {
                            Text(videoInfo, color = Color(0xFF80CBC4), fontSize = 12.sp, maxLines = 1)
                        }
                    }
                    IconButton(onClick = { panel = PanelPage.Main; showGuide = false; interaction++ }) {
                        Icon(Icons.Filled.Settings, contentDescription = "Oynatıcı ayarları", tint = Color.White)
                    }
                }

                // Orta kontroller
                Row(
                    Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(24.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (hasMany) {
                        IconButton(onClick = { if (index > 0) index--; interaction++ }, enabled = index > 0) {
                            Icon(Icons.Filled.SkipPrevious, contentDescription = "Önceki", tint = Color.White, modifier = Modifier.size(36.dp))
                        }
                    }
                    if (!isLive) {
                        IconButton(onClick = { seekBy(-10_000L); interaction++ }) {
                            Icon(Icons.Filled.Replay10, contentDescription = "10 sn geri", tint = Color.White, modifier = Modifier.size(36.dp))
                        }
                    }
                    IconButton(
                        onClick = {
                            if (player.isPlaying) player.pause() else player.play()
                            interaction++
                        },
                        modifier = Modifier.size(64.dp),
                    ) {
                        Icon(
                            if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = "Oynat/Duraklat", tint = Color.White,
                            modifier = Modifier.size(52.dp),
                        )
                    }
                    if (!isLive) {
                        IconButton(onClick = { seekBy(10_000L); interaction++ }) {
                            Icon(Icons.Filled.Forward10, contentDescription = "10 sn ileri", tint = Color.White, modifier = Modifier.size(36.dp))
                        }
                    }
                    if (hasMany) {
                        IconButton(
                            onClick = { if (index < req.items.lastIndex) index++; interaction++ },
                            enabled = index < req.items.lastIndex,
                        ) {
                            Icon(Icons.Filled.SkipNext, contentDescription = "Sonraki", tint = Color.White, modifier = Modifier.size(36.dp))
                        }
                    }
                }

                // Alt çubuk
                Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp)) {
                    if (isLive) {
                        val now = System.currentTimeMillis()
                        val cur = guide.firstOrNull { now >= it.startMs && now < it.endMs }
                        val next = guide.firstOrNull { it.startMs >= (cur?.endMs ?: now) }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "CANLI", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFFD32F2F))
                                    .padding(horizontal = 6.dp, vertical = 2.dp),
                            )
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    cur?.let { "${hm(it.startMs)} ${it.title}" } ?: "Yayın bilgisi yok",
                                    color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                )
                                next?.let {
                                    Text(
                                        "Sonra: ${hm(it.startMs)} ${it.title}",
                                        color = Color.LightGray, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                            TextButton(onClick = { showGuide = true; panel = null; interaction++ }) { Text("Yayın akışı") }
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(fmtDuration(dragPos?.toLong() ?: positionMs), color = Color.White, fontSize = 12.sp)
                            Slider(
                                value = (dragPos ?: positionMs.toFloat()).coerceAtLeast(0f),
                                onValueChange = { dragPos = it; interaction++ },
                                onValueChangeFinished = {
                                    dragPos?.let { player.seekTo(it.toLong()) }
                                    dragPos = null
                                },
                                valueRange = 0f..durationMs.toFloat().coerceAtLeast(1f),
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 8.dp)
                                    .onGloballyPositioned { sliderBounds = it.boundsInRoot() },
                            )
                            Text(fmtDuration(durationMs), color = Color.White, fontSize = 12.sp)
                        }
                    }

                    // Hızlı erişim düğmeleri
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                        if (!isLive) {
                            ActionChip(Icons.Filled.Speed, SpeedLabels[speedIndex].substringBefore(' ')) {
                                panel = PanelPage.Speed; showGuide = false; interaction++
                            }
                        }
                        ActionChip(Icons.Filled.AspectRatio, ResizeShort[settings.resize]) {
                            vm.updatePlayerSettings(settings.copy(resize = (settings.resize + 1) % ResizeShort.size))
                            interaction++
                        }
                        ActionChip(Icons.Filled.Audiotrack, "Ses") {
                            panel = PanelPage.Audio; showGuide = false; interaction++
                        }
                        ActionChip(Icons.Filled.Subtitles, "Altyazı") {
                            panel = PanelPage.Subs; showGuide = false; interaction++
                        }
                        if (supportsPip) {
                            ActionChip(Icons.Filled.PictureInPictureAlt, "PiP") {
                                activity?.let { enterPip(it) }
                            }
                        }
                    }
                }
            }
        }

        // Yayın akışı paneli
        if (showGuide && !inPip) {
            Column(
                Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxHeight()
                    .width(340.dp)
                    .background(Color(0xEE12121A))
                    .pointerInput(Unit) { detectTapGestures { } }
                    .padding(16.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Yayın Akışı", color = Color.White, fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f),
                    )
                    IconButton(onClick = { showGuide = false }) {
                        Icon(Icons.Filled.Close, contentDescription = "Kapat", tint = Color.White)
                    }
                }
                if (guide.isEmpty()) {
                    Text("Bu kanal için program bilgisi bulunamadı.", color = Color.Gray)
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(guide) { p ->
                            Column {
                                Text("${hm(p.startMs)} - ${hm(p.endMs)}", color = Color(0xFFB39DFF), fontSize = 12.sp)
                                Text(p.title, color = Color.White, fontWeight = FontWeight.Medium)
                                if (p.description.isNotBlank()) {
                                    Text(
                                        p.description, color = Color.Gray, fontSize = 12.sp,
                                        maxLines = 3, overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Oynatıcı ayarları paneli
        panel?.let { startPage ->
            if (!inPip) {
                Box(Modifier.align(Alignment.CenterEnd)) {
                    PlayerSettingsPanel(
                        startPage = startPage,
                        tracks = tracks,
                        settings = settings,
                        speedIndex = speedIndex,
                        isLive = isLive,
                        keys = keys,
                        searchDefault = item.title,
                        onSettings = { vm.updatePlayerSettings(it) },
                        onSpeed = { speedIndex = it },
                        onAudio = { applyTrackChoice(player, C.TRACK_TYPE_AUDIO, it) },
                        onSub = { applyTrackChoice(player, C.TRACK_TYPE_TEXT, it) },
                        onQuality = { applyTrackChoice(player, C.TRACK_TYPE_VIDEO, it) },
                        onPickLocalSub = {
                            // Dosya seçici açılırken onUserLeaveHint tetiklenir; PiP'e geçmesin
                            PipState.allowed = false
                            pickSubtitle.launch(arrayOf("*/*"))
                        },
                        onSearch = { provider, query, lang -> SubtitleService.search(keys, provider, query, lang) },
                        onDownload = { r ->
                            try {
                                val f = SubtitleService.download(keys, r, File(context.cacheDir, "subs"))
                                attachSubtitle(f, r.lang, "$EXTERNAL_PREFIX: ${r.lang.uppercase()} ${r.name.take(22)}")
                                null
                            } catch (e: Exception) {
                                e.message ?: "İndirilemedi"
                            }
                        },
                        onClose = { panel = null },
                    )
                }
            }
        }

        // Hata ekranı
        error?.let { msg ->
            Column(
                Modifier.align(Alignment.Center).padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(msg, color = Color.White)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = {
                        error = null
                        player.prepare()
                        player.play()
                    }) { Text("Tekrar dene") }
                    OutlinedButton(onClick = { nav.popBackStack() }) { Text("Geri") }
                }
            }
        }
    }
}

/**
 * Sarma sırasında gösterilen küçük resim ve "12:30 (+0:45)" etiketi.
 * Önizleme oynatıcısı hedef konuma henüz ulaşmadıysa, daha önce görülen en yakın kare (varsa) gösterilir;
 * böylece sürüklerken boş/eski kare yerine yaklaşık bir sahne görünür, bekleyince netleşir.
 */
@OptIn(UnstableApi::class)
@Composable
private fun ScrubPreview(
    preview: ExoPlayer?,
    label: String,
    target: Long,
    cache: android.util.LruCache<Long, android.graphics.Bitmap>,
    renderedPos: Long,
    onRendered: (Long) -> Unit,
    modifier: Modifier,
) {
    val bucket = 4_000L
    var view by remember { mutableStateOf<PlayerView?>(null) }

    if (preview != null) {
        DisposableEffect(preview) {
            val listener = object : Player.Listener {
                override fun onRenderedFirstFrame() {
                    val pos = preview.currentPosition
                    val tv = view?.videoSurfaceView as? TextureView
                    runCatching { tv?.getBitmap(240, 135) }.getOrNull()?.let { cache.put(pos / bucket, it) }
                    onRendered(pos)
                }

                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_READY) {
                        // Kare çizilsin diye kısa bir gecikmeyle "güncel" say
                        view?.postDelayed({ onRendered(preview.currentPosition) }, 80)
                    }
                }
            }
            preview.addListener(listener)
            onDispose { preview.removeListener(listener) }
        }
    }

    val fresh = preview != null && renderedPos >= 0 && abs(renderedPos - target) <= 5_000L
    val nearest = if (fresh) null else {
        var best: android.graphics.Bitmap? = null
        var bestD = 90_000L
        for ((k, v) in cache.snapshot()) {
            val d = abs(k * bucket - target)
            if (d <= bestD) { bestD = d; best = v }
        }
        best
    }

    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        if (preview != null) {
            Box(Modifier.size(176.dp, 99.dp).clip(RoundedCornerShape(8.dp)).background(Color.Black)) {
                AndroidView(
                    factory = { ctx ->
                        (LayoutInflater.from(ctx).inflate(R.layout.player_view, null) as PlayerView).apply {
                            useController = false
                            this.player = preview
                            resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                            view = this
                        }
                    },
                    modifier = Modifier.fillMaxSize().alpha(if (fresh) 1f else 0f),
                )
                if (!fresh) {
                    if (nearest != null) {
                        androidx.compose.foundation.Image(
                            bitmap = nearest.asImageBitmap(),
                            contentDescription = null,
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                            modifier = Modifier.fillMaxSize(),
                        )
                    }
                    CircularProgressIndicator(
                        Modifier.align(Alignment.BottomEnd).padding(6.dp).size(16.dp),
                        color = Color.White, strokeWidth = 2.dp,
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
        }
        Text(
            label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp,
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xCC000000))
                .padding(horizontal = 12.dp, vertical = 6.dp),
        )
    }
}
