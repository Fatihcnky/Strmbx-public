package com.example.streambox.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.example.streambox.AppViewModel
import com.example.streambox.data.Category
import com.example.streambox.data.ContentFilter

private val Tabs = listOf("Ana sayfa", "Canlı TV", "Filmler", "Diziler")

/**
 * İçerik seçimi: (1) hangi kategoriler listeden tamamen kaldırılsın (yenilemede mümkünse indirilmez),
 * (2) ana sayfada hangi satırlar görünsün. Değişiklikler "Kaydet" ile uygulanır.
 */
@Composable
fun ContentScreen(vm: AppViewModel, nav: NavController) {
    val ctx = LocalContext.current
    val cat by vm.catalog.collectAsStateWithLifecycle()
    val filter by vm.contentFilter.collectAsStateWithLifecycle()
    val homeHidden by vm.homeHidden.collectAsStateWithLifecycle()
    val feeds by vm.feeds.collectAsStateWithLifecycle()

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var query by rememberSaveable { mutableStateOf("") }
    var hLive by remember(filter) { mutableStateOf(filter.hiddenLive) }
    var hMovies by remember(filter) { mutableStateOf(filter.hiddenMovies) }
    var hSeries by remember(filter) { mutableStateOf(filter.hiddenSeries) }
    var hHome by remember(homeHidden) { mutableStateOf(homeHidden) }
    var confirmExit by remember { mutableStateOf(false) }

    val dirty = hLive != filter.hiddenLive || hMovies != filter.hiddenMovies ||
        hSeries != filter.hiddenSeries || hHome != homeHidden

    fun save() {
        val msg = vm.saveContentSelection(ContentFilter(hLive, hMovies, hSeries), hHome)
        Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
    }

    fun back() { if (dirty) confirmExit = true else nav.popBackStack() }
    BackHandler(enabled = dirty) { confirmExit = true }

    val c = cat
    val liveCats = c?.allLiveCategories?.ifEmpty { c.liveCategories }.orEmpty()
    val movieCats = c?.allMovieCategories?.ifEmpty { c.movieCategories }.orEmpty()
    val seriesCats = c?.allSeriesCategories?.ifEmpty { c.seriesCategories }.orEmpty()

    fun <T> Set<T>.toggle(v: T) = if (v in this) this - v else this + v

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { back() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                }
                Text("İçerik seçimi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(Tabs.size) { i ->
                    FilterChip(selected = tab == i, onClick = { tab = i; query = "" }, label = { Text(Tabs[i]) })
                }
            }

            when (tab) {
                0 -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 110.dp)) {
                    item {
                        Text(
                            "Ana sayfada görünecek satırları seç. Kapalı olanlar gösterilmez.",
                            color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp),
                        )
                    }
                    val fixed = buildList {
                        add("continue" to "Kaldığın yerden devam et")
                        feeds.forEach { add("feed:${it.title}" to "${it.title} (katalog)") }
                        add("rated_movies" to "Yüksek puanlı filmler")
                        add("rated_series" to "Yüksek puanlı diziler")
                        add("live" to "Canlı TV")
                    }
                    items(fixed) { (id, label) ->
                        CheckRow(label, id !in hHome) { hHome = hHome.toggle(id) }
                    }
                    item { SectionTitle("Film kategorisi satırları") }
                    items(c?.movieCategories.orEmpty()) { cc ->
                        CheckRow(cc.name, "mcat:${cc.id}" !in hHome) { hHome = hHome.toggle("mcat:${cc.id}") }
                    }
                    item { SectionTitle("Dizi kategorisi satırları") }
                    items(c?.seriesCategories.orEmpty()) { cc ->
                        CheckRow(cc.name, "scat:${cc.id}" !in hHome) { hHome = hHome.toggle("scat:${cc.id}") }
                    }
                }

                else -> {
                    val cats: List<Category>
                    val hidden: Set<String>
                    val prefix: String
                    when (tab) {
                        1 -> { cats = liveCats; hidden = hLive; prefix = "live" }
                        2 -> { cats = movieCats; hidden = hMovies; prefix = "movies" }
                        else -> { cats = seriesCats; hidden = hSeries; prefix = "series" }
                    }
                    fun setHidden(v: Set<String>) {
                        when (tab) { 1 -> hLive = v; 2 -> hMovies = v; else -> hSeries = v }
                    }
                    val shown = remember(cats, query) {
                        if (query.isBlank()) cats else cats.filter { it.name.contains(query, ignoreCase = true) }
                    }
                    SearchField(query, "Kategori ara") { query = it }
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            "Kapalı kategoriler listeden çıkar ve liste yenilenirken mümkünse hiç indirilmez.",
                            color = Color.Gray, fontSize = 12.sp, modifier = Modifier.weight(1f).padding(start = 8.dp),
                        )
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                        TextButton(onClick = { setHidden(hidden - shown.map { it.id }.toSet()) }) { Text("Görünenlerin hepsini aç") }
                        TextButton(onClick = { setHidden(hidden + shown.map { it.id }) }) { Text("Hepsini kapat") }
                    }
                    if (cats.isEmpty()) {
                        EmptyState("Kategori listesi henüz yok. Ayarlar'dan listeyi bir kez güncelle.")
                    } else {
                        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 110.dp)) {
                            items(shown, key = { it.id }) { cc ->
                                val n = c?.categorySizes?.get("$prefix:${cc.id}")
                                CheckRow(
                                    cc.name + if (n != null) "  ($n)" else "",
                                    cc.id !in hidden,
                                ) { setHidden(hidden.toggle(cc.id)) }
                            }
                        }
                    }
                }
            }
        }

        Surface(
            color = Color(0xFF1E1E2A),
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth(),
            shadowElevation = 8.dp,
        ) {
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 10.dp).navigationBarsPadding(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    if (dirty) "Kaydedilmemiş değişiklikler var" else "✓ Kayıtlı",
                    color = if (dirty) Color(0xFFFFC107) else Color(0xFF66BB6A),
                    fontSize = 13.sp, modifier = Modifier.weight(1f),
                )
                if (dirty) {
                    TextButton(onClick = {
                        hLive = filter.hiddenLive; hMovies = filter.hiddenMovies
                        hSeries = filter.hiddenSeries; hHome = homeHidden
                    }) { Text("Vazgeç") }
                }
                Button(onClick = { save() }, enabled = dirty) { Text("Kaydet") }
            }
        }
    }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("Değişiklikler kaydedilmedi") },
            text = { Text("Kaydetmeden çıkarsan seçimlerin uygulanmaz.") },
            confirmButton = { TextButton(onClick = { save(); confirmExit = false; nav.popBackStack() }) { Text("Kaydet ve çık") } },
            dismissButton = {
                Row {
                    TextButton(onClick = { confirmExit = false }) { Text("Vazgeç") }
                    TextButton(onClick = { confirmExit = false; nav.popBackStack() }) { Text("Kaydetmeden çık") }
                }
            },
        )
    }
}

@Composable
private fun CheckRow(label: String, checked: Boolean, onToggle: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onToggle),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(checked = checked, onCheckedChange = { onToggle() })
        Text(label, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun SectionTitle(text: String) {
    Column(Modifier.padding(top = 16.dp, bottom = 4.dp)) {
        HorizontalDivider()
        Text(text, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp))
    }
}
