package com.example.streambox.data

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import okhttp3.HttpUrl.Companion.toHttpUrl

/** Dış kataloğun (TMDb / Stremio) tek bir öğesi; kullanıcının içerikleriyle başlığa göre eşleştirilir. */
@Serializable
class FeedItem(
    val title: String,
    val altTitle: String? = null,
    val year: Int? = null,
    val rating: Double? = null,
)

/** "Popüler Filmler" gibi bir katalog satırı. type: "movie" | "series". */
@Serializable
class FeedRow(val title: String, val type: String, val items: List<FeedItem>)

/**
 * Ana sayfa katalogları. Kaynaklar:
 *  - TMDb (anahtar ister): popüler, yeni, haftanın trendleri
 *  - Stremio Cinemeta (anahtarsız): Popüler, Yeni, Öne çıkan
 *  - İsteğe bağlı: herhangi bir Stremio eklentisinin manifest adresi
 */
object Feeds {

    enum class Mode(val label: String, val hint: String) {
        AUTO("Otomatik", "TMDb anahtarı varsa TMDb, yoksa Stremio Cinemeta"),
        TMDB("TMDb", "Türkçe başlıklarla daha iyi eşleşir • anahtar gerekir"),
        CINEMETA("Stremio Cinemeta", "Anahtar gerekmez • başlıklar İngilizce"),
        OFF("Kapalı", "Yalnızca kendi kategorilerim"),
    }

    fun resolve(mode: Mode, keys: ApiKeys): Mode = when (mode) {
        Mode.AUTO -> if (keys.tmdb.isNotBlank()) Mode.TMDB else Mode.CINEMETA
        Mode.TMDB -> if (keys.tmdb.isNotBlank()) Mode.TMDB else Mode.OFF
        else -> mode
    }

    /** Ağ hatalarında satırı atlar; hiç satır gelmezse istisna fırlatır. */
    fun load(mode: Mode, keys: ApiKeys, addonUrl: String): List<FeedRow> {
        val rows = ArrayList<FeedRow>()
        var lastError: Exception? = null
        fun safe(block: () -> FeedRow?) {
            try { block()?.let { rows += it } } catch (e: Exception) { lastError = e }
        }
        when (resolve(mode, keys)) {
            Mode.TMDB -> {
                val k = keys.tmdb.trim()
                safe { tmdb(k, "movie/popular", "Popüler Filmler", "movie") }
                safe { tmdb(k, "tv/popular", "Popüler Diziler", "series") }
                safe { tmdb(k, "movie/now_playing", "Yeni Filmler", "movie") }
                safe { tmdb(k, "tv/on_the_air", "Yeni Diziler", "series") }
                safe { tmdb(k, "trending/movie/week", "Öne Çıkan Filmler", "movie") }
                safe { tmdb(k, "trending/tv/week", "Öne Çıkan Diziler", "series") }
            }
            Mode.CINEMETA -> {
                val base = "https://v3-cinemeta.strem.io"
                safe { stremio(base, "movie", "top", "Popüler Filmler") }
                safe { stremio(base, "series", "top", "Popüler Diziler") }
                safe { stremio(base, "movie", "year", "Yeni Filmler") }
                safe { stremio(base, "series", "year", "Yeni Diziler") }
                safe { stremio(base, "movie", "imdbRating", "Öne Çıkan Filmler") }
                safe { stremio(base, "series", "imdbRating", "Öne Çıkan Diziler") }
            }
            else -> Unit
        }
        if (addonUrl.isNotBlank()) {
            try { rows += addon(addonUrl.trim()) } catch (e: Exception) { lastError = e }
        }
        if (rows.isEmpty() && lastError != null) throw lastError!!
        return rows
    }

    // ---------------------------------------------------------------- TMDb

    private fun tmdb(key: String, path: String, title: String, type: String): FeedRow? {
        val items = ArrayList<FeedItem>()
        for (page in 1..4) {
            val b = "https://api.themoviedb.org/3/$path".toHttpUrl().newBuilder()
                .addQueryParameter("language", "tr-TR")
                .addQueryParameter("page", page.toString())
            val headers = HashMap<String, String>()
            if (key.startsWith("eyJ")) headers["Authorization"] = "Bearer $key" else b.addQueryParameter("api_key", key)
            val (code, body) = Http.getRaw(b.build().toString(), headers)
            if (code == 401) error("TMDb anahtarı geçersiz")
            if (code !in 200..299) error("TMDb hatası (HTTP $code)")
            val results = (Http.json.parseToJsonElement(body) as? JsonObject)?.get("results") as? JsonArray ?: break
            for (r in results) {
                val o = r as? JsonObject ?: continue
                val name = o.s("title") ?: o.s("name") ?: continue
                val orig = o.s("original_title") ?: o.s("original_name")
                items += FeedItem(
                    title = name,
                    altTitle = orig?.takeIf { it != name },
                    year = Ratings.parseYear(o.s("release_date") ?: o.s("first_air_date")),
                    rating = o.s("vote_average")?.toDoubleOrNull()?.takeIf { it > 0 && (o.s("vote_count")?.toIntOrNull() ?: 0) >= 20 },
                )
            }
        }
        return if (items.isEmpty()) null else FeedRow(title, type, items)
    }

    // ---------------------------------------------------------------- Stremio

    private fun stremio(base: String, type: String, id: String, title: String): FeedRow? {
        val items = ArrayList<FeedItem>()
        for (skip in listOf(0, 100, 200)) {
            val path = if (skip == 0) "$base/catalog/$type/$id.json" else "$base/catalog/$type/$id/skip=$skip.json"
            val (code, body) = Http.getRaw(path)
            if (code !in 200..299) { if (skip == 0) error("Katalog alınamadı (HTTP $code)") else break }
            items += parseMetas(body)
        }
        return if (items.isEmpty()) null else FeedRow(title, type, items)
    }

    private fun parseMetas(body: String): List<FeedItem> {
        val metas = (Http.json.parseToJsonElement(body) as? JsonObject)?.get("metas") as? JsonArray ?: return emptyList()
        return metas.mapNotNull { m ->
            val o = m as? JsonObject ?: return@mapNotNull null
            val name = o.s("name") ?: return@mapNotNull null
            FeedItem(
                title = name,
                year = Ratings.parseYear(o.s("releaseInfo") ?: o.s("year")),
                rating = o.s("imdbRating")?.toDoubleOrNull(),
            )
        }
    }

    /** Herhangi bir Stremio eklentisi: manifest adresinden katalogları okur (arama/zorunlu filtre isteyenler atlanır). */
    private fun addon(manifestUrl: String): List<FeedRow> {
        val url = manifestUrl.replace("stremio://", "https://")
        val base = url.removeSuffix("/manifest.json").trimEnd('/')
        val (code, body) = Http.getRaw("$base/manifest.json")
        if (code !in 200..299) error("Eklenti bildirimi alınamadı (HTTP $code)")
        val catalogs = (Http.json.parseToJsonElement(body) as? JsonObject)?.get("catalogs") as? JsonArray ?: return emptyList()
        val out = ArrayList<FeedRow>()
        for (c in catalogs.take(8)) {
            val o = c as? JsonObject ?: continue
            val type = o.s("type") ?: continue
            if (type != "movie" && type != "series") continue
            val id = o.s("id") ?: continue
            val required = (o["extra"] as? JsonArray)?.any { (it as? JsonObject)?.s("isRequired") == "true" } == true
            if (required) continue
            val name = o.s("name") ?: id
            try {
                val (cc, bb) = Http.getRaw("$base/catalog/$type/$id.json")
                if (cc !in 200..299) continue
                val items = parseMetas(bb)
                if (items.isNotEmpty()) out += FeedRow("$name (${if (type == "movie") "Film" else "Dizi"})", type, items)
            } catch (_: Exception) { }
        }
        return out
    }
}
