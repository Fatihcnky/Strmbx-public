package com.example.streambox.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import com.example.streambox.data.Ratings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.imePadding
import com.example.streambox.data.Feeds
import com.example.streambox.SettingsDraft
import androidx.compose.material3.FilterChip
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.example.streambox.AppViewModel
import com.example.streambox.data.AccountType

@Composable
fun SettingsScreen(vm: AppViewModel, nav: NavController) {
    val account by vm.account.collectAsStateWithLifecycle()
    val catalog by vm.catalog.collectAsStateWithLifecycle()
    val askRefresh by vm.askRefreshPref.collectAsStateWithLifecycle()
    val keys by vm.keys.collectAsStateWithLifecycle()
    val source by vm.ratingSource.collectAsStateWithLifecycle()
    val feedMode by vm.feedMode.collectAsStateWithLifecycle()
    val feedAddon by vm.feedAddon.collectAsStateWithLifecycle()
    val scrub by vm.scrubPreview.collectAsStateWithLifecycle()
    val hold by vm.holdSpeed.collectAsStateWithLifecycle()
    val refreshing by vm.refreshing.collectAsStateWithLifecycle()
    val openLocal = rememberLocalVideoPicker(vm, nav)
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    // Taslak değerler: "Kaydet"e basılana kadar uygulanmaz
    val acc = account
    val savedTs = acc?.liveExt == "ts"
    var dKeys by remember(keys) { mutableStateOf(keys) }
    var dSource by remember(source) { mutableIntStateOf(source) }
    var dAsk by remember(askRefresh) { mutableStateOf(askRefresh) }
    var dTs by remember(savedTs) { mutableStateOf(savedTs) }
    var dFeed by remember(feedMode) { mutableIntStateOf(feedMode) }
    var dAddon by remember(feedAddon) { mutableStateOf(feedAddon) }
    var dScrub by remember(scrub) { mutableStateOf(scrub) }
    var dHold by remember(hold) { mutableStateOf(hold) }
    var confirmExit by remember { mutableStateOf(false) }
    var testing by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<String?>(null) }

    val dirty = dKeys != keys || dSource != source || dAsk != askRefresh || (acc != null && dTs != savedTs) ||
        dFeed != feedMode || dAddon != feedAddon || dScrub != scrub || dHold != hold

    fun save() {
        val msg = vm.saveSettings(
            SettingsDraft(
                keys = dKeys, ratingSource = dSource, askRefresh = dAsk,
                liveTs = if (acc?.type == AccountType.XTREAM) dTs else null,
                feedMode = dFeed, feedAddon = dAddon, scrubPreview = dScrub, holdSpeed = dHold,
            )
        )
        Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
    }

    fun discard() {
        dKeys = keys; dSource = source; dAsk = askRefresh; dTs = savedTs
        dFeed = feedMode; dAddon = feedAddon; dScrub = scrub; dHold = hold
    }

    fun back() {
        if (dirty) confirmExit = true else nav.popBackStack()
    }

    BackHandler(enabled = dirty) { confirmExit = true }

    Box(Modifier.fillMaxSize().imePadding()) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { back() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                }
                Text("Ayarlar", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }

            if (acc != null) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(acc.name.ifBlank { "Listem" }, fontWeight = FontWeight.SemiBold)
                    Text(
                        if (acc.type == AccountType.XTREAM) "Xtream Codes • ${acc.server}" else "M3U listesi",
                        color = Color.Gray,
                    )
                    catalog?.let {
                        Text(
                            "${it.live.size} kanal • ${it.movies.size} film • ${it.series.size} dizi",
                            color = Color.Gray,
                        )
                    }
                }

                if (acc.type == AccountType.XTREAM) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Canlı yayında .ts kullan")
                            Text(
                                "Kanallar açılmıyorsa deneyin (varsayılan: m3u8/HLS). Kaydedince liste yenilenir.",
                                color = Color.Gray, style = MaterialTheme.typography.bodySmall,
                            )
                        }
                        Switch(checked = dTs, onCheckedChange = { dTs = it })
                    }
                }
            }

            HorizontalDivider()
            Text("Liste güncelleme", fontWeight = FontWeight.SemiBold)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Açılışta güncelleme sor")
                    Text(
                        "Kapalıysa uygulama kayıtlı listeyi kullanır; güncellemek için aşağıdaki düğmeye basın.",
                        color = Color.Gray, style = MaterialTheme.typography.bodySmall,
                    )
                }
                Switch(checked = dAsk, onCheckedChange = { dAsk = it })
            }
            OutlinedButton(
                onClick = { vm.loadCatalog(); nav.popBackStack() },
                enabled = !refreshing && !dirty,
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (refreshing) "Güncelleniyor..." else "Listeyi şimdi güncelle") }

            HorizontalDivider()
            Text("Cihazdaki videolar", fontWeight = FontWeight.SemiBold)
            OutlinedButton(onClick = openLocal, modifier = Modifier.fillMaxWidth()) {
                Text("Cihazdan video aç")
            }
            Text(
                "Birden fazla dosya seçersen ada göre sıralı oynatma listesi olur. Oynatıcıda Altyazı > Cihazdan ekle ile .srt/.vtt/.ass dosyası ekleyebilirsin.",
                color = Color.Gray, style = MaterialTheme.typography.bodySmall,
            )

            HorizontalDivider()
            Text("Altyazı servisleri (isteğe bağlı)", fontWeight = FontWeight.SemiBold)
            Text(
                "Online altyazı aramak için kendi API anahtarını gir. SubDL anahtarı ücretsizdir. " +
                    "OpenSubtitles indirme için kullanıcı adı ve şifre ister. Bilgiler yalnızca bu cihazda saklanır.",
                color = Color.Gray, style = MaterialTheme.typography.bodySmall,
            )
            OutlinedTextField(
                value = dKeys.subdl, onValueChange = { dKeys = dKeys.copy(subdl = it) },
                singleLine = true, label = { Text("SubDL API anahtarı") }, modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = dKeys.osKey, onValueChange = { dKeys = dKeys.copy(osKey = it) },
                singleLine = true, label = { Text("OpenSubtitles API anahtarı") }, modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = dKeys.osUser, onValueChange = { dKeys = dKeys.copy(osUser = it) },
                singleLine = true, label = { Text("OpenSubtitles kullanıcı adı") }, modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = dKeys.osPass, onValueChange = { dKeys = dKeys.copy(osPass = it) },
                singleLine = true, label = { Text("OpenSubtitles şifre") },
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(),
            )

            HorizontalDivider()
            Text("Puan kaynağı", fontWeight = FontWeight.SemiBold)
            Text(
                "Film ve dizi kartlarındaki ★ puanı buradan çekilir. Listenizin kendi puanı çoğu zaman her içerik için 10 yazıyor; " +
                    "bu yüzden güvenilir sayılmaz. Kaynaklar public-apis listesinden seçildi.",
                color = Color.Gray, style = MaterialTheme.typography.bodySmall,
            )
            Ratings.Source.entries.forEachIndexed { i, src ->
                Row(
                    Modifier.fillMaxWidth().clickable { dSource = i },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RadioButton(selected = dSource == i, onClick = { dSource = i })
                    Column(Modifier.weight(1f)) {
                        Text(src.label)
                        Text(src.hint, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            OutlinedTextField(
                value = dKeys.omdb, onValueChange = { dKeys = dKeys.copy(omdb = it) },
                singleLine = true, label = { Text("OMDb API anahtarı (omdbapi.com)") }, modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = dKeys.tmdb, onValueChange = { dKeys = dKeys.copy(tmdb = it) },
                singleLine = true, label = { Text("TMDb API anahtarı veya okuma jetonu") }, modifier = Modifier.fillMaxWidth(),
            )
            OutlinedButton(
                onClick = {
                    testing = true
                    testResult = null
                    scope.launch {
                        testResult = withContext(Dispatchers.IO) {
                            runCatching { Ratings.test(Ratings.Source.entries[dSource], dKeys.copy(omdb = dKeys.omdb.trim(), tmdb = dKeys.tmdb.trim())) }
                                .getOrElse { "Hata: ${it.message}" }
                        }
                        testing = false
                    }
                },
                enabled = !testing,
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (testing) "Test ediliyor..." else "Seçili kaynağı test et (kaydetmeden)") }
            testResult?.let { Text(it, style = MaterialTheme.typography.bodySmall) }

            HorizontalDivider()
            Text("Ana sayfa katalogları", fontWeight = FontWeight.SemiBold)
            Text(
                "Popüler / Yeni / Öne çıkan film ve diziler, listendeki içeriklerle eşleştirilip ana sayfada gösterilir. " +
                    "Yalnızca listende bulunan yapımlar çıkar. Başlıkların eşleşmesi için TMDb (Türkçe başlık) daha başarılıdır.",
                color = Color.Gray, style = MaterialTheme.typography.bodySmall,
            )
            Feeds.Mode.entries.forEachIndexed { i, mode ->
                Row(
                    Modifier.fillMaxWidth().clickable { dFeed = i },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RadioButton(selected = dFeed == i, onClick = { dFeed = i })
                    Column(Modifier.weight(1f)) {
                        Text(mode.label)
                        Text(mode.hint, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            OutlinedTextField(
                value = dAddon, onValueChange = { dAddon = it },
                singleLine = true,
                label = { Text("Ek Stremio eklentisi (manifest adresi, isteğe bağlı)") },
                placeholder = { Text("https://.../manifest.json") },
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                "Stremio eklentilerinin katalogları (film/dizi) ana sayfaya satır olarak eklenir. Anahtar gerektirmeyenler çalışır.",
                color = Color.Gray, style = MaterialTheme.typography.bodySmall,
            )

            HorizontalDivider()
            Text("İçerik seçimi", fontWeight = FontWeight.SemiBold)
            OutlinedButton(
                onClick = { nav.navigate("content") },
                enabled = !dirty,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Kategorileri ve ana sayfa satırlarını seç") }
            Text(
                if (dirty) "Önce yaptığın değişiklikleri kaydet." else
                    "İstemediğin canlı TV / film / dizi kategorilerini kaldır; yenilemede mümkünse hiç indirilmez. Ana sayfada hangi satırların görüneceğini de buradan seçersin.",
                color = Color.Gray, style = MaterialTheme.typography.bodySmall,
            )

            HorizontalDivider()
            Text("Oynatıcı", fontWeight = FontWeight.SemiBold)
            Text("Ekrana basılı tutunca hız", style = MaterialTheme.typography.bodyMedium)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1.25f, 1.5f, 2f, 2.5f, 3f, 4f).forEach { v ->
                    FilterChip(
                        selected = dHold == v,
                        onClick = { dHold = v },
                        label = { Text(("%.2f".format(java.util.Locale.US, v)).trimEnd('0').trimEnd('.') + "x") },
                    )
                }
            }
            Text(
                "Film/dizi oynatırken ekrana parmağını basılı tutarsan bu hızda oynar, bırakınca normale döner (canlı yayında çalışmaz).",
                color = Color.Gray, style = MaterialTheme.typography.bodySmall,
            )
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Sarma çubuğunda küçük resim önizleme")
                    Text(
                        "Çubuğu sürüklerken o anın görüntüsünü gösterir. Kısa süreli ikinci bir bağlantı açar; " +
                            "listen aynı anda tek bağlantıya izin veriyorsa yayın hata verirse kapat.",
                        color = Color.Gray, style = MaterialTheme.typography.bodySmall,
                    )
                }
                Switch(checked = dScrub, onCheckedChange = { dScrub = it })
            }

            HorizontalDivider()
            OutlinedButton(onClick = { vm.clearHistory() }, modifier = Modifier.fillMaxWidth()) {
                Text("İzleme geçmişini temizle")
            }
            Button(
                onClick = {
                    vm.logout()
                    nav.navigate("login") { popUpTo(0) }
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Çıkış yap") }
        }

        // Kaydet çubuğu: değişiklik var mı yok mu her zaman görünür
        Surface(
            color = Color(0xFF1E1E2A),
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth(),
            shadowElevation = 8.dp,
        ) {
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 10.dp).navigationBarsPadding(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    if (dirty) "Kaydedilmemiş değişiklikler var" else "✓ Tüm ayarlar kayıtlı",
                    color = if (dirty) Color(0xFFFFC107) else Color(0xFF66BB6A),
                    fontSize = 13.sp, modifier = Modifier.weight(1f),
                )
                if (dirty) {
                    TextButton(onClick = { discard() }) { Text("Vazgeç") }
                }
                Button(onClick = { save() }, enabled = dirty) { Text("Kaydet") }
            }
        }
    }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("Değişiklikler kaydedilmedi") },
            text = { Text("Kaydetmeden çıkarsan yaptığın değişiklikler uygulanmaz.") },
            confirmButton = {
                TextButton(onClick = { save(); confirmExit = false; nav.popBackStack() }) { Text("Kaydet ve çık") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { confirmExit = false }) { Text("Vazgeç") }
                    TextButton(onClick = { confirmExit = false; nav.popBackStack() }) { Text("Kaydetmeden çık") }
                }
            },
        )
    }
}
