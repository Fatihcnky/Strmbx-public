package com.example.streambox

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.streambox.data.Account
import com.example.streambox.data.AccountType
import com.example.streambox.data.ApiKeys
import com.example.streambox.data.AppDb
import com.example.streambox.data.Catalog
import com.example.streambox.data.CatalogCache
import com.example.streambox.data.Episode
import com.example.streambox.data.EpgItem
import com.example.streambox.data.FavoriteEntity
import com.example.streambox.data.HistoryEntity
import com.example.streambox.data.Movie
import com.example.streambox.data.PlayItem
import com.example.streambox.data.PlayRequest
import com.example.streambox.data.ContentFilter
import com.example.streambox.data.FeedRow
import com.example.streambox.data.applyFilter
import com.example.streambox.data.Feeds
import com.example.streambox.data.PlayerSettings
import com.example.streambox.data.Ratings
import com.example.streambox.data.Repository
import com.example.streambox.data.Series
import com.example.streambox.data.XmltvParser
import com.example.streambox.data.XtreamApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/** Ayarlar ekranındaki "Kaydet" ile birlikte uygulanan değerler. */
data class SettingsDraft(
    val keys: ApiKeys,
    val ratingSource: Int,
    val askRefresh: Boolean,
    val liveTs: Boolean?,
    val feedMode: Int,
    val feedAddon: String,
    val scrubPreview: Boolean,
    val holdSpeed: Float,
)

class AppViewModel(private val app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("streambox", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true }
    private val dao = AppDb.get(app).dao()

    val account = MutableStateFlow(
        prefs.getString("account", null)?.let { runCatching { json.decodeFromString<Account>(it) }.getOrNull() }
    )
    val catalog = MutableStateFlow<Catalog?>(null)

    /** Tam ekran yükleme (henüz hiç katalog yokken). */
    val loading = MutableStateFlow(account.value != null)

    /** Katalog gösterilirken arka planda yenileme sürüyor. */
    val refreshing = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)

    /** Kısa bildirim (toast) metni; arayüz gösterip null'lar. */
    val notice = MutableStateFlow<String?>(null)

    /** Açılışta "listeyi güncelleyelim mi?" sorusu. */
    val askRefresh = MutableStateFlow(false)
    val askRefreshPref = MutableStateFlow(prefs.getBoolean("ask_refresh", true))
    val lastUpdated = MutableStateFlow(prefs.getLong("last_updated", 0L))

    /** epgId -> yaklaşan programlar (XMLTV). */
    val epg = MutableStateFlow<Map<String, List<EpgItem>>>(emptyMap())

    val favorites: StateFlow<List<FavoriteEntity>> =
        dao.favorites().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val history: StateFlow<List<HistoryEntity>> =
        dao.history().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val playerSettings = MutableStateFlow(
        PlayerSettings(
            resize = prefs.getInt("p_resize2", 0),
            subSize = prefs.getInt("p_sub_size", 1),
            subColor = prefs.getInt("p_sub_color", 0),
            subBg = prefs.getInt("p_sub_bg", 1),
            subEdge = prefs.getInt("p_sub_edge", 2),
        )
    )

    val keys = MutableStateFlow(
        ApiKeys(
            subdl = prefs.getString("k_subdl", "").orEmpty(),
            osKey = prefs.getString("k_os_key", "").orEmpty(),
            osUser = prefs.getString("k_os_user", "").orEmpty(),
            osPass = prefs.getString("k_os_pass", "").orEmpty(),
            omdb = prefs.getString("k_omdb", "").orEmpty(),
            tmdb = prefs.getString("k_tmdb", "").orEmpty(),
        )
    )

    val ratingSource = MutableStateFlow(prefs.getInt("rating_source", 0).coerceIn(0, Ratings.Source.entries.lastIndex))

    /** Küçük harfli temiz başlık -> IMDb puanı (OMDb anahtarı girildiyse doldurulur). */
    val imdb = MutableStateFlow(
        prefs.getString("imdb_cache2", null)
            ?.let { runCatching { json.decodeFromString<Map<String, Double>>(it) }.getOrNull() }
            ?: emptyMap()
    )

    // Ana sayfa katalogları (TMDb / Stremio)
    val feedMode = MutableStateFlow(prefs.getInt("feed_mode", 0).coerceIn(0, Feeds.Mode.entries.lastIndex))
    val feedAddon = MutableStateFlow(prefs.getString("feed_addon", "").orEmpty())
    val feeds = MutableStateFlow<List<FeedRow>>(
        prefs.getString("feeds_cache", null)
            ?.let { runCatching { json.decodeFromString<List<FeedRow>>(it) }.getOrNull() }
            ?: emptyList()
    )
    val feedsLoading = MutableStateFlow(false)

    /** Gizlenen kategoriler: listeden çıkarılır ve mümkünse yenilemede indirilmez. */
    val contentFilter = MutableStateFlow(
        prefs.getString("content_filter", null)
            ?.let { runCatching { json.decodeFromString<ContentFilter>(it) }.getOrNull() }
            ?: ContentFilter()
    )

    /** Ana sayfada gizlenen satırların kimlikleri ("live", "continue", "feed:Popüler Filmler", "mcat:12" ...). */
    val homeHidden = MutableStateFlow(prefs.getStringSet("home_hidden", emptySet()).orEmpty().toSet())

    /** Ekrana basılı tutunca uygulanan oynatma hızı. */
    val holdSpeed = MutableStateFlow(prefs.getFloat("hold_speed", 2f))

    /** "Daha fazla" ekranında gösterilecek satır. */
    var moreTitle: String = ""
    var moreTiles: List<com.example.streambox.ui.Tile> = emptyList()

    /** Oynatıcıda sarma çubuğunu sürüklerken küçük resim önizlemesi. */
    val scrubPreview = MutableStateFlow(prefs.getBoolean("scrub_preview", true))

    /** Küçük harfli temiz başlık -> yapım yılı (puan servislerinden öğrenilir). */
    val years = MutableStateFlow(
        prefs.getString("years_cache2", null)
            ?.let { runCatching { json.decodeFromString<Map<String, Int>>(it) }.getOrNull() }
            ?: emptyMap()
    )

    // Ekranlar arası geçiş için seçili öğeler
    var selectedMovie: Movie? = null
    var selectedSeries: Series? = null
    var playRequest: PlayRequest? = null

    init {
        val acc = account.value
        if (acc != null) {
            viewModelScope.launch {
                val cached = withContext(Dispatchers.IO) { CatalogCache.load(app, acc) }
                if (cached != null) {
                    catalog.value = cached
                    loading.value = false
                    loadEpg(cached)
                    enrichRatings(cached)
                    loadFeeds()
                    if (askRefreshPref.value) askRefresh.value = true
                } else {
                    loadCatalog()
                }
            }
        }
    }

    // ------------------------------------------------------------------ Yükleme

    /**
     * Kataloğu ağdan yükler. [progressive] doğruysa bölümler bittikçe ekrana yansır;
     * değilse (yenileme) eski liste görünmeye devam eder ve iş bitince değişir.
     */
    private suspend fun runLoad(acc: Account, progressive: Boolean, onFirst: () -> Unit) {
        val old = catalog.value
        var first = true
        var epgStarted = false
        val result = Repository.load(acc, contentFilter.value, old) { c ->
            if (progressive) catalog.value = c
            if (first) {
                first = false
                if (progressive) loading.value = false
                viewModelScope.launch { onFirst() }
            }
            if (progressive && !epgStarted && c.live.isNotEmpty()) {
                epgStarted = true
                loadEpg(c)
            }
        }
        val merged = merge(old, result)
        catalog.value = merged
        if (!progressive) loadEpg(merged)
        enrichRatings(merged)
        loadFeeds()

        if (merged.live.isNotEmpty() || merged.movies.isNotEmpty() || merged.series.isNotEmpty()) {
            withContext(Dispatchers.IO) { CatalogCache.save(app, acc, merged) }
            val now = System.currentTimeMillis()
            prefs.edit().putLong("last_updated", now).apply()
            lastUpdated.value = now
        }
    }

    /** Yenilemede bir bölüm indirilemediyse eski verisini koru. */
    private fun merge(old: Catalog?, n: Catalog): Catalog {
        if (old == null) return n
        val liveKeep = "live" in n.errors && n.live.isEmpty()
        val movieKeep = "movies" in n.errors && n.movies.isEmpty()
        val seriesKeep = "series" in n.errors && n.series.isEmpty()
        val merged = n.copy(
            liveCategories = if (liveKeep) old.liveCategories else n.liveCategories,
            live = if (liveKeep) old.live else n.live,
            movieCategories = if (movieKeep) old.movieCategories else n.movieCategories,
            movies = if (movieKeep) old.movies else n.movies,
            seriesCategories = if (seriesKeep) old.seriesCategories else n.seriesCategories,
            series = if (seriesKeep) old.series else n.series,
        )
        val stillBroken = buildMap {
            if (merged.live.isEmpty()) n.errors["live"]?.let { put("live", it) }
            if (merged.movies.isEmpty()) n.errors["movies"]?.let { put("movies", it) }
            if (merged.series.isEmpty()) n.errors["series"]?.let { put("series", it) }
        }
        return merged.copy(errors = stillBroken)
    }

    /** Listeyi yeniden indirir. Elde liste varsa o görünmeye devam eder. */
    fun loadCatalog() {
        val acc = account.value ?: return
        if (refreshing.value) return
        viewModelScope.launch {
            val had = catalog.value != null
            if (had) refreshing.value = true else loading.value = true
            error.value = null
            try {
                runLoad(acc, progressive = !had) { }
                if (had) notice.value = "Liste güncellendi"
            } catch (e: Exception) {
                if (had) notice.value = "Liste güncellenemedi: ${friendly(e)}" else error.value = friendly(e)
            }
            loading.value = false
            refreshing.value = false
        }
    }

    fun confirmRefresh() {
        askRefresh.value = false
        loadCatalog()
    }

    fun dismissRefresh() {
        askRefresh.value = false
    }

    fun setAskRefreshPref(v: Boolean) {
        askRefreshPref.value = v
        prefs.edit().putBoolean("ask_refresh", v).apply()
    }

    fun login(acc: Account, onDone: () -> Unit) {
        viewModelScope.launch {
            loading.value = true
            error.value = null
            catalog.value = null
            try {
                // Önbellek bu hesaba göre kaydedildiği için hesabı önce yaz
                prefs.edit().putString("account", json.encodeToString(acc)).apply()
                account.value = acc
                runLoad(acc, progressive = true) { onDone() }
            } catch (e: Exception) {
                prefs.edit().remove("account").apply()
                account.value = null
                error.value = friendly(e)
            }
            loading.value = false
        }
    }

    fun updateAccount(acc: Account) {
        prefs.edit().putString("account", json.encodeToString(acc)).apply()
        account.value = acc
        loadCatalog()
    }

    fun logout() {
        account.value?.let { CatalogCache.delete(app, it) }
        prefs.edit().remove("account").remove("last_updated").remove("content_filter").apply()
        contentFilter.value = ContentFilter()
        account.value = null
        catalog.value = null
        epg.value = emptyMap()
        error.value = null
        askRefresh.value = false
    }

    fun clearHistory() {
        viewModelScope.launch { dao.clearHistory() }
    }

    private fun loadEpg(cat: Catalog) {
        val url = cat.epgUrl ?: return
        val wanted = cat.live.mapNotNull { it.epgId }.toSet()
        if (wanted.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { XmltvParser.parse(url, wanted) }.onSuccess { epg.value = it }
        }
    }

    // ------------------------------------------------------------------ Puanlar

    private val pendingRatings = HashMap<String, Double>()
    private val pendingYears = HashMap<String, Int>()
    private val inflight = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    private val ratingGate = kotlinx.coroutines.sync.Semaphore(3)
    private var flushJob: kotlinx.coroutines.Job? = null
    @Volatile private var ratingGen = 0
    @Volatile private var ratingFailures = 0
    @Volatile private var ratingPausedUntil = 0L

    /**
     * Bir başlığın puanını (henüz yoksa) seçili kaynaktan ister. Ekranda görünen kartlar çağırır;
     * aynı başlık tekrar istenmez, en fazla 3 istek aynı anda çalışır.
     */
    fun requestRating(name: String, type: String) {
        val src = Ratings.Source.entries[ratingSource.value]
        val k = Ratings.key(name)
        if (k.isBlank() || imdb.value.containsKey(k)) return
        if (System.currentTimeMillis() < ratingPausedUntil) return
        if (!Ratings.canFetch(src, keys.value, type)) return
        if (!inflight.add(k)) return
        val gen = ratingGen
        val keysNow = keys.value
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val v = ratingGate.withPermit { Ratings.fetch(src, keysNow, name, type) }
                if (gen == ratingGen) {
                    ratingFailures = 0
                    storeMeta(k, v?.rating ?: -1.0, v?.year)
                }
            } catch (e: Exception) {
                // Anahtar/limit/ağ sorunu: önbelleğe alma, art arda hatada bir süre dur
                if (++ratingFailures >= 5) {
                    ratingPausedUntil = System.currentTimeMillis() + 60_000
                    ratingFailures = 0
                }
            } finally {
                inflight.remove(k)
            }
        }
    }

    /** Katalog eşleşmelerinden (TMDb/Cinemeta) gelen puan ve yılı, henüz bilinmiyorsa kaydeder. */
    fun seedMeta(key: String, rating: Double?, year: Int?) {
        if (key.isBlank()) return
        val needRating = rating != null && rating > 0 && imdb.value[key].let { it == null || it <= 0 }
        val needYear = year != null && !years.value.containsKey(key)
        if (needRating || needYear) storeMeta(key, if (needRating) rating!! else (imdb.value[key] ?: -1.0), year)
    }

    /** Sonuçlar toplu yazılır: ekran her puanda yeniden çizilmesin, hero afişler sürekli karışmasın. */
    private fun storeMeta(k: String, v: Double, year: Int?) {
        synchronized(pendingRatings) {
            pendingRatings[k] = v
            if (year != null) pendingYears[k] = year
        }
        if (flushJob?.isActive == true) return
        flushJob = viewModelScope.launch(Dispatchers.IO) {
            kotlinx.coroutines.delay(1500)
            val (rb, yb) = synchronized(pendingRatings) {
                val r = HashMap(pendingRatings); val y = HashMap(pendingYears)
                pendingRatings.clear(); pendingYears.clear()
                r to y
            }
            if (rb.isEmpty() && yb.isEmpty()) return@launch
            val mr = imdb.value + rb
            val my = years.value + yb
            imdb.value = mr
            years.value = my
            prefs.edit()
                .putString("imdb_cache2", json.encodeToString(mr))
                .putString("years_cache2", json.encodeToString(my))
                .apply()
        }
    }

    /** Ana sayfa önerileri için en umut verici başlıkların puanlarını önceden ister. */
    fun enrichRatings(cat: Catalog) {
        val src = Ratings.Source.entries[ratingSource.value]
        if (!Ratings.canFetch(src, keys.value, "movie") && !Ratings.canFetch(src, keys.value, "series")) return
        viewModelScope.launch(Dispatchers.Default) {
            class C(val name: String, val rating: Double, val type: String)
            val withRating = buildList {
                cat.movies.forEach { m -> Ratings.providerRating(m.rating)?.takeIf { it >= 6.0 }?.let { add(C(m.name, it, "movie")) } }
                cat.series.forEach { s -> Ratings.providerRating(s.rating)?.takeIf { it >= 6.0 }?.let { add(C(s.name, it, "series")) } }
            }.sortedByDescending { it.rating }.take(60)
            // Liste puan vermiyorsa (ör. hepsi 10) afişi olan rastgele başlıklardan örnekle
            val extra = if (withRating.size < 30) {
                (cat.movies.filter { !it.poster.isNullOrBlank() }.shuffled().take(25).map { C(it.name, 0.0, "movie") } +
                    cat.series.filter { !it.poster.isNullOrBlank() }.shuffled().take(25).map { C(it.name, 0.0, "series") })
            } else emptyList()
            (withRating + extra).forEach { requestRating(it.name, it.type) }
        }
    }

    // ------------------------------------------------------------------ İçerik seçimi

    /**
     * Gizlenen kategorileri ve ana sayfa satırlarını kaydeder.
     * Yeni gizlenenler hemen listeden çıkar; geri açılanlar için liste arka planda yenilenir.
     */
    fun saveContentSelection(filter: ContentFilter, homeOff: Set<String>): String {
        val old = contentFilter.value
        val unhidden = (old.hiddenLive - filter.hiddenLive).isNotEmpty() ||
            (old.hiddenMovies - filter.hiddenMovies).isNotEmpty() ||
            (old.hiddenSeries - filter.hiddenSeries).isNotEmpty()
        contentFilter.value = filter
        homeHidden.value = homeOff
        prefs.edit()
            .putString("content_filter", json.encodeToString(filter))
            .putStringSet("home_hidden", homeOff)
            .apply()
        val cur = catalog.value
        if (cur != null && filter != old) {
            val filtered = cur.applyFilter(filter)
            catalog.value = filtered
            account.value?.let { acc ->
                viewModelScope.launch(Dispatchers.IO) { CatalogCache.save(app, acc, filtered) }
            }
        }
        if (unhidden) {
            loadCatalog()
            return "Kaydedildi. Geri açılan kategoriler için liste yenileniyor"
        }
        return if (filter != old) "Kaydedildi. Gizlenen kategoriler artık listelenmeyecek ve yenilemede mümkünse indirilmeyecek"
        else "Kaydedildi"
    }

    // ------------------------------------------------------------------ Ana sayfa katalogları

    private fun feedSignature(): String =
        "${feedMode.value}|${keys.value.tmdb.isNotBlank()}|${feedAddon.value}"

    /** Katalogları ağdan çeker. Önbellek 12 saat geçerli; [force] ile (ayarlar değişince) yenilenir. */
    fun loadFeeds(force: Boolean = false) {
        if (feedsLoading.value) return
        val fresh = System.currentTimeMillis() - prefs.getLong("feeds_time", 0L) < 12 * 3600_000L
        if (!force && fresh && prefs.getString("feeds_sig", "") == feedSignature() && feeds.value.isNotEmpty()) return
        val mode = Feeds.Mode.entries[feedMode.value]
        if (Feeds.resolve(mode, keys.value) == Feeds.Mode.OFF && feedAddon.value.isBlank()) {
            feeds.value = emptyList()
            prefs.edit().remove("feeds_cache").apply()
            return
        }
        feedsLoading.value = true
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val rows = Feeds.load(mode, keys.value, feedAddon.value)
                feeds.value = rows
                prefs.edit()
                    .putString("feeds_cache", json.encodeToString(rows))
                    .putLong("feeds_time", System.currentTimeMillis())
                    .putString("feeds_sig", feedSignature())
                    .apply()
            } catch (e: Exception) {
                // Ağ yoksa eski önbellek kullanılmaya devam eder
            } finally {
                feedsLoading.value = false
            }
        }
    }

    private val seasonCache = java.util.concurrent.ConcurrentHashMap<String, Int>()

    /** Dizinin sezon sayısı (Xtream bölüm listesinden); öneri afişinde gösterilir. */
    suspend fun seasonCount(s: Series): Int? {
        seasonCache[s.id]?.let { return it }
        val acc = account.value ?: return null
        if (acc.type != AccountType.XTREAM) return null
        return withContext(Dispatchers.IO) {
            runCatching { XtreamApi(acc).seriesEpisodes(s.id).size }.getOrNull()
        }?.takeIf { it > 0 }?.also { seasonCache[s.id] = it }
    }

    // ------------------------------------------------------------------ Ayarlar

    fun updatePlayerSettings(s: PlayerSettings) {
        playerSettings.value = s
        prefs.edit()
            .putInt("p_resize2", s.resize)
            .putInt("p_sub_size", s.subSize)
            .putInt("p_sub_color", s.subColor)
            .putInt("p_sub_bg", s.subBg)
            .putInt("p_sub_edge", s.subEdge)
            .apply()
    }

    /**
     * Ayarlar ekranındaki "Kaydet". @return kullanıcıya gösterilecek özet.
     * Puan kaynağı/anahtarı değiştiyse eski puan önbelleği silinir ve yeniden çekilir.
     */
    fun saveSettings(d: SettingsDraft): String {
        val k = d.keys
        val source = d.ratingSource
        val ask = d.askRefresh
        val liveTs = d.liveTs
        val feedModeIdx = d.feedMode
        val addon = d.feedAddon
        val scrub = d.scrubPreview
        holdSpeed.value = d.holdSpeed
        prefs.edit().putFloat("hold_speed", d.holdSpeed).apply()
        val clean = k.copy(
            subdl = k.subdl.trim(), osKey = k.osKey.trim(), osUser = k.osUser.trim(),
            omdb = k.omdb.trim(), tmdb = k.tmdb.trim(),
        )
        val oldTmdbSet = keys.value.tmdb.isNotBlank()
        val ratingChanged = clean.omdb != keys.value.omdb || clean.tmdb != keys.value.tmdb || source != ratingSource.value
        keys.value = clean
        ratingSource.value = source
        prefs.edit()
            .putString("k_subdl", clean.subdl)
            .putString("k_os_key", clean.osKey)
            .putString("k_os_user", clean.osUser)
            .putString("k_os_pass", clean.osPass)
            .putString("k_omdb", clean.omdb)
            .putString("k_tmdb", clean.tmdb)
            .putInt("rating_source", source)
            .apply()
        setAskRefreshPref(ask)
        scrubPreview.value = scrub
        prefs.edit().putBoolean("scrub_preview", scrub).apply()

        val feedChanged = feedModeIdx != feedMode.value || addon.trim() != feedAddon.value ||
            (clean.tmdb.isNotBlank() != oldTmdbSet)
        feedMode.value = feedModeIdx
        feedAddon.value = addon.trim()
        prefs.edit().putInt("feed_mode", feedModeIdx).putString("feed_addon", addon.trim()).apply()

        val notes = ArrayList<String>()
        if (feedChanged) {
            loadFeeds(force = true)
            notes += "katalogler yenileniyor"
        }
        if (ratingChanged) {
            ratingGen++
            inflight.clear()
            synchronized(pendingRatings) { pendingRatings.clear(); pendingYears.clear() }
            ratingFailures = 0
            ratingPausedUntil = 0L
            imdb.value = emptyMap()
            prefs.edit().remove("imdb_cache2").apply()
            catalog.value?.let { enrichRatings(it) }
            notes += "puanlar yeniden çekiliyor"
        }
        val acc = account.value
        if (acc != null && liveTs != null && (acc.liveExt == "ts") != liveTs) {
            updateAccount(acc.copy(liveExt = if (liveTs) "ts" else "m3u8"))
            notes += "liste yenileniyor"
        }
        return "Ayarlar kaydedildi" + if (notes.isEmpty()) "" else " (" + notes.joinToString(", ") + ")"
    }

    // ------------------------------------------------------------------ Favori / geçmiş

    fun toggleFavorite(key: String, kind: String, title: String, image: String?) {
        viewModelScope.launch {
            if (favorites.value.any { it.itemKey == key }) {
                dao.removeFavorite(key)
            } else {
                dao.addFavorite(FavoriteEntity(key, kind, title, image, System.currentTimeMillis()))
            }
        }
    }

    fun saveProgress(item: PlayItem, positionMs: Long, durationMs: Long) {
        if (item.kind == "live" || durationMs <= 0) return
        viewModelScope.launch {
            dao.saveHistory(
                HistoryEntity(
                    itemKey = item.key, kind = item.kind, title = item.title, image = item.image,
                    url = item.url, positionMs = positionMs, durationMs = durationMs,
                    updatedAt = System.currentTimeMillis(),
                )
            )
        }
    }

    suspend fun movieInfo(m: Movie): com.example.streambox.data.VodInfo? {
        val acc = account.value ?: return null
        if (acc.type != AccountType.XTREAM) return null
        return withContext(Dispatchers.IO) { XtreamApi(acc).vodInfo(m.id) }
    }

    suspend fun seriesEpisodes(s: Series): Map<Int, List<Episode>> {
        val acc = account.value ?: return emptyMap()
        return withContext(Dispatchers.IO) { XtreamApi(acc).seriesEpisodes(s.id) }
    }

    /** Bir kanalın yaklaşan programları: önce XMLTV, yoksa Xtream kısa EPG. */
    suspend fun guideFor(item: PlayItem): List<EpgItem> {
        val now = System.currentTimeMillis()
        item.epgId?.let { id ->
            val fromXmltv = epg.value[id]?.filter { it.endMs > now }.orEmpty()
            if (fromXmltv.isNotEmpty()) return fromXmltv.take(8)
        }
        val acc = account.value ?: return emptyList()
        val sid = item.streamId
        if (acc.type != AccountType.XTREAM || sid == null) return emptyList()
        return withContext(Dispatchers.IO) {
            runCatching { XtreamApi(acc).shortEpg(sid).filter { it.endMs > now } }.getOrDefault(emptyList())
        }
    }

    private fun friendly(e: Exception): String = when (e) {
        is UnknownHostException -> "Sunucuya ulaşılamadı. Adresi ve internet bağlantınızı kontrol edin."
        is SocketTimeoutException -> "Bağlantı zaman aşımına uğradı."
        is IllegalArgumentException -> "Adres geçersiz. http:// veya https:// ile başlayan tam adresi girin."
        else -> e.message ?: "Bilinmeyen hata"
    }
}
