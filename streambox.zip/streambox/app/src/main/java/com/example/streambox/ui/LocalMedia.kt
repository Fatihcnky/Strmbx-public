package com.example.streambox.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import com.example.streambox.AppViewModel
import com.example.streambox.data.PlayItem
import com.example.streambox.data.PlayRequest

fun displayName(ctx: Context, uri: Uri): String? =
    runCatching {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }
    }.getOrNull()

/**
 * Cihazdaki video dosyasını (birden fazla seçilirse ada göre sıralı oynatma listesi) açan
 * seçiciyi döndürür. Dönen işlev çağrılınca dosya seçici açılır.
 */
@Composable
fun rememberLocalVideoPicker(vm: AppViewModel, nav: NavController): () -> Unit {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@rememberLauncherForActivityResult
        val items = uris.map { uri ->
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val name = displayName(ctx, uri) ?: "Video"
            name to PlayItem(
                kind = "local",
                key = uri.toString(),
                title = name.substringBeforeLast('.'),
                subtitle = "Cihazdan",
                image = null,
                url = uri.toString(),
            )
        }.sortedBy { it.first.lowercase() }.map { it.second }

        vm.playRequest = PlayRequest(items, 0)
        nav.navigate("player")
    }
    return { launcher.launch(arrayOf("video/*")) }
}
