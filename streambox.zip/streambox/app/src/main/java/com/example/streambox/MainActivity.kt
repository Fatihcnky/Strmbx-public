package com.example.streambox

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.streambox.ui.Bg
import com.example.streambox.ui.ContentScreen
import com.example.streambox.ui.MoreScreen
import com.example.streambox.ui.LocalRatings
import com.example.streambox.ui.RatingCtx
import com.example.streambox.ui.PipState
import com.example.streambox.ui.enterPip
import com.example.streambox.ui.LoginScreen
import com.example.streambox.ui.MainScreen
import com.example.streambox.ui.MovieDetailScreen
import com.example.streambox.ui.PlayerScreen
import com.example.streambox.ui.SeriesDetailScreen
import com.example.streambox.ui.SettingsScreen
import com.example.streambox.ui.StreamTheme

class MainActivity : ComponentActivity() {
    // Oynatıcı açıkken Ana Ekran tuşuna basınca pencerede videoyu küçültüp oynatmaya devam et
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (PipState.allowed) enterPip(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            StreamTheme {
                // Koyu zemin + açık yazı rengi; bunun dışında Text varsayılan olarak siyah kalır
                Surface(Modifier.fillMaxSize(), color = Bg, contentColor = Color.White) {
                    AppRoot()
                }
            }
        }
    }
}

@Composable
fun AppRoot(vm: AppViewModel = viewModel()) {
    val nav = rememberNavController()
    // Başlangıç ekranı sabit kalmalı; yoksa giriş sırasında hesap değişince grafik sıfırlanır
    val start = remember { if (vm.account.value == null) "login" else "main" }

    val imdb by vm.imdb.collectAsStateWithLifecycle()
    val ratings = remember(imdb) { RatingCtx(imdb, vm::requestRating) }

    CompositionLocalProvider(LocalRatings provides ratings) {
    NavHost(navController = nav, startDestination = start) {
        composable("login") {
            LoginScreen(vm) {
                nav.navigate("main") { popUpTo("login") { inclusive = true } }
            }
        }
        composable("main") { MainScreen(vm, nav) }
        composable("movie") { MovieDetailScreen(vm, nav) }
        composable("series") { SeriesDetailScreen(vm, nav) }
        composable("player") { PlayerScreen(vm, nav) }
        composable("settings") { SettingsScreen(vm, nav) }
        composable("content") { ContentScreen(vm, nav) }
        composable("more") { MoreScreen(vm, nav) }
    }
    }
}
